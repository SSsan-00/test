#!/usr/bin/env php
<?php
/**
 * Analyzer Step1 — ファイル走査 & コメント除去 + define() 展開処理
 * 対象: PHP5.6、PostgreSQL、HTML/JS混在
 *
 * 機能:
 * - 指定ディレクトリ配下の .php, .inc, .html, .js ファイルを再帰的に探索
 * - ファイルごとにコメントを除去した内容を取得
 * - define() による定数定義を抽出し、全ファイルに対して展開
 * - 結果を後続の解析処理に渡せるよう連想配列で保持
 */

if ($argc < 2) {
    echo "Usage: php analyzer_step1.php [target_directory]\n";
    exit(1);
}

$targetDir = $argv[1];
if (!is_dir($targetDir)) {
    echo "指定されたディレクトリが存在しません。\n";
    exit(1);
}

$extensions = ['php', 'inc', 'html', 'js'];

function strip_comments($content, $ext) {
    if (in_array($ext, ['php', 'inc'])) {
        $output = '';
        $tokens = token_get_all($content);
        foreach ($tokens as $token) {
            if (is_array($token)) {
                list($id, $text) = $token;
                if (in_array($id, [T_COMMENT, T_DOC_COMMENT])) {
                    continue;
                }
                $output .= $text;
            } else {
                $output .= $token;
            }
        }
        return $output;
    }

    if ($ext === 'html') {
        return preg_replace('/<!--.*?-->/s', '', $content);
    }

    if ($ext === 'js') {
        $content = preg_replace('!//.*!', '', $content);
        $content = preg_replace('!/\*.*?\*/!s', '', $content);
        return $content;
    }

    return $content;
}

function analyze_files($root, $extensions) {
    $results = [];

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $ext = strtolower($file->getExtension());
            if (in_array($ext, $extensions)) {
                $relativePath = ltrim(str_replace(realpath($root), '', realpath($file->getPathname())), '/\\');
                $rawContent = file_get_contents($file->getPathname());
                $cleanedContent = strip_comments($rawContent, $ext);
                $results[$relativePath] = $cleanedContent;
            }
        }
    }

    return $results;
}

function extract_define_constants($files) {
    $constants = [];
    $defineRegex = '/define\s*\(\s*[\'"]([A-Z0-9_]+)[\'"]\s*,\s*[\'"]([^\'"]+)[\'"]\s*\)\s*;/i';

    foreach ($files as $code) {
        if (preg_match_all($defineRegex, $code, $matches)) {
            foreach ($matches[1] as $i => $key) {
                $constants[$key] = $matches[2][$i];
            }
        }
    }

    return $constants;
}

function apply_constants_to_code($files, $constants) {
    foreach ($files as $path => &$code) {
        foreach ($constants as $const => $value) {
            // "TABLE_USER" → 'users' などを展開（"TABLE_USER" / 'TABLE_USER' / bare）
            $code = preg_replace("/\\b" . preg_quote($const, '/') . "\\b/", $value, $code);
        }
    }
    return $files;
}

$cleanedFiles = analyze_files($targetDir, $extensions);
$constants = extract_define_constants($cleanedFiles);
$expandedFiles = apply_constants_to_code($cleanedFiles, $constants);

// 確認用出力（本番運用時は次フェーズにデータを渡す）
foreach ($expandedFiles as $path => $code) {
    echo "=== $path ===\n";
    echo mb_strimwidth($code, 0, 300, "...") . "\n\n";
}
