#!/usr/bin/env php
<?php
/**
 * Analyzer — 解析データ出力対応版
 * コメント除去、定数展開、CRUD/関数解析、インクルード解析、フロントエンドアクセス解析 → Excel出力
 */

require_once __DIR__ . '/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// ...（前半の関数は前と同じなので省略 — 必要に応じて保持）...

// ↓↓↓ Excel出力処理を追加 ↓↓↓
function output_excel($fileCrud, $functionCrud, $includeMap, $frontendMap, $outputPath = 'analysis_result.xlsx') {
    $spreadsheet = new Spreadsheet();
    $sheet1 = $spreadsheet->getActiveSheet();
    $sheet1->setTitle('File-CRUD');

    // シート1: File-CRUD（ファイルごとにテーブルをブロック出力）
    $row = 1;
    foreach ($fileCrud as $file => $tables) {
        $sheet1->setCellValue("A{$row}", "[{$file}]");
        $row++;
        $sheet1->fromArray(['テーブル名', 'C', 'R', 'U', 'D'], null, "A{$row}");
        $row++;
        foreach ($tables as $table => $flags) {
            $sheet1->fromArray(array_merge([$table], array_values($flags)), null, "A{$row}");
            $row++;
        }
        $row++;
    }

    // シート2: Function-CRUD
    $sheet2 = $spreadsheet->createSheet()->setTitle('Function-CRUD');
    $sheet2->fromArray(['関数名@ファイル名', 'テーブル名', 'C', 'R', 'U', 'D'], null, 'A1');
    $row = 2;
    foreach ($functionCrud as $func => $tables) {
        foreach ($tables as $table => $flags) {
            $sheet2->fromArray(array_merge([$func, $table], array_values($flags)), null, "A{$row}");
            $row++;
        }
    }

    // シート3: Include-Relations
    $sheet3 = $spreadsheet->createSheet()->setTitle('Include-Relations');
    $sheet3->fromArray(['ファイル名', 'include_1', 'include_2', 'include_3', '...'], null, 'A1');
    $row = 2;
    foreach ($includeMap as $file => $includes) {
        $sheet3->fromArray(array_merge([$file], $includes), null, "A{$row}");
        $row++;
    }

    // シート4: Frontend-Access
    $sheet4 = $spreadsheet->createSheet()->setTitle('Frontend-Access');
    $sheet4->fromArray(['ファイル名', 'action', 'location.href', 'window.open', 'XMLHttpRequest'], null, 'A1');
    $row = 2;
    foreach ($frontendMap as $file => $types) {
        $rowData = [$file];
        foreach (['action', 'location.href', 'window.open', 'XMLHttpRequest'] as $key) {
            $rowData[] = implode(", ", $types[$key] ?? []);
        }
        $sheet4->fromArray($rowData, null, "A{$row}");
        $row++;
    }

    $writer = new Xlsx($spreadsheet);
    $writer->save($outputPath);
    echo "Excelファイル出力完了: {$outputPath}\n";
}

// === 実行 ===
$cleanedFiles = analyze_files($targetDir, $extensions);
$constants = extract_define_constants($cleanedFiles);
$expandedFiles = apply_constants_to_code($cleanedFiles, $constants);
$sqlCrudResults = extract_sql_crud_operations($expandedFiles);
$functionCrudResults = extract_function_sql_crud($expandedFiles);
$includeResults = extract_includes($expandedFiles);
$frontendAccessResults = extract_frontend_access($expandedFiles);

output_excel($sqlCrudResults, $functionCrudResults, $includeResults, $frontendAccessResults);
