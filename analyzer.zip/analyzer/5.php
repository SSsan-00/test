#!/usr/bin/env php
<?php
/**
 * Analyzer Step1 — ファイル走査 & コメント除去 + define() 展開 + SQL抽出&CRUD分類 + 関数単位抽出 + include依存解析
 * 対象: PHP5.6、PostgreSQL、HTML/JS混在
 */

if ($argc < 2) {
    echo "Usage: php analyzer_step1.php [target_directory]\n";
    exit(1);
}

$targetDir = $argv[1];
if (!is_dir($targetDir)) {
    echo "指定されたディレクトリが存在しません。\n";
    exit(1);
}

$extensions = ['php', 'inc', 'html', 'js'];

function strip_comments($content, $ext) {
    if (in_array($ext, ['php', 'inc'])) {
        $output = '';
        $tokens = token_get_all($content);
        foreach ($tokens as $token) {
            if (is_array($token)) {
                list($id, $text) = $token;
                if (in_array($id, [T_COMMENT, T_DOC_COMMENT])) {
                    continue;
                }
                $output .= $text;
            } else {
                $output .= $token;
            }
        }
        return $output;
    }
    if ($ext === 'html') {
        return preg_replace('/<!--.*?-->/s', '', $content);
    }
    if ($ext === 'js') {
        $content = preg_replace('!//.*!', '', $content);
        $content = preg_replace('!/\*.*?\*/!s', '', $content);
        return $content;
    }
    return $content;
}

function analyze_files($root, $extensions) {
    $results = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $ext = strtolower($file->getExtension());
            if (in_array($ext, $extensions)) {
                $relativePath = ltrim(str_replace(realpath($root), '', realpath($file->getPathname())), '/\\');
                $rawContent = file_get_contents($file->getPathname());
                $cleanedContent = strip_comments($rawContent, $ext);
                $results[$relativePath] = $cleanedContent;
            }
        }
    }
    return $results;
}

function extract_define_constants($files) {
    $constants = [];
    $defineRegex = '/define\s*\(\s*[\'"]([A-Z0-9_]+)[\'"]\s*,\s*[\'"]([^\'"]+)[\'"]\s*\)\s*;/i';
    foreach ($files as $code) {
        if (preg_match_all($defineRegex, $code, $matches)) {
            foreach ($matches[1] as $i => $key) {
                $constants[$key] = $matches[2][$i];
            }
        }
    }
    return $constants;
}

function apply_constants_to_code($files, $constants) {
    foreach ($files as $path => &$code) {
        foreach ($constants as $const => $value) {
            $code = preg_replace("/\\b" . preg_quote($const, '/') . "\\b/", $value, $code);
        }
    }
    return $files;
}

function extract_sql_crud_operations($files) {
    $results = [];
    $sqlPattern = '/\b(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM)\b.*?;(?=(?:[^\'"]|\'[^\']*\'|\"[^\"]*\")*$)/is';
    $tablePattern = '/\bFROM\s+([a-zA-Z0-9_\"\.]+)|\bINTO\s+([a-zA-Z0-9_\"\.]+)|\bUPDATE\s+([a-zA-Z0-9_\"\.]+)/i';

    foreach ($files as $path => $code) {
        $crud = [];
        if (preg_match_all($sqlPattern, $code, $matches)) {
            foreach ($matches[0] as $sql) {
                $type = strtoupper(trim(strtok($sql, " ")));
                if (preg_match($tablePattern, $sql, $tmatches)) {
                    $table = $tmatches[1] ?: $tmatches[2] ?: $tmatches[3];
                    $table = trim($table, '\"');
                    if (!isset($crud[$table])) {
                        $crud[$table] = ['C' => '', 'R' => '', 'U' => '', 'D' => ''];
                    }
                    if ($type === 'SELECT') $crud[$table]['R'] = '○';
                    if ($type === 'INSERT' || $type === 'INSERT INTO') $crud[$table]['C'] = '○';
                    if ($type === 'UPDATE') $crud[$table]['U'] = '○';
                    if ($type === 'DELETE') $crud[$table]['D'] = '○';
                }
            }
        }
        if (!empty($crud)) {
            $results[$path] = $crud;
        }
    }
    return $results;
}

function extract_function_sql_crud($files) {
    $results = [];
    $functionPattern = '/function\s+(\w+)\s*\([^)]*\)\s*\{(.*?)\}/is';
    $sqlPattern = '/\b(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM)\b.*?;(?=(?:[^\'"]|\'[^\']*\'|\"[^\"]*\")*$)/is';
    $tablePattern = '/\bFROM\s+([a-zA-Z0-9_\"\.]+)|\bINTO\s+([a-zA-Z0-9_\"\.]+)|\bUPDATE\s+([a-zA-Z0-9_\"\.]+)/i';

    foreach ($files as $path => $code) {
        if (preg_match_all($functionPattern, $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $func) {
                $fname = $func[1];
                $body = $func[2];
                $crud = [];
                if (preg_match_all($sqlPattern, $body, $sqls)) {
                    foreach ($sqls[0] as $sql) {
                        $type = strtoupper(trim(strtok($sql, " ")));
                        if (preg_match($tablePattern, $sql, $tmatches)) {
                            $table = $tmatches[1] ?: $tmatches[2] ?: $tmatches[3];
                            $table = trim($table, '\"');
                            if (!isset($crud[$table])) {
                                $crud[$table] = ['C' => '', 'R' => '', 'U' => '', 'D' => ''];
                            }
                            if ($type === 'SELECT') $crud[$table]['R'] = '○';
                            if ($type === 'INSERT' || $type === 'INSERT INTO') $crud[$table]['C'] = '○';
                            if ($type === 'UPDATE') $crud[$table]['U'] = '○';
                            if ($type === 'DELETE') $crud[$table]['D'] = '○';
                        }
                    }
                }
                if (!empty($crud)) {
                    $results[$fname . '@' . $path] = $crud;
                }
            }
        }
    }
    return $results;
}

function extract_includes($files) {
    $results = [];
    $includePattern = '/\b(include|require)(_once)?\s*\(?(.*?)\)?\s*;/i';

    foreach ($files as $path => $code) {
        if (preg_match_all($includePattern, $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $raw = trim($match[3]);
                if (!isset($results[$path])) $results[$path] = [];
                $results[$path][] = $raw;
            }
        }
    }
    return $results;
}

$cleanedFiles = analyze_files($targetDir, $extensions);
$constants = extract_define_constants($cleanedFiles);
$expandedFiles = apply_constants_to_code($cleanedFiles, $constants);
$sqlCrudResults = extract_sql_crud_operations($expandedFiles);
$functionCrudResults = extract_function_sql_crud($expandedFiles);
$includeResults = extract_includes($expandedFiles);

// 出力：ファイル単位
foreach ($sqlCrudResults as $file => $tables) {
    echo "=== $file ===\n";
    foreach ($tables as $table => $flags) {
        echo "- $table: ";
        foreach ($flags as $op => $v) {
            if ($v !== '') echo "$op ";
        }
        echo "\n";
    }
    echo "\n";
}

// 出力：関数単位
foreach ($functionCrudResults as $func => $tables) {
    echo "=== $func ===\n";
    foreach ($tables as $table => $flags) {
        echo "- $table: ";
        foreach ($flags as $op => $v) {
            if ($v !== '') echo "$op ";
        }
        echo "\n";
    }
    echo "\n";
}

// 出力：インクルード解析
foreach ($includeResults as $file => $includes) {
    echo "=== includes in $file ===\n";
    foreach ($includes as $inc) {
        echo "- $inc\n";
    }
    echo "\n";
}
