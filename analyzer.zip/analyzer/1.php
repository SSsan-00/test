#!/usr/bin/env php
<?php
/**
 * Analyzer Step1 — ファイル走査 & コメント除去処理
 * 対象: PHP5.6、PostgreSQL、HTML/JS混在
 *
 * 機能:
 * - 指定ディレクトリ配下の .php, .inc, .html, .js ファイルを再帰的に探索
 * - ファイルごとにコメントを除去した内容を取得
 * - 結果を後続の解析処理に渡せるよう連想配列で保持
 */

if ($argc < 2) {
    echo "Usage: php analyzer_step1.php [target_directory]\n";
    exit(1);
}

$targetDir = $argv[1];
if (!is_dir($targetDir)) {
    echo "指定されたディレクトリが存在しません。\n";
    exit(1);
}

$extensions = ['php', 'inc', 'html', 'js'];

/**
 * コメント除去ロジック
 * @param string $content ファイル内容
 * @param string $ext 拡張子
 * @return string コメント除去後のコード
 */
function strip_comments($content, $ext) {
    if (in_array($ext, ['php', 'inc'])) {
        $output = '';
        $tokens = token_get_all($content);
        foreach ($tokens as $token) {
            if (is_array($token)) {
                list($id, $text) = $token;
                if (in_array($id, [T_COMMENT, T_DOC_COMMENT])) {
                    continue;
                }
                $output .= $text;
            } else {
                $output .= $token;
            }
        }
        return $output;
    }

    if ($ext === 'html') {
        return preg_replace('/<!--.*?-->/s', '', $content);
    }

    if ($ext === 'js') {
        $content = preg_replace('!//.*!', '', $content);
        $content = preg_replace('!/\*.*?\*/!s', '', $content);
        return $content;
    }

    return $content;
}

/**
 * 対象ディレクトリ配下の全ファイルを再帰的に解析
 * @param string $root ルートディレクトリ
 * @param array $extensions 対象拡張子
 * @return array 相対パス => コメント除去後コード
 */
function analyze_files($root, $extensions) {
    $results = [];

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $ext = strtolower($file->getExtension());
            if (in_array($ext, $extensions)) {
                $relativePath = ltrim(str_replace(realpath($root), '', realpath($file->getPathname())), '/\\');
                $rawContent = file_get_contents($file->getPathname());
                $cleanedContent = strip_comments($rawContent, $ext);
                $results[$relativePath] = $cleanedContent;
            }
        }
    }

    return $results;
}

$cleanedFiles = analyze_files($targetDir, $extensions);

// 確認用出力（本番運用時は次フェーズにデータを渡す）
foreach ($cleanedFiles as $path => $code) {
    echo "=== $path ===\n";
    echo mb_strimwidth($code, 0, 300, "...") . "\n\n";
}
