<?php
declare(strict_types=1);

namespace PhpParser;

/**
 * Parser interface
 * 
 * PSR-0互換性のためにインターフェースを定義
 */
interface Parser
{
    /**
     * PHPコードをASTに解析
     *
     * @param string $code 解析対象のPHPコード
     * @return array|null 解析結果のASTノード、失敗時はnull
     * @throws Error 解析中にエラーが発生した場合
     */
    public function parse(string $code);
} 