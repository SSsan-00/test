<?php
declare(strict_types=1);

namespace App\PhpParser;

use PhpParser\Parser;
use PhpParser\Error;
use PhpParser\ErrorHandler;

/**
 * シンプルなパーサー実装
 * 
 * PHP-Parser互換性問題のためのシンプルな実装
 */
class SimpleParser implements Parser
{
    /**
     * PHPコードをパースする
     * 
     * @param string $code PHPコード
     * @param ErrorHandler|null $errorHandler エラーハンドラー
     * @return array|null AST、パース失敗時はnull
     */
    public function parse(string $code, ?ErrorHandler $errorHandler = null): ?array
    {
        // この実装はスタブです。実際のプロジェクトでは、必要に応じて実装を追加してください。
        // ここでは単にからのASTを返します。
        return [];
    }
    
    /**
     * トークンを取得する
     * 
     * @return array トークンの配列
     */
    public function getTokens(): array
    {
        // この実装はスタブです。
        return [];
    }
} 