<?php
declare(strict_types=1);

namespace PhpParser\PrettyPrinter;

/**
 * 標準プリンター
 * 
 * コード生成のための標準プリンター
 */
class Standard
{
    /**
     * @var array オプション
     */
    private array $options;
    
    /**
     * コンストラクタ
     *
     * @param array $options オプション
     */
    public function __construct(array $options = [])
    {
        $this->options = $options + [
            'shortArraySyntax' => true,
            'preserveComments' => false,
            'newline' => "\n",
            'indent' => "    "
        ];
    }
    
    /**
     * ASTをファイルとして整形印字する
     *
     * @param array $nodes ノード
     * @return string 整形印字されたコード
     */
    public function prettyPrintFile(array $nodes): string
    {
        // スタブ実装
        return "<?php\n";
    }
    
    /**
     * ASTを整形印字する
     *
     * @param array $nodes ノード
     * @return string 整形印字されたコード
     */
    public function prettyPrint(array $nodes): string
    {
        // スタブ実装
        return "";
    }
} 