<?php
declare(strict_types=1);

namespace App\PhpParser;

/**
 * PHP-Parserのアダプター
 * 
 * PHP-Parserの互換性問題を解決するためのクラス
 */
class ParserAdapter
{
    /**
     * パーサーオブジェクトを作成する
     *
     * @return \PhpParser\Parser パーサーオブジェクト
     */
    public static function createParser(): \PhpParser\Parser
    {
        // 直接ParserFactoryを使わずに独自のパーサーを返す
        return new SimpleParser();
    }

    /**
     * プリンターオブジェクトを作成する
     *
     * @return \PhpParser\PrettyPrinter\Standard プリンターオブジェクト
     */
    public static function createPrinter(): \PhpParser\PrettyPrinter\Standard
    {
        return new \PhpParser\PrettyPrinter\Standard([
            'shortArraySyntax' => true,
            'preserveComments' => false,
            'newline' => "\n",
            'indent' => "    "
        ]);
    }
    
    /**
     * ASTを整形されたコードに変換する
     *
     * @param \PhpParser\PrettyPrinter\Standard $printer プリンターオブジェクト
     * @param array $ast AST
     * @return string 整形されたコード
     */
    public static function printCode(\PhpParser\PrettyPrinter\Standard $printer, array $ast): string
    {
        // 適切なメソッドを呼び出す
        if (method_exists($printer, 'prettyPrintFile')) {
            return $printer->prettyPrintFile($ast);
        }
        
        return $printer->prettyPrint($ast);
    }
} 