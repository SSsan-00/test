<?php
declare(strict_types=1);

namespace PhpParser;

/**
 * ノードトラバーサー
 * 
 * ASTを走査するためのクラス
 */
class NodeTraverser
{
    /**
     * @var array ビジター
     */
    private array $visitors = [];
    
    /**
     * ビジターを追加
     *
     * @param NodeVisitorAbstract $visitor ビジター
     * @return void
     */
    public function addVisitor(NodeVisitorAbstract $visitor): void
    {
        $this->visitors[] = $visitor;
    }
    
    /**
     * ASTを走査
     *
     * @param array $nodes ノード
     * @return array 処理後のノード
     */
    public function traverse(array $nodes): array
    {
        // 各ビジターのbeforeTraverseを呼び出し
        foreach ($this->visitors as $visitor) {
            if (method_exists($visitor, 'beforeTraverse')) {
                $visitor->beforeTraverse($nodes);
            }
        }
        
        // 各ノードに対して各ビジターのenterNodeとleaveNodeを呼び出し
        // スタブ実装のため実際の処理は行わない
        
        // 各ビジターのafterTraverseを呼び出し
        foreach ($this->visitors as $visitor) {
            if (method_exists($visitor, 'afterTraverse')) {
                $visitor->afterTraverse($nodes);
            }
        }
        
        return $nodes;
    }
} 