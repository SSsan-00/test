<?php
declare(strict_types=1);

namespace PhpParser;

/**
 * ノードビジター抽象クラス
 * 
 * ノード走査処理の基底クラス
 */
abstract class NodeVisitorAbstract
{
    /**
     * 走査前処理
     *
     * @param array $nodes ノード
     * @return array|null 変更されたノード、または何も変更しない場合はnull
     */
    public function beforeTraverse(array $nodes)
    {
        return null;
    }
    
    /**
     * ノード進入時処理
     *
     * @param Node $node ノード
     * @return Node|null 変更されたノード、または何も変更しない場合はnull
     */
    public function enterNode(Node $node)
    {
        return null;
    }
    
    /**
     * ノード退出時処理
     *
     * @param Node $node ノード
     * @return Node|null 変更されたノード、または何も変更しない場合はnull
     */
    public function leaveNode(Node $node)
    {
        return null;
    }
    
    /**
     * 走査後処理
     *
     * @param array $nodes ノード
     * @return array|null 変更されたノード、または何も変更しない場合はnull
     */
    public function afterTraverse(array $nodes)
    {
        return null;
    }
} 