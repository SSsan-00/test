<?php
declare(strict_types=1);

namespace PhpParser;

/**
 * Node interface
 * 
 * PSR-0互換性のためにインターフェースを定義
 */
interface Node
{
    /**
     * getStartLine method
     * 
     * @return int
     */
    public function getStartLine(): int;
    
    /**
     * getLine method for backward compatibility
     * 
     * @return int
     */
    public function getLine(): int;
    
    /**
     * getAttribute method
     * 
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function getAttribute(string $key, $default = null);
} 