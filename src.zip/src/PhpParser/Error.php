<?php
declare(strict_types=1);

namespace PhpParser;

/**
 * Parser error
 * 
 * PSR-0互換性のためにクラスを定義
 */
class Error extends \RuntimeException
{
    /**
     * エラーの行
     */
    protected int $startLine;
    
    /**
     * コンストラクタ
     *
     * @param string $message エラーメッセージ
     * @param int $line エラーが発生した行
     */
    public function __construct(string $message, int $line = -1)
    {
        parent::__construct($message);
        $this->startLine = $line;
    }
    
    /**
     * エラーが発生した行を取得
     *
     * @return int
     */
    public function getStartLine(): int
    {
        return $this->startLine;
    }
} 