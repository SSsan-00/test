<?php
declare(strict_types=1);

namespace PhpParser;

/**
 * Parser factory
 * 
 * PSR-0互換性のためにクラスを定義
 */
class ParserFactory
{
    /**
     * 最新のサポートされているバージョン用のパーサーを作成
     *
     * @return Parser
     */
    public function createForNewestSupportedVersion(): Parser
    {
        // ParserAdapterを使用
        return \App\PhpParser\ParserAdapter::createParser();
    }
} 