<?php

namespace App\Model;

/**
 * 入力データを管理するクラス
 * 
 * ビュー名のリスト、ストアドプロシージャ名のリストなど、
 * 解析に必要な外部ファイルからの入力データを管理する。
 */
class InputData
{
    /**
     * データベースビューのリスト
     * @var array
     */
    private array $views = [];
    
    /**
     * ストアドプロシージャのリスト
     * @var array
     */
    private array $storedProcedures = [];
    
    /**
     * ビューリストを設定する
     * 
     * @param array $views ビュー名の配列
     * @return void
     */
    public function setViews(array $views): void
    {
        $this->views = $views;
    }
    
    /**
     * ストアドプロシージャリストを設定する
     * 
     * @param array $procedures ストアドプロシージャ名の配列
     * @return void
     */
    public function setStoredProcedures(array $procedures): void
    {
        $this->storedProcedures = $procedures;
    }
    
    /**
     * ビューリストを取得する
     * 
     * @return array ビュー名の配列
     */
    public function getViews(): array
    {
        return $this->views;
    }
    
    /**
     * ストアドプロシージャリストを取得する
     * 
     * @return array ストアドプロシージャ名の配列
     */
    public function getStoredProcedures(): array
    {
        return $this->storedProcedures;
    }
    
    /**
     * 指定した名前がビューかどうかをチェックする
     * 
     * @param string $name チェックする名前
     * @return bool ビューの場合はtrue
     */
    public function isView(string $name): bool
    {
        return in_array($name, $this->views);
    }
    
    /**
     * 指定した名前がストアドプロシージャかどうかをチェックする
     * 
     * @param string $name チェックする名前
     * @return bool ストアドプロシージャの場合はtrue
     */
    public function isStoredProcedure(string $name): bool
    {
        return in_array($name, $this->storedProcedures);
    }
} 