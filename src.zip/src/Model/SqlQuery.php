<?php
declare(strict_types=1);

namespace App\Model;

/**
 * SQLクエリを表すモデル
 */
class SqlQuery
{
    /**
     * SQLクエリ文字列
     */
    private string $query;
    
    /**
     * テーブル名とCRUD操作のマッピング
     */
    private array $tables = [];
    
    /**
     * コンストラクタ
     *
     * @param string $query SQLクエリ文字列
     */
    public function __construct(string $query)
    {
        $this->query = $query;
    }
    
    /**
     * クエリ文字列を取得
     *
     * @return string クエリ文字列
     */
    public function getQuery(): string
    {
        return $this->query;
    }
    
    /**
     * テーブル名とCRUD操作を関連付ける
     *
     * @param string $table テーブル名
     * @param string|array $crud CRUD操作（'C', 'R', 'U', 'D'のいずれかまたはその組み合わせ）
     * @return self
     */
    public function addTable(string $table, $crud): self
    {
        if (!isset($this->tables[$table])) {
            $this->tables[$table] = [];
        }
        
        // 文字列の場合は文字の配列に変換
        if (is_string($crud)) {
            $crud = str_split($crud);
        }
        
        // 重複を排除して追加
        $this->tables[$table] = array_unique(array_merge($this->tables[$table], $crud));
        
        return $this;
    }
    
    /**
     * 指定テーブルのCRUD操作を取得
     *
     * @param string $table テーブル名
     * @return array CRUD操作の配列
     */
    public function getTableCrud(string $table): array
    {
        return $this->tables[$table] ?? [];
    }
    
    /**
     * すべてのテーブルとCRUD操作を取得
     *
     * @return array テーブル名をキー、CRUD操作の配列を値とする連想配列
     */
    public function getTables(): array
    {
        return $this->tables;
    }
    
    /**
     * クエリを配列表現で取得
     *
     * @return array クエリの配列表現
     */
    public function toArray(): array
    {
        return [
            'query' => $this->query,
            'tables' => $this->tables
        ];
    }
} 