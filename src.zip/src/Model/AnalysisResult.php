<?php
declare(strict_types=1);

namespace App\Model;

/**
 * 解析結果を格納するクラス
 */
class AnalysisResult
{
    /**
     * 対象ファイルパス
     */
    private string $filePath;
    
    /**
     * テーブル単位のCRUD操作
     */
    private array $tableCruds = [];
    
    /**
     * 関数単位のCRUD操作
     */
    private array $functionCruds = [];
    
    /**
     * インクルード情報
     */
    private array $includes = [];
    
    /**
     * 外部アクセス情報
     */
    private array $externalAccesses = [];
    
    /**
     * ストアドプロシージャ呼び出し
     */
    private array $procedureCalls = [];
    
    /**
     * SQLクエリ情報
     */
    private array $queries = [];
    
    /**
     * 変数とその値のマッピング
     */
    private array $variables = [];
    
    /**
     * 定数とその値のマッピング
     */
    private array $constants = [];
    
    /**
     * エラー情報
     */
    private array $errors = [];
    
    /**
     * コンストラクタ
     *
     * @param string $filePath 対象ファイルのパス
     */
    public function __construct(string $filePath)
    {
        $this->filePath = $filePath;
    }
    
    /**
     * ファイルパスを取得
     *
     * @return string ファイルパス
     */
    public function getFilePath(): string
    {
        return $this->filePath;
    }
    
    /**
     * SQLクエリを追加
     *
     * @param string $query SQL クエリ文字列
     * @param array $metadata メタデータ
     * @return self
     */
    public function addQuery(string $query, array $metadata = []): self
    {
        $this->queries[] = [
            'query' => $query,
            'metadata' => $metadata
        ];
        
        // テーブル情報がある場合、テーブル単位のCRUD情報も追加
        if (isset($metadata['tables'])) {
            foreach ($metadata['tables'] as $table => $crud) {
                $this->addTableCrud($table, $crud);
            }
        }
        
        return $this;
    }
    
    /**
     * テーブル単位のCRUD操作を追加
     *
     * @param string $table テーブル名
     * @param string|array $crud CRUD操作
     * @return self
     */
    public function addTableCrud(string $table, $crud): self
    {
        if (!isset($this->tableCruds[$table])) {
            $this->tableCruds[$table] = [];
        }
        
        // 文字列の場合は文字の配列に変換
        if (is_string($crud)) {
            $crud = str_split($crud);
        }
        
        // 重複を排除して追加
        $this->tableCruds[$table] = array_unique(array_merge($this->tableCruds[$table], $crud));
        
        return $this;
    }
    
    /**
     * 関数単位のCRUD操作を追加
     *
     * @param string $function 関数名
     * @param array $cruds テーブル名とCRUD操作のマッピング
     * @return self
     */
    public function addFunctionCrud(string $function, array $cruds): self
    {
        if (!isset($this->functionCruds[$function])) {
            $this->functionCruds[$function] = [];
        }
        
        foreach ($cruds as $table => $crud) {
            // 文字列の場合は文字の配列に変換
            if (is_string($crud)) {
                $crud = str_split($crud);
            }
            
            if (!isset($this->functionCruds[$function][$table])) {
                $this->functionCruds[$function][$table] = [];
            }
            
            // 重複を排除して追加
            $this->functionCruds[$function][$table] = array_unique(
                array_merge($this->functionCruds[$function][$table], $crud)
            );
            
            // テーブル単位のCRUD情報も更新
            $this->addTableCrud($table, $crud);
        }
        
        return $this;
    }
    
    /**
     * インクルード情報を追加
     *
     * @param array $include インクルード情報
     * @return self
     */
    public function addInclude(array $include): self
    {
        $this->includes[] = $include;
        return $this;
    }
    
    /**
     * 外部アクセス情報を追加
     *
     * @param array $access 外部アクセス情報
     * @return self
     */
    public function addExternalAccess(array $access): self
    {
        $this->externalAccesses[] = $access;
        return $this;
    }
    
    /**
     * ストアドプロシージャ呼び出しを追加
     *
     * @param array $procedure ストアドプロシージャ情報
     * @return self
     */
    public function addProcedureCall(array $procedure): self
    {
        $this->procedureCalls[] = $procedure;
        return $this;
    }
    
    /**
     * 変数をセット
     *
     * @param string $name 変数名
     * @param string $value 変数値
     * @return self
     */
    public function setVariable(string $name, string $value): self
    {
        $this->variables[$name] = $value;
        return $this;
    }
    
    /**
     * 定数をセット
     *
     * @param string $name 定数名
     * @param string $value 定数値
     * @return self
     */
    public function setConstant(string $name, string $value): self
    {
        $this->constants[$name] = $value;
        return $this;
    }
    
    /**
     * クエリリストを取得
     *
     * @return array クエリのリスト
     */
    public function getQueries(): array
    {
        return $this->queries;
    }
    
    /**
     * テーブル単位のCRUD操作を取得
     *
     * @return array テーブル名をキー、CRUD操作の配列を値とする連想配列
     */
    public function getTableCruds(): array
    {
        return $this->tableCruds;
    }
    
    /**
     * 関数単位のCRUD操作を取得
     *
     * @return array 関数名をキー、テーブルとCRUD操作のマッピングを値とする連想配列
     */
    public function getFunctionCruds(): array
    {
        return $this->functionCruds;
    }
    
    /**
     * インクルード情報を取得
     *
     * @return array インクルード情報のリスト
     */
    public function getIncludes(): array
    {
        return $this->includes;
    }
    
    /**
     * 外部アクセス情報を取得
     *
     * @return array 外部アクセス情報のリスト
     */
    public function getExternalAccesses(): array
    {
        return $this->externalAccesses;
    }
    
    /**
     * ストアドプロシージャ呼び出しを取得
     *
     * @return array ストアドプロシージャ情報のリスト
     */
    public function getProcedureCalls(): array
    {
        return $this->procedureCalls;
    }
    
    /**
     * 変数を取得
     *
     * @param string $name 変数名
     * @return string|null 変数値、存在しない場合はnull
     */
    public function getVariable(string $name): ?string
    {
        return $this->variables[$name] ?? null;
    }
    
    /**
     * 全変数を取得
     *
     * @return array 変数のマッピング
     */
    public function getVariables(): array
    {
        return $this->variables;
    }
    
    /**
     * 定数を取得
     *
     * @param string $name 定数名
     * @return string|null 定数値、存在しない場合はnull
     */
    public function getConstant(string $name): ?string
    {
        return $this->constants[$name] ?? null;
    }
    
    /**
     * 全定数を取得
     *
     * @return array 定数のマッピング
     */
    public function getConstants(): array
    {
        return $this->constants;
    }

    /**
     * エラーを追加
     *
     * @param string $message エラーメッセージ
     * @param array $context エラーのコンテキスト情報
     * @return self
     */
    public function addError(string $message, array $context = []): self
    {
        $this->errors[] = [
            'message' => $message,
            'context' => $context
        ];
        return $this;
    }

    /**
     * エラーを取得
     *
     * @return array エラー情報の配列
     */
    public function getErrors(): array
    {
        return $this->errors ?? [];
    }
} 