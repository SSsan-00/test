<?php

namespace App\Utils\StringAnalysis;

use PhpParser\Node;

/**
 * 文字列解析インターフェース
 */
interface StringAnalyzerInterface
{
    /**
     * ノードを解析して文字列値を抽出する
     * 
     * @param Node $node 解析対象のノード
     * @param int $depth 現在の再帰の深さ（無限ループ防止用）
     * @return string|null 抽出された文字列値、解析できない場合はnull
     */
    public function analyze(Node $node, int $depth = 0): ?string;
} 