<?php
declare(strict_types=1);

namespace App\Utils\StringAnalysis;

use PhpParser\Node;
use PhpParser\Node\Expr\BinaryOp\Concat;
use PhpParser\Node\Scalar\String_;
use PhpParser\Node\Scalar\LNumber;
use PhpParser\Node\Scalar\DNumber;
use PhpParser\Node\Expr\ConstFetch;
use PhpParser\Node\Expr\Variable;
use PhpParser\Node\Name;
use App\Utils\ErrorHandling\ErrorHandler;
use PhpParser\ParserFactory;

/**
 * 文字列表現を解析するクラス
 */
class StringAnalyzer
{
    /**
     * エラーハンドラ
     */
    private ?ErrorHandler $errorHandler;
    
    /**
     * 変数シンボルテーブル
     */
    private array $variables = [];
    
    /**
     * 定数シンボルテーブル
     */
    private array $constants = [];
    
    /**
     * コンストラクタ
     */
    public function __construct(?ErrorHandler $errorHandler = null)
    {
        $this->errorHandler = $errorHandler;
    }
    
    /**
     * シンボルテーブルに変数を追加
     */
    public function setVariable(string $name, string $value): void
    {
        $this->variables[$name] = $value;
    }
    
    /**
     * シンボルテーブルに変数一覧を設定
     */
    public function setVariables(array $variables): void
    {
        $this->variables = $variables;
    }
    
    /**
     * シンボルテーブルに定数を追加
     */
    public function setConstant(string $name, string $value): void
    {
        $this->constants[$name] = $value;
    }
    
    /**
     * シンボルテーブルに定数一覧を設定
     */
    public function setConstants(array $constants): void
    {
        $this->constants = $constants;
    }
    
    /**
     * ノードを解析して文字列表現を取得
     *
     * @param mixed $node 解析対象のノード
     * @return string|null 解析結果（文字列）、解析失敗時はnull
     */
    public function analyze($node): ?string
    {
        if ($node === null) {
            return null;
        }
        
        try {
            // 文字列リテラル
            if ($node instanceof String_) {
                return $node->value;
            }
            
            // 数値リテラル
            if ($node instanceof LNumber || $node instanceof DNumber) {
                return (string)$node->value;
            }
            
            // 文字列連結
            if ($node instanceof Concat) {
                $left = $this->analyze($node->left);
                $right = $this->analyze($node->right);
                
                if ($left !== null && $right !== null) {
                    return $left . $right;
                }
            }
            
            // 定数
            if ($node instanceof ConstFetch && $node->name instanceof Name) {
                $constName = $node->name->toString();
                return $this->constants[$constName] ?? null;
            }
            
            // 変数
            if ($node instanceof Variable && is_string($node->name)) {
                return $this->variables[$node->name] ?? null;
            }
        } catch (\Exception $e) {
            if ($this->errorHandler) {
                $this->errorHandler->handle('Error analyzing string: ' . $e->getMessage());
            }
        }
        
        return null;
    }
    
    /**
     * 文字列内の変数を置換する
     *
     * @param string $template 置換対象の文字列
     * @param array $variables 変数の配列（変数名 => 値）
     * @return string 置換後の文字列
     */
    public function replaceVariables(string $template, array $variables): string
    {
        $result = $template;
        
        foreach ($variables as $name => $value) {
            // {$変数名} 形式の置換
            $result = str_replace('{$' . $name . '}', $value, $result);
            // $変数名 形式の置換
            $result = str_replace('$' . $name, $value, $result);
        }
        
        return $result;
    }
    
    /**
     * 文字列内の定数を置換する
     *
     * @param string $template 置換対象の文字列
     * @param array $constants 定数の配列（定数名 => 値）
     * @return string 置換後の文字列
     */
    public function replaceConstants(string $template, array $constants): string
    {
        $result = $template;
        
        foreach ($constants as $name => $value) {
            // {定数名} 形式の置換
            $result = str_replace('{' . $name . '}', $value, $result);
            // 定数名 形式の置換（通常の文字列置換）
            $result = str_replace($name, $value, $result);
        }
        
        return $result;
    }
    
    /**
     * PHPコードから変数とその値を抽出する
     *
     * @param string $code PHPコード
     * @return array 変数の配列（変数名 => 値）
     */
    public function extractVariablesFromCode(string $code): array
    {
        $variables = [];
        
        // 単純な変数代入を正規表現で抽出
        if (preg_match_all('/\$([a-zA-Z0-9_]+)\s*=\s*["\']([^"\']*)["\'];/m', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $variables[$match[1]] = $match[2];
            }
        }
        
        // より複雑なケースはASTパーサーを使用して抽出
        try {
            $parser = (new ParserFactory)->createForNewestSupportedVersion();
            $ast = $parser->parse($code);
            if ($ast) {
                $this->extractVariablesFromAst($ast, $variables);
            }
        } catch (\Exception $e) {
            if ($this->errorHandler) {
                $this->errorHandler->handle('Error extracting variables: ' . $e->getMessage());
            }
        }
        
        return $variables;
    }
    
    /**
     * ASTから変数を抽出する補助メソッド
     *
     * @param array $nodes ASTノード配列
     * @param array &$variables 抽出した変数を格納する配列
     */
    private function extractVariablesFromAst(array $nodes, array &$variables): void
    {
        foreach ($nodes as $node) {
            // 変数代入ノードの処理
            if ($node instanceof \PhpParser\Node\Expr\Assign) {
                if ($node->var instanceof \PhpParser\Node\Expr\Variable && is_string($node->var->name)) {
                    $varName = $node->var->name;
                    
                    // 文字列値の場合
                    if ($node->expr instanceof \PhpParser\Node\Scalar\String_) {
                        $variables[$varName] = $node->expr->value;
                    }
                    // 数値の場合
                    elseif ($node->expr instanceof \PhpParser\Node\Scalar\LNumber || $node->expr instanceof \PhpParser\Node\Scalar\DNumber) {
                        $variables[$varName] = (string)$node->expr->value;
                    }
                }
            }
            
            // 子ノードを再帰的に処理
            if ($node instanceof Node) {
                // Nodeクラスのプロパティを取得するには、リフレクションを使用します
                $properties = $this->getNodeProperties($node);
                foreach ($properties as $propName => $propValue) {
                    if (is_array($propValue)) {
                        $this->extractVariablesFromAst($propValue, $variables);
                    } elseif ($propValue instanceof Node) {
                        $this->extractVariablesFromAst([$propValue], $variables);
                    }
                }
            }
        }
    }
    
    /**
     * PHPコードから定数とその値を抽出する
     *
     * @param string $code PHPコード
     * @return array 定数の配列（定数名 => 値）
     */
    public function extractConstantsFromCode(string $code): array
    {
        $constants = [];
        
        // define() による定数定義を正規表現で抽出
        if (preg_match_all('/define\s*\(\s*["\']([a-zA-Z0-9_]+)["\'],\s*["\']?([^"\')]*)["\']?\s*\)/m', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $constants[$match[1]] = $match[2];
            }
        }
        
        // const による定数定義を正規表現で抽出
        if (preg_match_all('/const\s+([a-zA-Z0-9_]+)\s*=\s*["\']([^"\']*)["\'];/m', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $constants[$match[1]] = $match[2];
            }
        }
        
        // より複雑なケースはASTパーサーを使用して抽出
        try {
            $parser = (new ParserFactory)->createForNewestSupportedVersion();
            $ast = $parser->parse($code);
            if ($ast) {
                $this->extractConstantsFromAst($ast, $constants);
            }
        } catch (\Exception $e) {
            if ($this->errorHandler) {
                $this->errorHandler->handle('Error extracting constants: ' . $e->getMessage());
            }
        }
        
        return $constants;
    }
    
    /**
     * ASTから定数を抽出する補助メソッド
     *
     * @param array $nodes ASTノード配列
     * @param array &$constants 抽出した定数を格納する配列
     */
    private function extractConstantsFromAst(array $nodes, array &$constants): void
    {
        foreach ($nodes as $node) {
            // define() 関数呼び出しを処理
            if ($node instanceof \PhpParser\Node\Expr\FuncCall
                && $node->name instanceof \PhpParser\Node\Name
                && $node->name->toString() === 'define'
                && isset($node->args[0], $node->args[1])
            ) {
                $constNameNode = $node->args[0]->value;
                $constValueNode = $node->args[1]->value;
                
                if ($constNameNode instanceof \PhpParser\Node\Scalar\String_ 
                    && ($constValueNode instanceof \PhpParser\Node\Scalar\String_
                        || $constValueNode instanceof \PhpParser\Node\Scalar\LNumber
                        || $constValueNode instanceof \PhpParser\Node\Scalar\DNumber)
                ) {
                    $constants[$constNameNode->value] = (string)$constValueNode->value;
                }
            }
            
            // const 定義を処理
            if ($node instanceof \PhpParser\Node\Stmt\Const_) {
                foreach ($node->consts as $const) {
                    if ($const->value instanceof \PhpParser\Node\Scalar\String_
                        || $const->value instanceof \PhpParser\Node\Scalar\LNumber
                        || $const->value instanceof \PhpParser\Node\Scalar\DNumber
                    ) {
                        $constants[$const->name->toString()] = (string)$const->value->value;
                    }
                }
            }
            
            // 子ノードを再帰的に処理
            if ($node instanceof Node) {
                // Nodeクラスのプロパティを取得するには、リフレクションを使用します
                $properties = $this->getNodeProperties($node);
                foreach ($properties as $propName => $propValue) {
                    if (is_array($propValue)) {
                        $this->extractConstantsFromAst($propValue, $constants);
                    } elseif ($propValue instanceof Node) {
                        $this->extractConstantsFromAst([$propValue], $constants);
                    }
                }
            }
        }
    }
    
    /**
     * Nodeクラスのプロパティを取得する補助メソッド
     *
     * @param Node $node 解析対象のノード
     * @return array プロパティ名 => 値 の連想配列
     */
    private function getNodeProperties(Node $node): array
    {
        $properties = [];
        
        // リフレクションを使用してノードのプロパティを取得
        $reflection = new \ReflectionObject($node);
        foreach ($reflection->getProperties() as $property) {
            $property->setAccessible(true);
            $propName = $property->getName();
            $propValue = $property->getValue($node);
            $properties[$propName] = $propValue;
        }
        
        return $properties;
    }
    
    /**
     * SQLクエリ内の変数を置換する
     *
     * @param string $query SQLクエリ
     * @param array $variables 変数の配列（変数名 => 値）
     * @return string 置換後のクエリ
     */
    public function replaceVariablesInQuery(string $query, array $variables): string
    {
        return $this->replaceVariables($query, $variables);
    }
    
    /**
     * SQLクエリ内の定数を置換する
     *
     * @param string $query SQLクエリ
     * @param array $constants 定数の配列（定数名 => 値）
     * @return string 置換後のクエリ
     */
    public function replaceConstantsInQuery(string $query, array $constants): string
    {
        return $this->replaceConstants($query, $constants);
    }
    
    /**
     * 変数シンボルテーブルを取得する
     *
     * @return array 変数シンボルテーブル
     */
    public function getVariables(): array
    {
        return $this->variables;
    }
    
    /**
     * 定数シンボルテーブルを取得する
     *
     * @return array 定数シンボルテーブル
     */
    public function getConstants(): array
    {
        return $this->constants;
    }
} 