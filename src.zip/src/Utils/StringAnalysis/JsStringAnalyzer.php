<?php
declare(strict_types=1);

namespace App\Utils\StringAnalysis;

use App\Utils\ErrorHandling\ErrorHandler;

/**
 * JavaScript文字列を解析するクラス
 */
class JsStringAnalyzer
{
    /**
     * エラーハンドラ
     */
    private ?ErrorHandler $errorHandler;
    
    /**
     * 変数シンボルテーブル
     */
    private array $variables = [];
    
    /**
     * 定数シンボルテーブル
     */
    private array $constants = [];
    
    /**
     * コンストラクタ
     */
    public function __construct(?ErrorHandler $errorHandler = null)
    {
        $this->errorHandler = $errorHandler;
    }
    
    /**
     * シンボルテーブルに変数を追加
     */
    public function setVariable(string $name, string $value): void
    {
        $this->variables[$name] = $value;
    }
    
    /**
     * シンボルテーブルに変数一覧を設定
     */
    public function setVariables(array $variables): void
    {
        $this->variables = $variables;
    }
    
    /**
     * シンボルテーブルに定数を追加
     */
    public function setConstant(string $name, string $value): void
    {
        $this->constants[$name] = $value;
    }
    
    /**
     * シンボルテーブルに定数一覧を設定
     */
    public function setConstants(array $constants): void
    {
        $this->constants = $constants;
    }
    
    /**
     * JavaScriptコードから変数を抽出する
     *
     * @param string $jsCode JavaScriptコード
     * @return array 変数の配列（変数名 => 値）
     */
    public function extractVariablesFromCode(string $jsCode): array
    {
        $variables = [];
        
        // var/let/const 宣言の抽出
        $patterns = [
            // var varName = "value";
            '/(?:var|let|const)\s+([a-zA-Z0-9_$]+)\s*=\s*(["\'])(.*?)\2/m',
            // varName = "value";
            '/([a-zA-Z0-9_$]+)\s*=\s*(["\'])(.*?)\2/m',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $jsCode, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $match) {
                    if ($pattern === $patterns[0]) {
                        // var/let/const 宣言の場合
                        $varName = $match[1];
                        $value = $match[3];
                    } else {
                        // 代入式の場合
                        $varName = $match[1];
                        $value = $match[3];
                    }
                    
                    $variables[$varName] = $value;
                }
            }
        }
        
        return $variables;
    }
    
    /**
     * JavaScriptコードから定数を抽出する
     *
     * @param string $jsCode JavaScriptコード
     * @return array 定数の配列（定数名 => 値）
     */
    public function extractConstantsFromCode(string $jsCode): array
    {
        $constants = [];
        
        // const 宣言の抽出
        $pattern = '/const\s+([A-Z0-9_$]+)\s*=\s*(["\'])(.*?)\2/m';
        
        if (preg_match_all($pattern, $jsCode, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $constName = $match[1];
                $value = $match[3];
                $constants[$constName] = $value;
            }
        }
        
        return $constants;
    }
    
    /**
     * JavaScript文字列内の変数を置換する
     *
     * @param string $template 置換対象の文字列
     * @param array $variables 変数の配列（変数名 => 値）
     * @return string 置換後の文字列
     */
    public function replaceVariables(string $template, array $variables): string
    {
        $result = $template;
        
        foreach ($variables as $name => $value) {
            // ${変数名} 形式の置換
            $result = str_replace('${' . $name . '}', $value, $result);
            
            // テンプレートリテラル形式の置換
            $result = preg_replace('/\$\{' . preg_quote($name, '/') . '\}/', $value, $result);
            
            // 文字列連結形式の置換 "text" + varName + "text"
            $result = preg_replace('/(["\']\s*\+\s*)' . preg_quote($name, '/') . '(\s*\+\s*["\'"])/', '$1' . $value . '$2', $result);
        }
        
        return $result;
    }
    
    /**
     * JavaScript文字列内の定数を置換する
     *
     * @param string $template 置換対象の文字列
     * @param array $constants 定数の配列（定数名 => 値）
     * @return string 置換後の文字列
     */
    public function replaceConstants(string $template, array $constants): string
    {
        $result = $template;
        
        foreach ($constants as $name => $value) {
            // 定数名 形式の置換（通常の文字列置換）
            $result = str_replace($name, $value, $result);
            
            // 文字列連結形式の置換 "text" + CONSTANT + "text"
            $result = preg_replace('/(["\']\s*\+\s*)' . preg_quote($name, '/') . '(\s*\+\s*["\'"])/', '$1' . $value . '$2', $result);
        }
        
        return $result;
    }
    
    /**
     * コード内の文字列リテラルを解析して連結する
     *
     * @param string $jsCode JavaScriptコード
     * @return string|null 連結された文字列、解析失敗時はnull
     */
    public function analyze(string $jsCode): ?string
    {
        try {
            // 文字列リテラルの抽出
            if (preg_match('/^(?:[\'"](.*?)[\'"](?:\s*\+\s*)?)+$/', $jsCode, $match)) {
                // 単純な文字列リテラルまたは文字列連結
                $result = '';
                preg_match_all('/[\'"](.+?)[\'"]/s', $jsCode, $parts);
                
                foreach ($parts[1] as $part) {
                    $result .= $part;
                }
                
                return $result;
            }
            
            // 変数と定数を置換
            $result = $jsCode;
            $result = $this->replaceVariables($result, $this->variables);
            $result = $this->replaceConstants($result, $this->constants);
            
            return $result;
        } catch (\Exception $e) {
            if ($this->errorHandler) {
                $this->errorHandler->handle('Error analyzing JS string: ' . $e->getMessage());
            }
            return null;
        }
    }
} 