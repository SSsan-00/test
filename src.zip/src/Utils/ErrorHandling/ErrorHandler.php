<?php
declare(strict_types=1);

namespace App\Utils\ErrorHandling;

/**
 * エラーハンドリングを担当するクラス
 * 
 * エラーメッセージを収集し、標準エラー出力に表示する。
 */
class ErrorHandler
{
    /**
     * エラーメッセージの配列
     * @var array
     */
    private array $errors = [];
    
    /**
     * エラーを処理する
     * 
     * @param string $message エラーメッセージ
     * @param array $context 追加のコンテキスト情報
     * @return void
     */
    public function handle(string $message, array $context = []): void
    {
        $this->errors[] = [
            'message' => $message,
            'context' => $context,
        ];
        
        // 標準エラー出力にエラーメッセージを出力
        fwrite(STDERR, "[WARN] " . $message . "\n");
    }
    
    /**
     * 収集されたすべてのエラーを取得する
     * 
     * @return array エラーの配列
     */
    public function getErrors(): array
    {
        return $this->errors;
    }
    
    /**
     * エラーが発生したかどうかをチェックする
     * 
     * @return bool エラーがある場合はtrue
     */
    public function hasErrors(): bool
    {
        return !empty($this->errors);
    }
    
    /**
     * エラーをクリアする
     * 
     * @return void
     */
    public function clearErrors(): void
    {
        $this->errors = [];
    }
} 