<?php
declare(strict_types=1);

namespace App\Utils\FileManagement;

use RuntimeException;

/**
 * ファイルの読み込みを行うクラス
 */
class FileLoader
{
    /**
     * ファイルを読み込んで行単位で返す
     *
     * @param string $filePath ファイルパス
     * @return array ファイルの各行を格納した配列
     * @throws RuntimeException ファイルが読み込めない場合
     */
    public static function readLines(string $filePath): array
    {
        if (!file_exists($filePath)) {
            throw new RuntimeException("File not found: {$filePath}");
        }
        
        $content = file_get_contents($filePath);
        if ($content === false) {
            throw new RuntimeException("Could not read file: {$filePath}");
        }
        
        // 改行コードを統一してから分割
        $content = str_replace(["\r\n", "\r"], "\n", $content);
        $lines = explode("\n", $content);
        
        // 空行と空白のみの行を除去し、前後の空白をトリム
        return array_values(array_filter(array_map('trim', $lines), function($line) {
            return $line !== '';
        }));
    }
    
    /**
     * 指定されたディレクトリから再帰的にファイルを取得
     *
     * @param string $directory 検索対象のディレクトリ
     * @param array $extensions 取得する拡張子の配列
     * @return array ファイルパスの配列
     */
    public static function getFilesRecursively(string $directory, array $extensions = []): array
    {
        $files = [];
        
        if (!is_dir($directory)) {
            return [];
        }
        
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator(
                $directory,
                \FilesystemIterator::SKIP_DOTS | \FilesystemIterator::FOLLOW_SYMLINKS
            )
        );
        
        foreach ($iterator as $info) {
            if ($info->isFile()) {
                $extension = strtolower(pathinfo($info->getPathname(), PATHINFO_EXTENSION));
                
                // 拡張子のフィルタリング
                if (empty($extensions) || in_array($extension, $extensions, true)) {
                    $files[] = $info->getPathname();
                }
            }
        }
        
        // ソートしてファイル名の昇順に
        sort($files);
        
        return $files;
    }
    
    /**
     * ファイルの内容を読み込む
     *
     * @param string $filePath ファイルパス
     * @return string ファイルの内容
     * @throws \RuntimeException ファイルが存在しないか読み込めない場合
     */
    public static function readFile(string $filePath): string
    {
        if (!file_exists($filePath)) {
            throw new \RuntimeException("File not found: {$filePath}");
        }
        
        $content = file_get_contents($filePath);
        if ($content === false) {
            throw new \RuntimeException("Failed to read file: {$filePath}");
        }
        
        return $content;
    }
} 