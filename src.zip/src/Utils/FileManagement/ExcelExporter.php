<?php
declare(strict_types=1);

namespace App\Utils\FileManagement;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use RuntimeException;

/**
 * Excel出力を行うクラス
 */
class ExcelExporter
{
    /**
     * スプレッドシートオブジェクト
     */
    private Spreadsheet $spreadsheet;
    
    /**
     * 現在のシート
     */
    private ?Worksheet $currentSheet = null;
    
    /**
     * コンストラクタ
     */
    public function __construct()
    {
        $this->spreadsheet = new Spreadsheet();
        // デフォルトシートを削除
        $this->spreadsheet->removeSheetByIndex(0);
    }
    
    /**
     * 新しいシートを作成
     *
     * @param string $name シート名
     * @return Worksheet 作成されたシート
     */
    public function createSheet(string $name): Worksheet
    {
        $sheet = new Worksheet($this->spreadsheet, $name);
        $this->spreadsheet->addSheet($sheet);
        $this->currentSheet = $sheet;
        
        // ヘッダースタイルを設定
        $sheet->getStyle('A1:Z1')->getFont()->setBold(true);
        $sheet->getStyle('A1:Z1')->getFill()
            ->setFillType(Fill::FILL_SOLID)
            ->getStartColor()->setRGB('DDDDDD');
            
        return $sheet;
    }
    
    /**
     * ヘッダー行を設定
     *
     * @param array $headers ヘッダー名の配列
     * @return void
     */
    public function setHeaders(array $headers): void
    {
        if ($this->currentSheet === null) {
            throw new RuntimeException('No active sheet.');
        }
        
        $col = 1;
        foreach ($headers as $header) {
            $cellCoord = Coordinate::stringFromColumnIndex($col) . '1';
            $this->currentSheet->setCellValue($cellCoord, $header);
            $col++;
        }
        
        // 自動フィルター設定
        $lastCol = Coordinate::stringFromColumnIndex(count($headers));
        $this->currentSheet->setAutoFilter("A1:{$lastCol}1");
    }
    
    /**
     * データ行を追加
     *
     * @param array $data データの配列
     * @return void
     */
    public function addRow(array $data): void
    {
        if ($this->currentSheet === null) {
            throw new RuntimeException('No active sheet.');
        }
        
        // 次の行番号を取得
        $row = $this->currentSheet->getHighestRow() + 1;
        
        $col = 1;
        foreach ($data as $value) {
            $cellCoord = Coordinate::stringFromColumnIndex($col) . $row;
            $this->currentSheet->setCellValue($cellCoord, $value);
            $col++;
        }
    }
    
    /**
     * 空行を追加
     *
     * @return void
     */
    public function addEmptyRow(): void
    {
        if ($this->currentSheet === null) {
            throw new RuntimeException('No active sheet.');
        }
        
        // 次の行番号を取得してスキップ
        $this->currentSheet->getHighestRow() + 1;
    }
    
    /**
     * 列幅を最適化
     *
     * @return void
     */
    public function autoSizeColumns(): void
    {
        if ($this->currentSheet === null) {
            throw new RuntimeException('No active sheet.');
        }
        
        $highestColumn = $this->currentSheet->getHighestColumn();
        $columnIndex = Coordinate::columnIndexFromString($highestColumn);
        
        for ($col = 1; $col <= $columnIndex; $col++) {
            $column = Coordinate::stringFromColumnIndex($col);
            $this->currentSheet->getColumnDimension($column)->setAutoSize(true);
        }
    }
    
    /**
     * Excelファイルとして保存
     *
     * @param string $filePath 保存先のファイルパス
     * @return void
     */
    public function save(string $filePath): void
    {
        // 出力ディレクトリが存在しない場合は作成
        $directory = dirname($filePath);
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }
        
        $writer = new Xlsx($this->spreadsheet);
        $writer->save($filePath);
    }
    
    /**
     * スプレッドシートオブジェクトを取得
     *
     * @return Spreadsheet スプレッドシートオブジェクト
     */
    public function getSpreadsheet(): Spreadsheet
    {
        return $this->spreadsheet;
    }
} 