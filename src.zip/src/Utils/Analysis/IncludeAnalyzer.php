<?php
declare(strict_types=1);

namespace App\Utils\Analysis;

use PhpParser\Node;
use PhpParser\Node\Expr\Include_;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;
use PhpParser\ParserFactory;
use RuntimeException;
use App\Utils\StringAnalysis\StringAnalyzer;
use App\PhpParser\ParserAdapter;
use PhpParser\Node\Expr\BinaryOp\Concat;
use PhpParser\Node\Scalar\String_;
use PhpParser\Node\Expr\Variable;
use App\Utils\ErrorHandling\ErrorHandler;

/**
 * インクルード解析用のノードビジター
 */
class IncludeVisitor extends NodeVisitorAbstract
{
    private array $includes = [];
    private StringAnalyzer $stringAnalyzer;
    private int $currentDepth = 0;
    private int $maxDepth;
    
    public function __construct(int $maxDepth = 5)
    {
        $this->stringAnalyzer = new StringAnalyzer();
        $this->maxDepth = $maxDepth;
    }
    
    public function beforeTraverse(array $nodes)
    {
        $this->includes = [];
        $this->currentDepth = 0;
        return null;
    }
    
    public function enterNode(Node $node)
    {
        if ($node instanceof Include_) {
            $expr = $node->expr;
            $path = $this->stringAnalyzer->analyze($expr);
            
            if ($path !== null) {
                $this->includes[] = [
                    'path' => $path,
                    'depth' => $this->currentDepth,
                    'line' => $node->getLine(),
                    'type' => $this->getIncludeType($node)
                ];
                
                // 深さが最大値未満なら再帰的に解析
                if ($this->currentDepth < $this->maxDepth) {
                    $this->analyzeIncludedFile($path);
                }
            }
        }
        
        return null;
    }
    
    private function analyzeIncludedFile(string $path): void
    {
        // 相対パスを解決
        $realPath = $this->resolvePath($path);
        if (!file_exists($realPath)) {
            return;
        }
        
        try {
            $code = file_get_contents($realPath);
            if ($code === false) {
                return;
            }
            
            $parser = ParserAdapter::createParser();
            $ast = $parser->parse($code);
            
            if ($ast !== null) {
                $this->currentDepth++;
                $traverser = new NodeTraverser();
                $traverser->addVisitor($this);
                $traverser->traverse($ast);
                $this->currentDepth--;
            }
        } catch (\Exception $e) {
            // インクルードファイルの解析に失敗しても処理を継続
        }
    }
    
    private function resolvePath(string $path): string
    {
        // 現在のスクリプトからの相対パスを解決
        if (strpos($path, '/') !== 0) {
            return dirname(__FILE__) . '/' . $path;
        }
        
        return $path;
    }
    
    private function getIncludeType(Include_ $node): string
    {
        switch ($node->type) {
            case Include_::TYPE_INCLUDE:
                return 'include';
            case Include_::TYPE_INCLUDE_ONCE:
                return 'include_once';
            case Include_::TYPE_REQUIRE:
                return 'require';
            case Include_::TYPE_REQUIRE_ONCE:
                return 'require_once';
            default:
                return 'unknown';
        }
    }
    
    public function getIncludes(): array
    {
        return $this->includes;
    }
}

/**
 * インクルードを解析するクラス
 */
class IncludeAnalyzer
{
    /**
     * インクルード解析の最大深さ
     */
    private int $maxDepth;
    
    /**
     * 文字列解析ツール
     */
    private StringAnalyzer $stringAnalyzer;
    
    /**
     * エラーハンドラ
     */
    private ?ErrorHandler $errorHandler;
    
    /**
     * 解析済みのファイル
     */
    private array $analyzedFiles = [];
    
    /**
     * コンストラクタ
     */
    public function __construct(int $maxDepth = 5, ?ErrorHandler $errorHandler = null)
    {
        $this->maxDepth = $maxDepth;
        $this->stringAnalyzer = new StringAnalyzer($errorHandler);
        $this->errorHandler = $errorHandler;
    }
    
    /**
     * ファイルを解析してインクルード情報を取得
     *
     * @param string $filePath 解析対象のファイルパス
     * @return array インクルード情報の配列
     */
    public function analyzeFile(string $filePath): array
    {
        if (!file_exists($filePath)) {
            if ($this->errorHandler) {
                $this->errorHandler->handle("File not found: $filePath");
            }
            return [];
        }
        
        $code = file_get_contents($filePath);
        if ($code === false) {
            if ($this->errorHandler) {
                $this->errorHandler->handle("Could not read file: $filePath");
            }
            return [];
        }
        
        $baseDir = dirname($filePath);
        $includes = $this->analyze($code);
        
        // 相対パスの解決とファイル存在チェック
        foreach ($includes as $key => $include) {
            $path = $include['path'];
            
            // 絶対パスかどうかチェック
            if (!$this->isAbsolutePath($path)) {
                // 相対パスを絶対パスに変換
                $absolutePath = $this->resolveRelativePath($baseDir, $path);
                $includes[$key]['absolute_path'] = $absolutePath;
                $includes[$key]['exists'] = file_exists($absolutePath);
            } else {
                $includes[$key]['absolute_path'] = $path;
                $includes[$key]['exists'] = file_exists($path);
            }
        }
        
        // 深さ1のインクルードを記録
        $this->analyzedFiles[] = $filePath;
        
        // 再帰的にインクルードを解析
        $this->analyzeIncludesRecursively($includes, $baseDir, 1);
        
        return $includes;
    }
    
    /**
     * 再帰的にインクルードを解析
     */
    private function analyzeIncludesRecursively(array &$includes, string $baseDir, int $currentDepth): void
    {
        // 深さの上限を設定（無限ループ防止）
        if ($currentDepth >= 10) {
            return;
        }
        
        $newIncludes = [];
        
        foreach ($includes as $include) {
            if (isset($include['exists']) && $include['exists'] && isset($include['absolute_path'])) {
                $includedFilePath = $include['absolute_path'];
                
                // 循環参照を防止
                if (in_array($includedFilePath, $this->analyzedFiles)) {
                    continue;
                }
                
                $this->analyzedFiles[] = $includedFilePath;
                
                // インクルードされたファイルを解析
                $code = file_get_contents($includedFilePath);
                if ($code !== false) {
                    $nextIncludes = $this->analyze($code);
                    
                    // 相対パスの解決とファイル存在チェック
                    $includedBaseDir = dirname($includedFilePath);
                    foreach ($nextIncludes as $key => $nextInclude) {
                        $path = $nextInclude['path'];
                        $nextIncludes[$key]['depth'] = $currentDepth + 1;
                        
                        // 絶対パスかどうかチェック
                        if (!$this->isAbsolutePath($path)) {
                            // 相対パスを絶対パスに変換
                            $absolutePath = $this->resolveRelativePath($includedBaseDir, $path);
                            $nextIncludes[$key]['absolute_path'] = $absolutePath;
                            $nextIncludes[$key]['exists'] = file_exists($absolutePath);
                        } else {
                            $nextIncludes[$key]['absolute_path'] = $path;
                            $nextIncludes[$key]['exists'] = file_exists($path);
                        }
                    }
                    
                    $newIncludes = array_merge($newIncludes, $nextIncludes);
                }
            }
        }
        
        if (!empty($newIncludes)) {
            // 新しく見つかったインクルードをマージ
            $includes = array_merge($includes, $newIncludes);
            
            // 次の階層を解析
            $this->analyzeIncludesRecursively($newIncludes, $baseDir, $currentDepth + 1);
        }
    }
    
    /**
     * コードを解析してインクルード情報を取得
     *
     * @param string $code 解析対象のコード
     * @return array インクルード情報の配列
     */
    public function analyze(string $code): array
    {
        $includes = [];
        
        // PHP-Parser を使用した解析
        try {
            $parser = (new ParserFactory)->createForNewestSupportedVersion();
            $ast = $parser->parse($code);
            
            if ($ast !== null) {
                $traverser = new NodeTraverser();
                $visitor = new IncludeVisitor($this->maxDepth);
                
                $traverser->addVisitor($visitor);
                $traverser->traverse($ast);
                
                $includes = $visitor->getIncludes();
            }
        } catch (\Exception $e) {
            if ($this->errorHandler) {
                $this->errorHandler->handle('AST解析エラー: ' . $e->getMessage());
            }
            
            // 正規表現による解析へのフォールバック
            $includes = $this->fallbackAnalyze($code);
        }
        
        // インクルードが見つからなかった場合も正規表現での抽出を試みる
        if (empty($includes)) {
            $includes = $this->fallbackAnalyze($code);
        }
        
        return $includes;
    }
    
    /**
     * 正規表現を使ったフォールバック解析
     */
    private function fallbackAnalyze(string $code): array
    {
        $includes = [];
        
        // include/require パターン
        $patterns = [
            // include 'file.php';
            '/include\s+[\'"](.*?)[\'"]\s*;/i',
            // include("file.php");
            '/include\s*\(\s*[\'"](.*?)[\'"]\s*\)\s*;/i',
            // require 'file.php';
            '/require\s+[\'"](.*?)[\'"]\s*;/i',
            // require("file.php");
            '/require\s*\(\s*[\'"](.*?)[\'"]\s*\)\s*;/i',
            // include_once 'file.php';
            '/include_once\s+[\'"](.*?)[\'"]\s*;/i',
            // include_once("file.php");
            '/include_once\s*\(\s*[\'"](.*?)[\'"]\s*\)\s*;/i',
            // require_once 'file.php';
            '/require_once\s+[\'"](.*?)[\'"]\s*;/i',
            // require_once("file.php");
            '/require_once\s*\(\s*[\'"](.*?)[\'"]\s*\)\s*;/i',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $code, $matches)) {
                foreach ($matches[1] as $path) {
                    $includes[] = [
                        'path' => $path,
                        'depth' => 1
                    ];
                }
            }
        }
        
        // 変数を使ったインクルード
        $varPatterns = [
            // include $file;
            '/include\s+\$(.*?)\s*;/i',
            // include($file);
            '/include\s*\(\s*\$(.*?)\s*\)\s*;/i',
            // require $file;
            '/require\s+\$(.*?)\s*;/i',
            // require($file);
            '/require\s*\(\s*\$(.*?)\s*\)\s*;/i',
            // include_once $file;
            '/include_once\s+\$(.*?)\s*;/i',
            // include_once($file);
            '/include_once\s*\(\s*\$(.*?)\s*\)\s*;/i',
            // require_once $file;
            '/require_once\s+\$(.*?)\s*;/i',
            // require_once($file);
            '/require_once\s*\(\s*\$(.*?)\s*\)\s*;/i',
        ];
        
        foreach ($varPatterns as $pattern) {
            if (preg_match_all($pattern, $code, $matches)) {
                foreach ($matches[1] as $varName) {
                    // 変数の値を検索
                    if (preg_match('/\$' . $varName . '\s*=\s*[\'"](.*?)[\'"]\s*;/i', $code, $varMatch)) {
                        $includes[] = [
                            'path' => $varMatch[1],
                            'depth' => 1
                        ];
                    }
                }
            }
        }
        
        // 文字列連結を使ったインクルード
        $concatPatterns = [
            // include $dir . '/file.php';
            '/include\s+\$(.*?)\s*\.\s*[\'"](.*?)[\'"]\s*;/i',
            // include($dir . '/file.php');
            '/include\s*\(\s*\$(.*?)\s*\.\s*[\'"](.*?)[\'"]\s*\)\s*;/i',
            // require $dir . '/file.php';
            '/require\s+\$(.*?)\s*\.\s*[\'"](.*?)[\'"]\s*;/i',
            // require($dir . '/file.php');
            '/require\s*\(\s*\$(.*?)\s*\.\s*[\'"](.*?)[\'"]\s*\)\s*;/i',
        ];
        
        foreach ($concatPatterns as $pattern) {
            if (preg_match_all($pattern, $code, $matches)) {
                for ($i = 0; $i < count($matches[1]); $i++) {
                    $varName = $matches[1][$i];
                    $path = $matches[2][$i];
                    
                    // 変数の値を検索
                    if (preg_match('/\$' . $varName . '\s*=\s*[\'"](.*?)[\'"]\s*;/i', $code, $varMatch)) {
                        $fullPath = $varMatch[1] . $path;
                        $includes[] = [
                            'path' => $fullPath,
                            'depth' => 1
                        ];
                    }
                }
            }
        }
        
        return $includes;
    }
    
    /**
     * パスが絶対パスかどうかをチェック
     */
    private function isAbsolutePath(string $path): bool
    {
        // Unix系絶対パス
        if (strpos($path, '/') === 0) {
            return true;
        }
        
        // Windows系絶対パス
        if (preg_match('/^[A-Z]:\\\\/i', $path)) {
            return true;
        }
        
        // Webルートからの絶対パス
        if (strpos($path, 'http://') === 0 || strpos($path, 'https://') === 0) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 相対パスを解決
     */
    private function resolveRelativePath(string $baseDir, string $relativePath): string
    {
        // ドキュメントルートからの相対パスの場合
        if (strpos($relativePath, $_SERVER['DOCUMENT_ROOT'] ?? '') === 0) {
            return $relativePath;
        }
        
        // ./ で始まる場合
        if (strpos($relativePath, './') === 0) {
            $relativePath = substr($relativePath, 2);
        }
        
        // 複数の ../ を解決
        if (strpos($relativePath, '../') !== false) {
            $parts = explode('/', $relativePath);
            $result = explode('/', $baseDir);
            
            foreach ($parts as $part) {
                if ($part === '..') {
                    array_pop($result);
                } else {
                    $result[] = $part;
                }
            }
            
            return implode('/', $result);
        }
        
        return $baseDir . '/' . $relativePath;
    }
    
    /**
     * 文字列解析ツールを設定
     */
    public function setStringAnalyzer(StringAnalyzer $analyzer): void
    {
        $this->stringAnalyzer = $analyzer;
    }
} 