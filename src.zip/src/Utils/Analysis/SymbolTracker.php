<?php

namespace App\Utils\Analysis;

use PhpParser\Node;
use PhpParser\Node\Expr\Variable;
use PhpParser\Node\Stmt\Const_;

class SymbolTracker
{
    private array $variables = [];
    private array $constants = [];
    private array $variableHistory = [];
    private array $constantHistory = [];

    public function track(Node $node): void
    {
        if ($node instanceof Variable) {
            $this->trackVariable($node);
        } elseif ($node instanceof Const_) {
            $this->trackConstant($node);
        }
    }

    public function setVariable(string $name, $value): void
    {
        $this->variables[$name] = $value;
        $this->variableHistory[$name][] = [
            'value' => $value,
            'timestamp' => microtime(true)
        ];
    }

    public function setConstant(string $name, $value): void
    {
        $this->constants[$name] = $value;
        $this->constantHistory[$name][] = [
            'value' => $value,
            'timestamp' => microtime(true)
        ];
    }

    public function getVariable(string $name): ?string
    {
        return $this->variables[$name] ?? null;
    }

    public function getConstant(string $name): ?string
    {
        return $this->constants[$name] ?? null;
    }

    public function getVariableHistory(string $name): array
    {
        return $this->variableHistory[$name] ?? [];
    }

    public function getConstantHistory(string $name): array
    {
        return $this->constantHistory[$name] ?? [];
    }

    private function trackVariable(Variable $node): void
    {
        if (!is_string($node->name)) {
            return;
        }
        // 変数の追跡ロジック
    }

    private function trackConstant(Const_ $node): void
    {
        foreach ($node->consts as $const) {
            $this->constants[$const->name->name] = $const->value->value ?? '';
        }
    }

    public function clear(): void
    {
        $this->variables = [];
        $this->constants = [];
        $this->variableHistory = [];
        $this->constantHistory = [];
    }
} 