<?php
declare(strict_types=1);

namespace App\Utils\Analysis;

/**
 * SQLクエリを検出するクラス
 */
class SqlDetector
{
    /**
     * SQLクエリかどうか判定する
     *
     * @param string $text 判定対象のテキスト
     * @return bool SQLクエリの場合true
     */
    public function detect(string $text): bool
    {
        // トリミングして大文字に変換
        $normalizedText = trim(strtoupper($text));
        
        // SQLキーワードで始まるかチェック
        $sqlStartKeywords = [
            'SELECT', 'INSERT', 'UPDATE', 'DELETE', 
            'CREATE', 'ALTER', 'DROP', 'TRUNCATE',
            'WITH', 'CALL'
        ];
        
        foreach ($sqlStartKeywords as $keyword) {
            if (strpos($normalizedText, $keyword) === 0) {
                return true;
            }
        }
        
        // 他のSQLパターンチェック
        $sqlPatterns = [
            // JOINを含む
            '/\s+JOIN\s+/i',
            // WHERE句を含む
            '/\s+WHERE\s+/i',
            // ORDER BY句を含む
            '/\s+ORDER\s+BY\s+/i',
            // GROUP BY句を含む
            '/\s+GROUP\s+BY\s+/i',
            // HAVING句を含む
            '/\s+HAVING\s+/i',
            // FROM句を含む（SELECT後に通常あるパターン）
            '/\s+FROM\s+/i'
        ];
        
        foreach ($sqlPatterns as $pattern) {
            if (preg_match($pattern, $normalizedText)) {
                return true;
            }
        }
        
        return false;
    }
} 