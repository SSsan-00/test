<?php
declare(strict_types=1);

namespace App\Utils\Analysis;

use PhpParser\Node;
use PhpParser\Node\Expr\FuncCall;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;
use PhpParser\ParserFactory;
use RuntimeException;
use App\Utils\StringAnalysis\StringAnalyzer;
use App\PhpParser\ParserAdapter;
use PhpParser\Node\Expr\MethodCall;
use PhpParser\Node\Expr\Variable;
use App\Utils\ErrorHandling\ErrorHandler;

/**
 * ストアドプロシージャ解析用のノードビジター
 */
class StoredProcedureVisitor extends NodeVisitorAbstract
{
    private array $procedures = [];
    private StringAnalyzer $stringAnalyzer;
    private array $storedProcList;
    
    public function __construct(array $storedProcList)
    {
        $this->stringAnalyzer = new StringAnalyzer();
        $this->storedProcList = array_map('strtolower', $storedProcList);
    }
    
    public function enterNode(Node $node)
    {
        // 関数呼び出しを処理
        if ($node instanceof FuncCall) {
            if ($node->name instanceof Node\Name) {
                $funcName = strtolower($node->name->toString());
                
                // ストアドプロシージャ呼び出しの可能性がある関数名
                if (in_array($funcName, ['pg_query', 'pg_exec', 'pg_execute', 'pg_send_query', 'mysqli_query', 'mysql_query'])) {
                    if (isset($node->args[1])) {
                        $sql = $this->stringAnalyzer->analyze($node->args[1]->value);
                        $this->checkForProcedureCalls($sql, $node->getLine());
                    } else if (isset($node->args[0])) {
                        $sql = $this->stringAnalyzer->analyze($node->args[0]->value);
                        $this->checkForProcedureCalls($sql, $node->getLine());
                    }
                }
            }
            
            // 直接的なストアドプロシージャ呼び出し関数（仮名）
            if ($node->name instanceof Node\Name && in_array(strtolower($node->name->toString()), ['call_procedure', 'execute_proc'])) {
                if (isset($node->args[0])) {
                    $procName = $this->stringAnalyzer->analyze($node->args[0]->value);
                    if ($procName !== null && in_array(strtolower($procName), $this->storedProcList)) {
                        $args = '';
                        if (isset($node->args[1])) {
                            $args = $this->stringAnalyzer->analyze($node->args[1]->value) ?? '';
                        }
                        
                        $this->procedures[] = [
                            'name' => $procName,
                            'args' => $args,
                            'line' => $node->getLine()
                        ];
                    }
                }
            }
        }
        
        return null;
    }
    
    private function checkForProcedureCalls(?string $sql, int $line): void
    {
        if ($sql === null) {
            return;
        }
        
        // CALL文の検出
        if (preg_match('/CALL\s+([a-zA-Z0-9_]+)(?:\s*\(([^)]*)\))?/i', $sql, $matches)) {
            $procName = $matches[1];
            $args = isset($matches[2]) ? $matches[2] : '';
            
            if (in_array(strtolower($procName), $this->storedProcList)) {
                $this->procedures[] = [
                    'name' => $procName,
                    'args' => $args,
                    'line' => $line
                ];
            }
        }
        
        // SELECT * FROM procedure()の形式
        if (preg_match('/SELECT\s+.*\s+FROM\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\)/i', $sql, $matches)) {
            $procName = $matches[1];
            $args = isset($matches[2]) ? $matches[2] : '';
            
            if (in_array(strtolower($procName), $this->storedProcList)) {
                $this->procedures[] = [
                    'name' => $procName,
                    'args' => $args,
                    'line' => $line
                ];
            }
        }
    }
    
    public function getProcedures(): array
    {
        return $this->procedures;
    }
}

/**
 * ストアドプロシージャを解析するクラス
 */
class StoredProcedureAnalyzer
{
    /**
     * ストアドプロシージャのリスト
     */
    private array $storedProcedures;
    
    /**
     * 文字列解析ツール
     */
    private StringAnalyzer $stringAnalyzer;
    
    /**
     * エラーハンドラ
     */
    private ?ErrorHandler $errorHandler;
    
    /**
     * コンストラクタ
     *
     * @param array $storedProcedures ストアドプロシージャのリスト
     * @param ErrorHandler|null $errorHandler エラーハンドラ
     */
    public function __construct(array $storedProcedures, ?ErrorHandler $errorHandler = null)
    {
        $this->storedProcedures = $storedProcedures;
        $this->stringAnalyzer = new StringAnalyzer($errorHandler);
        $this->errorHandler = $errorHandler;
    }
    
    /**
     * ファイルを解析してストアドプロシージャ情報を取得
     *
     * @param string $file 解析対象のファイルパス
     * @return array ストアドプロシージャ情報の配列
     */
    public function analyzeFile(string $file): array
    {
        if (!file_exists($file)) {
            if ($this->errorHandler) {
                $this->errorHandler->handle("File not found: $file");
            }
            return [];
        }
        
        $code = file_get_contents($file);
        if ($code === false) {
            if ($this->errorHandler) {
                $this->errorHandler->handle("Could not read file: $file");
            }
            return [];
        }
        
        return $this->analyze($code);
    }
    
    /**
     * コードを解析してストアドプロシージャ情報を取得
     *
     * @param string $code 解析対象のコード
     * @return array ストアドプロシージャ情報の配列
     */
    public function analyze(string $code): array
    {
        $procedures = [];
        
        // PHP-Parser を使用した解析
        try {
            $parser = (new ParserFactory)->createForNewestSupportedVersion();
            $ast = $parser->parse($code);
            
            if ($ast !== null) {
                // シンボルテーブルの構築
                $this->extractVariablesFromCode($code);
                
                // ストアドプロシージャ呼び出しを検索
                $this->findStoredProcedureCalls($code, $procedures);
            }
        } catch (\Exception $e) {
            if ($this->errorHandler) {
                $this->errorHandler->handle('AST解析エラー: ' . $e->getMessage());
            }
            
            // 正規表現による解析へのフォールバック
            $procedures = $this->fallbackAnalyze($code);
        }
        
        // ストアドプロシージャが見つからなかった場合も正規表現での抽出を試みる
        if (empty($procedures)) {
            $procedures = $this->fallbackAnalyze($code);
        }
        
        return $procedures;
    }
    
    /**
     * ストアドプロシージャ呼び出しを検索
     */
    private function findStoredProcedureCalls(string $code, array &$procedures): void
    {
        // CALL プロシージャ名(引数) パターン
        if (preg_match_all('/CALL\s+([a-zA-Z0-9_]+)\s*\((.*?)\)/is', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $procName = $match[1];
                $args = $match[2];
                
                if ($this->isProcedureInList($procName)) {
                    $procedures[] = [
                        'name' => $procName,
                        'args' => $args
                    ];
                }
            }
        }
        
        // {call プロシージャ名(引数)} パターン
        if (preg_match_all('/\{call\s+([a-zA-Z0-9_]+)\s*\((.*?)\)\}/is', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $procName = $match[1];
                $args = $match[2];
                
                if ($this->isProcedureInList($procName)) {
                    $procedures[] = [
                        'name' => $procName,
                        'args' => $args
                    ];
                }
            }
        }
        
        // EXECUTE プロシージャ名 引数 パターン
        if (preg_match_all('/EXECUTE\s+([a-zA-Z0-9_]+)\s+(.*?)(?:;|$)/is', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $procName = $match[1];
                $args = $match[2];
                
                if ($this->isProcedureInList($procName)) {
                    $procedures[] = [
                        'name' => $procName,
                        'args' => $args
                    ];
                }
            }
        }
    }
    
    /**
     * PHPコードから変数とその値を抽出する
     */
    private function extractVariablesFromCode(string $code): void
    {
        $variables = $this->stringAnalyzer->extractVariablesFromCode($code);
        foreach ($variables as $name => $value) {
            $this->stringAnalyzer->setVariable($name, $value);
        }
    }
    
    /**
     * 正規表現を使ったフォールバック解析
     */
    private function fallbackAnalyze(string $code): array
    {
        $procedures = [];
        
        // PDO::prepare パターン
        // $stmt = $pdo->prepare("CALL proc_name(arg1, arg2)");
        if (preg_match_all('/->prepare\s*\(\s*[\'"](?:.*?)CALL\s+([a-zA-Z0-9_]+)\s*\((.*?)\)[\'"]/', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $procName = $match[1];
                $args = $match[2];
                
                if ($this->isProcedureInList($procName)) {
                    $procedures[] = [
                        'name' => $procName,
                        'args' => $args
                    ];
                }
            }
        }
        
        // PDO::exec パターン
        // $pdo->exec("CALL proc_name(arg1, arg2)");
        if (preg_match_all('/->exec\s*\(\s*[\'"](?:.*?)CALL\s+([a-zA-Z0-9_]+)\s*\((.*?)\)[\'"]/', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $procName = $match[1];
                $args = $match[2];
                
                if ($this->isProcedureInList($procName)) {
                    $procedures[] = [
                        'name' => $procName,
                        'args' => $args
                    ];
                }
            }
        }
        
        // PDO::query パターン
        // $pdo->query("CALL proc_name(arg1, arg2)");
        if (preg_match_all('/->query\s*\(\s*[\'"](?:.*?)CALL\s+([a-zA-Z0-9_]+)\s*\((.*?)\)[\'"]/', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $procName = $match[1];
                $args = $match[2];
                
                if ($this->isProcedureInList($procName)) {
                    $procedures[] = [
                        'name' => $procName,
                        'args' => $args
                    ];
                }
            }
        }
        
        // 変数に格納されたSQLの場合
        if (preg_match_all('/\$([a-zA-Z0-9_]+)\s*=\s*[\'"](?:.*?)CALL\s+([a-zA-Z0-9_]+)\s*\((.*?)\)[\'"]/', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $procName = $match[2];
                $args = $match[3];
                
                if ($this->isProcedureInList($procName)) {
                    $procedures[] = [
                        'name' => $procName,
                        'args' => $args
                    ];
                }
            }
        }
        
        // {call 形式}
        if (preg_match_all('/[\'"](?:.*?)\{call\s+([a-zA-Z0-9_]+)\s*\((.*?)\)\}[\'"]/', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $procName = $match[1];
                $args = $match[2];
                
                if ($this->isProcedureInList($procName)) {
                    $procedures[] = [
                        'name' => $procName,
                        'args' => $args
                    ];
                }
            }
        }
        
        // EXECUTE 形式
        if (preg_match_all('/[\'"](?:.*?)EXECUTE\s+([a-zA-Z0-9_]+)\s+(.*?)(?:;|$)[\'"]/', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $procName = $match[1];
                $args = $match[2];
                
                if ($this->isProcedureInList($procName)) {
                    $procedures[] = [
                        'name' => $procName,
                        'args' => $args
                    ];
                }
            }
        }
        
        return $procedures;
    }
    
    /**
     * ストアドプロシージャ名がリストに含まれているかチェック
     */
    private function isProcedureInList(string $name): bool
    {
        if (empty($this->storedProcedures)) {
            // リストが空の場合は全て許可
            return true;
        }
        
        return in_array($name, $this->storedProcedures);
    }
    
    /**
     * ストアドプロシージャを追加
     *
     * @param string $name ストアドプロシージャ名
     */
    public function addProcedure(string $name): void
    {
        if (!in_array($name, $this->storedProcedures)) {
            $this->storedProcedures[] = $name;
        }
    }
    
    /**
     * 登録済みストアドプロシージャ名のリストを取得
     *
     * @return array ストアドプロシージャ名の配列
     */
    public function getProcedures(): array
    {
        return $this->storedProcedures;
    }
    
    /**
     * 登録済みストアドプロシージャ名のリストを設定
     *
     * @param array $procedures ストアドプロシージャ名の配列
     */
    public function setProcedures(array $procedures): void
    {
        $this->storedProcedures = $procedures;
    }
    
    /**
     * 文字列解析ツールを設定
     *
     * @param StringAnalyzer $analyzer 文字列解析ツール
     */
    public function setStringAnalyzer(StringAnalyzer $analyzer): void
    {
        $this->stringAnalyzer = $analyzer;
    }
} 