<?php

namespace App\Utils\Analysis;

class AnalysisResult
{
    private array $queries = [];
    private array $errors = [];
    private array $context = [];
    private array $variables = [];
    private array $constants = [];

    public function addQuery(string $query, array $context = []): void
    {
        $this->queries[] = [
            'query' => $query,
            'context' => $context,
            'timestamp' => microtime(true)
        ];
    }

    public function addError(string $message, array $context = []): void
    {
        $this->errors[] = [
            'message' => $message,
            'context' => $context,
            'timestamp' => microtime(true)
        ];
    }

    public function setVariable(string $name, $value): void
    {
        $this->variables[$name] = $value;
    }

    public function getVariables(): array
    {
        return $this->variables;
    }

    public function getQueries(): array
    {
        return $this->queries;
    }

    /**
     * クエリリストを新しいリストで置き換える
     *
     * @param array $queries 新しいクエリリスト
     * @return void
     */
    public function replaceQueries(array $queries): void
    {
        $this->queries = $queries;
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public function setConstant(string $name, $value): void
    {
        $this->constants[$name] = $value;
    }

    public function getConstants(): array
    {
        return $this->constants;
    }

    public function clear(): void
    {
        $this->queries = [];
        $this->errors = [];
        $this->context = [];
        $this->variables = [];
        $this->constants = [];
    }
} 