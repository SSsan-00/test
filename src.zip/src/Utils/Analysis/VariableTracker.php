<?php
declare(strict_types=1);

namespace App\Utils\Analysis;

use PhpParser\Node;
use PhpParser\Node\Expr\Assign;
use PhpParser\Node\Expr\Variable;
use App\Utils\StringAnalysis\StringAnalyzer;

/**
 * 変数の値を追跡するクラス
 */
class VariableTracker
{
    /**
     * 変数名と値のマッピング
     */
    private array $variables = [];
    
    /**
     * 文字列解析器
     */
    private StringAnalyzer $stringAnalyzer;
    
    /**
     * コンストラクタ
     */
    public function __construct()
    {
        $this->stringAnalyzer = new StringAnalyzer();
    }
    
    /**
     * ASTノードを追跡して変数を記録
     */
    public function track(Node $node): void
    {
        if ($node instanceof Assign && $node->var instanceof Variable && is_string($node->var->name)) {
            $varName = $node->var->name;
            $value = $this->stringAnalyzer->analyze($node->expr);
            
            if ($value !== null) {
                $this->variables[$varName] = $value;
            }
        }
    }
    
    /**
     * 変数の値を取得
     */
    public function getValue(string $name): ?string
    {
        return $this->variables[$name] ?? null;
    }
    
    /**
     * 変数のマッピングすべてを取得
     */
    public function getVariables(): array
    {
        return $this->variables;
    }
    
    /**
     * 変数の値を設定
     */
    public function setValue(string $name, string $value): void
    {
        $this->variables[$name] = $value;
    }
} 