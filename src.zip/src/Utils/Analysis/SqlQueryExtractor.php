<?php

namespace App\Utils\Analysis;

use PhpParser\Node;

/**
 * AST（抽象構文木）からSQL文字列を抽出するクラス
 */
class SqlQueryExtractor
{
    private array $variables = [];
    private array $queryStrings = [];
    private array $potentialSqlFragments = [];
    
    /**
     * 変数の値を設定
     *
     * @param string $name 変数名
     * @param string $value 変数の値
     */
    public function setVariable(string $name, string $value): void
    {
        $this->variables[$name] = $value;
    }
    
    /**
     * 抽出されたSQLクエリを取得
     *
     * @return array SQL文字列の配列
     */
    public function getQueries(): array
    {
        return $this->queryStrings;
    }
    
    /**
     * 潜在的なSQL構文の断片を追加
     *
     * @param string $fragment SQL構文の断片
     * @param string $varName 格納されている変数名
     */
    public function addSqlFragment(string $fragment, string $varName): void
    {
        $this->potentialSqlFragments[$varName] = $fragment;
        
        // 部分的な断片を組み合わせて完全なSQLになっていないか確認
        $this->checkCombinedFragments();
    }
    
    /**
     * SQL構文の断片を組み合わせて完全なSQLが構成できないか確認
     */
    private function checkCombinedFragments(): void
    {
        // SQLキーワードの組み合わせパターンを確認
        $selectPattern = null;
        $fromPattern = null;
        $wherePattern = null;
        
        foreach ($this->potentialSqlFragments as $varName => $fragment) {
            if (preg_match('/SELECT\s+.+/i', $fragment)) {
                $selectPattern = $fragment;
            } elseif (preg_match('/FROM\s+.+/i', $fragment)) {
                $fromPattern = $fragment;
            } elseif (preg_match('/WHERE\s+.+/i', $fragment)) {
                $wherePattern = $fragment;
            }
        }
        
        // SELECT + FROM が両方あれば、基本的なクエリとして組み合わせ可能
        if ($selectPattern !== null && $fromPattern !== null) {
            $combinedQuery = $selectPattern . ' ' . $fromPattern;
            if ($wherePattern !== null) {
                $combinedQuery .= ' ' . $wherePattern;
            }
            
            // 重複を避けて追加
            if (!in_array($combinedQuery, $this->queryStrings)) {
                $this->queryStrings[] = $combinedQuery;
            }
        }
    }
    
    /**
     * 文字列ノードからSQL文を抽出
     *
     * @param Node $node ノード
     */
    public function extract(Node $node): void
    {
        if ($node instanceof Node\Scalar\String_) {
            $this->checkAndAddQuery($node->value);
        } elseif ($node instanceof Node\Expr\BinaryOp\Concat) {
            $this->handleConcatenation($node);
        } elseif ($node instanceof Node\Expr\Variable && is_string($node->name) && isset($this->variables[$node->name])) {
            $this->checkAndAddQuery($this->variables[$node->name]);
        }
    }
    
    /**
     * 文字列連結の処理
     *
     * @param Node\Expr\BinaryOp\Concat $node 連結ノード
     */
    private function handleConcatenation(Node\Expr\BinaryOp\Concat $node): void
    {
        // 左辺の処理
        $leftValue = $this->getNodeValue($node->left);
        
        // 右辺の処理
        $rightValue = $this->getNodeValue($node->right);
        
        if ($leftValue !== null && $rightValue !== null) {
            $concatenated = $leftValue . $rightValue;
            $this->checkAndAddQuery($concatenated);
        }
    }
    
    /**
     * ノードの値を取得
     *
     * @param Node $node ノード
     * @return string|null ノードの値、取得できない場合はnull
     */
    private function getNodeValue(Node $node): ?string
    {
        if ($node instanceof Node\Scalar\String_) {
            return $node->value;
        } elseif ($node instanceof Node\Expr\Variable && is_string($node->name) && isset($this->variables[$node->name])) {
            return $this->variables[$node->name];
        } elseif ($node instanceof Node\Expr\BinaryOp\Concat) {
            $leftValue = $this->getNodeValue($node->left);
            $rightValue = $this->getNodeValue($node->right);
            
            if ($leftValue !== null && $rightValue !== null) {
                return $leftValue . $rightValue;
            }
        }
        
        // 値が取得できない場合は、空の文字列を返す代わりにnullを返す
        // これにより不完全な連結を避ける
        return null;
    }
    
    /**
     * SQL文かどうかチェックして、SQLなら追加
     *
     * @param string $str チェック対象の文字列
     */
    private function checkAndAddQuery(string $str): void
    {
        $sqlKeywords = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP', 'ALTER', 'TRUNCATE'];
        
        foreach ($sqlKeywords as $keyword) {
            if (stripos($str, $keyword) === 0) {
                // 重複チェック
                if (!in_array($str, $this->queryStrings)) {
                    $this->queryStrings[] = $str;
                }
                break;
            }
        }
    }
} 