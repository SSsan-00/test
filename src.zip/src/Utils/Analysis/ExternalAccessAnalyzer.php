<?php
declare(strict_types=1);

namespace App\Utils\Analysis;

use PhpParser\Node;
use PhpParser\Node\Expr\FuncCall;
use PhpParser\Node\Expr\MethodCall;
use PhpParser\Node\Scalar\String_;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;
use PhpParser\ParserFactory;
use RuntimeException;
use App\Utils\StringAnalysis\StringAnalyzer;
use App\PhpParser\ParserAdapter;
use App\Utils\StringAnalysis\JsStringAnalyzer;
use App\Utils\ErrorHandling\ErrorHandler;

/**
 * 外部アクセス解析用のノードビジター
 */
class ExternalAccessVisitor extends NodeVisitorAbstract
{
    private array $externalAccesses = [];
    private StringAnalyzer $stringAnalyzer;
    
    public function __construct()
    {
        $this->stringAnalyzer = new StringAnalyzer();
    }
    
    public function enterNode(Node $node)
    {
        // header関数の処理
        if ($node instanceof FuncCall && $node->name instanceof Node\Name && $node->name->toString() === 'header') {
            if (isset($node->args[0])) {
                $headerValue = $this->stringAnalyzer->analyze($node->args[0]->value);
                if ($headerValue !== null && preg_match('/^Location:\s*(.+)/i', $headerValue, $matches)) {
                    $this->externalAccesses[] = [
                        'type' => 'header',
                        'url' => trim($matches[1]),
                        'line' => $node->getLine()
                    ];
                }
            }
        }
        
        // window.open, window.location.href などのメソッド呼び出しの処理
        if ($node instanceof MethodCall) {
            $obj = $node->var;
            $methodName = $node->name;
            
            if ($obj instanceof Node\Expr\PropertyFetch && $obj->var instanceof Node\Expr\Variable) {
                $varName = $obj->var->name;
                if ($varName === 'window' && $methodName instanceof Node\Identifier && $methodName->toString() === 'open') {
                    if (isset($node->args[0])) {
                        $url = $this->stringAnalyzer->analyze($node->args[0]->value);
                        if ($url !== null) {
                            $this->externalAccesses[] = [
                                'type' => 'window.open',
                                'url' => $url,
                                'line' => $node->getLine()
                            ];
                        }
                    }
                }
            }
        }
        
        return null;
    }
    
    public function getExternalAccesses(): array
    {
        return $this->externalAccesses;
    }
}

/**
 * 外部アクセスを解析するクラス
 */
class ExternalAccessAnalyzer
{
    /**
     * 文字列解析ツール
     */
    private StringAnalyzer $stringAnalyzer;
    
    /**
     * JavaScript文字列解析ツール
     */
    private JsStringAnalyzer $jsStringAnalyzer;
    
    /**
     * エラーハンドラ
     */
    private ?ErrorHandler $errorHandler;
    
    /**
     * コンストラクタ
     */
    public function __construct(?ErrorHandler $errorHandler = null)
    {
        $this->stringAnalyzer = new StringAnalyzer($errorHandler);
        $this->jsStringAnalyzer = new JsStringAnalyzer($errorHandler);
        $this->errorHandler = $errorHandler;
    }
    
    /**
     * ファイルの内容を解析して外部アクセスを抽出
     *
     * @param string $filePath 解析対象ファイルのパス
     * @return array 外部アクセス情報の配列
     */
    public function analyzeFile(string $filePath): array
    {
        if (!file_exists($filePath)) {
            if ($this->errorHandler) {
                $this->errorHandler->handle("File not found: $filePath");
            }
            return [];
        }
        
        $content = file_get_contents($filePath);
        $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        
        switch ($fileExtension) {
            case 'php':
            case 'inc':
                return $this->analyzePhp($content);
            case 'html':
            case 'htm':
                return $this->analyzeHtml($content);
            case 'js':
                return $this->analyzeJs($content);
            default:
                // 拡張子が不明な場合はPHPとして解析を試みる
                return $this->analyzePhp($content);
        }
    }
    
    /**
     * PHPコードを解析して外部アクセスを抽出
     *
     * @param string $php PHPコード
     * @return array 外部アクセス情報の配列
     */
    public function analyzePhp(string $php): array
    {
        $accesses = [];
        
        // PHPコード内のHTMLを抽出して解析
        $this->extractAndAnalyzeHtmlFromPhp($php, $accesses);
        
        // PHPコード内のJavaScriptを抽出して解析
        $this->extractAndAnalyzeJsFromPhp($php, $accesses);
        
        // headerリダイレクトの検出
        $this->detectHeaderRedirects($php, $accesses);
        
        return $accesses;
    }
    
    /**
     * HTMLを解析して外部アクセスを抽出
     *
     * @param string $html HTMLコード
     * @return array 外部アクセス情報の配列
     */
    public function analyzeHtml(string $html): array
    {
        $accesses = [];
        
        // フォームのaction属性を抽出
        $this->extractFormActions($html, $accesses);
        
        // アンカータグのhref属性を抽出
        $this->extractAnchorHrefs($html, $accesses);
        
        // iframeのsrc属性を抽出
        $this->extractIframeSrcs($html, $accesses);
        
        // インラインJavaScriptを抽出して解析
        $this->extractAndAnalyzeInlineJs($html, $accesses);
        
        return $accesses;
    }
    
    /**
     * JavaScriptを解析して外部アクセスを抽出
     *
     * @param string $js JavaScriptコード
     * @return array 外部アクセス情報の配列
     */
    public function analyzeJs(string $js): array
    {
        $accesses = [];
        
        // document.form.action = "URL"
        $this->extractDocumentFormActions($js, $accesses);
        
        // XMLHttpRequest
        $this->extractXhrRequests($js, $accesses);
        
        // window.open("URL")
        $this->extractWindowOpen($js, $accesses);
        
        // window.location.href = "URL"
        $this->extractWindowLocation($js, $accesses);
        
        return $accesses;
    }
    
    /**
     * PHPコード内のHTMLを抽出して解析
     */
    private function extractAndAnalyzeHtmlFromPhp(string $php, array &$accesses): void
    {
        // PHPタグの外側のHTMLを抽出
        if (preg_match_all('/<\?.*?\?>(*SKIP)(*FAIL)|<[^?].*?>/s', $php, $matches)) {
            $htmlAccesses = $this->analyzeHtml($php);
            $accesses = array_merge($accesses, $htmlAccesses);
        }
        
        // echo/print文で出力されるHTMLも解析
        if (preg_match_all('/(?:echo|print)\s+(["\'])(.*?)\1/s', $php, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                if (strpos($match[2], '<') !== false) {
                    $htmlAccesses = $this->analyzeHtml($match[2]);
                    $accesses = array_merge($accesses, $htmlAccesses);
                }
            }
        }
    }
    
    /**
     * PHPコード内のJavaScriptを抽出して解析
     */
    private function extractAndAnalyzeJsFromPhp(string $php, array &$accesses): void
    {
        // <script>タグ内のJavaScriptを抽出
        if (preg_match_all('/<script[^>]*>(.*?)<\/script>/s', $php, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $jsAccesses = $this->analyzeJs($match[1]);
                $accesses = array_merge($accesses, $jsAccesses);
            }
        }
        
        // echo/print文で出力されるJavaScriptも解析
        if (preg_match_all('/(?:echo|print)\s+(["\'])<script[^>]*>(.*?)<\/script>\1/s', $php, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $jsAccesses = $this->analyzeJs($match[2]);
                $accesses = array_merge($accesses, $jsAccesses);
            }
        }
    }
    
    /**
     * HTTPヘッダーリダイレクトを検出
     */
    private function detectHeaderRedirects(string $php, array &$accesses): void
    {
        // header("Location: URL")の形式
        if (preg_match_all('/header\s*\(\s*(["\'])Location:\s*(.*?)\1/i', $php, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = trim($match[2]);
                $accesses[] = [
                    'type' => 'header',
                    'url' => $url
                ];
            }
        }
        
        // header("Location: " . $url)の形式
        if (preg_match_all('/header\s*\(\s*(["\'])Location:\s*\1\s*\.\s*(.*?)\s*\)/i', $php, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $urlExpr = $match[2];
                // 変数の解決を試みる
                if (preg_match('/\$([a-zA-Z0-9_]+)/', $urlExpr, $varMatch)) {
                    $varName = $varMatch[1];
                    
                    // 変数定義を探す簡易的な方法
                    if (preg_match('/\$' . $varName . '\s*=\s*(["\'])(.*?)\1/', $php, $defMatch)) {
                        $url = $defMatch[2];
                        $accesses[] = [
                            'type' => 'header',
                            'url' => $url
                        ];
                    }
                }
            }
        }
    }
    
    /**
     * フォームのaction属性を抽出
     */
    private function extractFormActions(string $html, array &$accesses): void
    {
        if (preg_match_all('/<form[^>]*action\s*=\s*(["\'])(.*?)\1[^>]*>/i', $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[2];
                if (!empty($url) && $url !== '#' && $url !== 'javascript:void(0)') {
                    $accesses[] = [
                        'type' => 'action',
                        'url' => $url
                    ];
                }
            }
        }
    }
    
    /**
     * アンカータグのhref属性を抽出
     */
    private function extractAnchorHrefs(string $html, array &$accesses): void
    {
        if (preg_match_all('/<a[^>]*href\s*=\s*(["\'])(.*?)\1[^>]*>/i', $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[2];
                if (!empty($url) && $url !== '#' && $url !== 'javascript:void(0)' && strpos($url, 'javascript:') !== 0) {
                    $accesses[] = [
                        'type' => 'href',
                        'url' => $url
                    ];
                }
            }
        }
    }
    
    /**
     * iframeのsrc属性を抽出
     */
    private function extractIframeSrcs(string $html, array &$accesses): void
    {
        if (preg_match_all('/<iframe[^>]*src\s*=\s*(["\'])(.*?)\1[^>]*>/i', $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[2];
                if (!empty($url) && $url !== 'about:blank') {
                    $accesses[] = [
                        'type' => 'iframe',
                        'url' => $url
                    ];
                }
            }
        }
    }
    
    /**
     * インラインJavaScriptを抽出して解析
     */
    private function extractAndAnalyzeInlineJs(string $html, array &$accesses): void
    {
        if (preg_match_all('/<script[^>]*>(.*?)<\/script>/s', $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $jsAccesses = $this->analyzeJs($match[1]);
                $accesses = array_merge($accesses, $jsAccesses);
            }
        }
    }
    
    /**
     * document.form.action = "URL"の形式を抽出
     */
    private function extractDocumentFormActions(string $js, array &$accesses): void
    {
        // document.*.action = "URL"
        if (preg_match_all('/document\s*\.\s*[a-zA-Z0-9_]+\s*\.\s*action\s*=\s*(["\'])(.*?)\1/i', $js, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[2];
                if (!empty($url)) {
                    $accesses[] = [
                        'type' => 'action',
                        'url' => $url
                    ];
                }
            }
        }
        
        // document.forms["name"].action = "URL" 形式も考慮
        if (preg_match_all('/document\s*\.\s*forms\s*\[\s*(["\'])[a-zA-Z0-9_]+\1\s*\]\s*\.\s*action\s*=\s*(["\'])(.*?)\2/i', $js, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[3];
                if (!empty($url)) {
                    $accesses[] = [
                        'type' => 'action',
                        'url' => $url
                    ];
                }
            }
        }
    }
    
    /**
     * XMLHttpRequestを抽出
     */
    private function extractXhrRequests(string $js, array &$accesses): void
    {
        // xhr.open("METHOD", "URL", async)
        if (preg_match_all('/[a-zA-Z0-9_]+\s*\.\s*open\s*\(\s*(["\'])[^"\']*\1\s*,\s*(["\'])(.*?)\2/i', $js, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[3];
                if (!empty($url)) {
                    $accesses[] = [
                        'type' => 'XMLHttpRequest',
                        'url' => $url
                    ];
                }
            }
        }
        
        // fetch("URL")
        if (preg_match_all('/fetch\s*\(\s*(["\'])(.*?)\1/i', $js, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[2];
                if (!empty($url)) {
                    $accesses[] = [
                        'type' => 'XMLHttpRequest',
                        'url' => $url
                    ];
                }
            }
        }
    }
    
    /**
     * window.open("URL")を抽出
     */
    private function extractWindowOpen(string $js, array &$accesses): void
    {
        if (preg_match_all('/window\s*\.\s*open\s*\(\s*(["\'])(.*?)\1/i', $js, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[2];
                if (!empty($url) && $url !== 'about:blank') {
                    $accesses[] = [
                        'type' => 'window.open',
                        'url' => $url
                    ];
                }
            }
        }
    }
    
    /**
     * window.location.href = "URL"を抽出
     */
    private function extractWindowLocation(string $js, array &$accesses): void
    {
        // window.location.href = "URL"
        if (preg_match_all('/window\s*\.\s*location(?:\s*\.\s*href)?\s*=\s*(["\'])(.*?)\1/i', $js, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[2];
                if (!empty($url)) {
                    $accesses[] = [
                        'type' => 'window.location',
                        'url' => $url
                    ];
                }
            }
        }
        
        // window.location.replace("URL")
        if (preg_match_all('/window\s*\.\s*location\s*\.\s*replace\s*\(\s*(["\'])(.*?)\1/i', $js, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $url = $match[2];
                if (!empty($url)) {
                    $accesses[] = [
                        'type' => 'window.location',
                        'url' => $url
                    ];
                }
            }
        }
    }
    
    /**
     * 文字列解析を設定する
     */
    public function setStringAnalyzer(StringAnalyzer $analyzer): void
    {
        $this->stringAnalyzer = $analyzer;
    }
    
    /**
     * JavaScript文字列解析を設定する
     */
    public function setJsStringAnalyzer(JsStringAnalyzer $analyzer): void
    {
        $this->jsStringAnalyzer = $analyzer;
    }
} 