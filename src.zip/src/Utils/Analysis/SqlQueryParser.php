<?php
declare(strict_types=1);

namespace App\Utils\Analysis;

use PHPSQLParser\PHPSQLParser;
use PhpParser\Node\Expr\BinaryOp\Concat as BinaryConcat;
use PhpParser\Node\Expr\Variable;
use PhpParser\Node\Expr\ConstFetch;
use PhpParser\Node\Scalar\String_;
use PhpParser\Node\Expr\AssignOp\Concat as AssignConcat;
use RuntimeException;
use PDO;
use App\Utils\StringAnalysis\StringAnalyzer;

class SqlQueryParser
{
    private PHPSQLParser $parser;
    private array $variables = [];
    private array $constants = [];
    private array $variableVariants = []; // 条件分岐による複数候補を保持
    
    /**
     * テーブル名の複数候補を追跡
     * @var array
     */
    private array $tableCandidates = [];

    /**
     * 変数の代替値を格納する配列
     */
    private array $alternativeValues = [];
    
    /**
     * 登録済みビュー名のリスト
     */
    private array $viewNames = [];

    public function __construct()
    {
        $this->parser = new PHPSQLParser();
    }

    public function setVariable(string $name, string $value): void
    {
        $this->variables[$name] = $value;
        $this->variableVariants[$name] = [$value]; // 最初の値を変数バリアントとして登録
        
        // テーブル名候補として検出する可能性がある変数名パターン
        $tableNamePatterns = ['table', 'tbl', 'db'];
        
        foreach ($tableNamePatterns as $pattern) {
            if (stripos($name, $pattern) !== false) {
                $this->addTableCandidate($name, $value);
            }
        }
    }

    /**
     * 変数に対する別の値候補を追加する
     * 
     * @param string $name 変数名
     * @param string $value 変数の値候補
     */
    public function addVariableVariant(string $name, string $value): void
    {
        if (!isset($this->variableVariants[$name])) {
            $this->variableVariants[$name] = [];
        }
        
        // 重複を避けるためチェック
        if (!in_array($value, $this->variableVariants[$name])) {
            $this->variableVariants[$name][] = $value;
            
            // テーブル名候補として検出する可能性がある変数名パターン
            $tableNamePatterns = ['table', 'tbl', 'db'];
            
            foreach ($tableNamePatterns as $pattern) {
                if (stripos($name, $pattern) !== false) {
                    $this->addTableCandidate($name, $value);
                }
            }
        }
    }

    /**
     * テーブル名の候補を追加
     *
     * @param string $varName 変数名
     * @param string $value テーブル名
     */
    private function addTableCandidate(string $varName, string $value): void
    {
        if (!isset($this->tableCandidates[$varName])) {
            $this->tableCandidates[$varName] = [];
        }
        
        if (!in_array($value, $this->tableCandidates[$varName])) {
            $this->tableCandidates[$varName][] = $value;
        }
    }

    /**
     * 変数名に対するテーブル候補の数を取得
     *
     * @param string $varName 変数名
     * @return int 候補数
     */
    public function getTableCandidateCount(string $varName): int
    {
        return isset($this->tableCandidates[$varName]) ? count($this->tableCandidates[$varName]) : 0;
    }

    /**
     * 変数名に対するテーブル候補を取得
     *
     * @param string $varName 変数名
     * @return array テーブル名の配列
     */
    public function getTableCandidates(string $varName): array
    {
        return $this->tableCandidates[$varName] ?? [];
    }

    /**
     * 変数の全ての値候補を取得する
     * 
     * @param string $name 変数名
     * @return array 値候補の配列
     */
    public function getVariableVariants(string $name): array
    {
        $variants = [];
        
        if (isset($this->variables[$name])) {
            $variants[] = $this->variables[$name];
        }
        
        if (isset($this->alternativeValues[$name])) {
            $variants = array_merge($variants, $this->alternativeValues[$name]);
        }
        
        return array_unique($variants);
    }

    public function setConstant(string $name, string $value): void
    {
        $this->constants[$name] = $value;
    }

    public function resolveStringValue($node): ?string
    {
        if ($node instanceof String_) {
            return $node->value;
        }

        if ($node instanceof Variable) {
            $name = $node->name;
            if (is_string($name) && isset($this->variables[$name])) {
                return $this->variables[$name];
            }
            return null;
        }

        if ($node instanceof ConstFetch) {
            $name = $node->name->toString();
            if (isset($this->constants[$name])) {
                return $this->constants[$name];
            }
            return null;
        }

        return null;
    }

    public function isValidSqlQuery(string $query): bool
    {
        // 基本的なSQLキーワードチェック
        $sqlDetector = new SqlDetector();
        return $sqlDetector->detect($query);
    }

    public function parseQuery(string $query): array
    {
        try {
            // 構文解析
            $parsed = $this->parser->parse($query);
            
            // クエリタイプの判定
            $type = $this->getQueryType($parsed);
            
            // テーブルと操作の特定
            $tableOps = $this->getTableOperations($query);
            
            $tables = [];
            foreach ($tableOps as $table => $op) {
                $tables[] = $table;
            }
            
            return [
                'type' => $type,
                'tables' => $tables,
                'operation' => $this->determineOperation($type)
            ];
        } catch (\Exception $e) {
            // 解析に失敗した場合は最低限の情報を返す
            return [
                'type' => 'UNKNOWN',
                'tables' => [],
                'operation' => ''
            ];
        }
    }
    
    /**
     * クエリタイプに基づいて操作タイプを決定
     */
    private function determineOperation(string $type): string
    {
        switch ($type) {
            case 'SELECT':
                return 'R';
            case 'INSERT':
                return 'C';
            case 'UPDATE':
                return 'U';
            case 'DELETE':
            case 'DROP':
            case 'TRUNCATE':
                return 'D';
            case 'CREATE':
                return 'C';
            default:
                return '';
        }
    }

    /**
     * 与えられたSQLクエリから使用されているテーブルと操作（CRUD）を取得
     */
    public function getTableOperations(string $query): array
    {
        $result = [];
        
        try {
            // PHPSQLParserを使用してクエリを解析
            $parsed = $this->parser->parse($query);
            
            // クエリタイプを取得
            $queryType = $this->getQueryType($parsed);
            
            // WITH句の処理（Common Table Expressions）
            if (isset($parsed['WITH'])) {
                foreach ($parsed['WITH'] as $cte) {
                    if (isset($cte['alias']) && isset($cte['alias']['name'])) {
                        $tableName = $cte['alias']['name'];
                        // 一時テーブル（CTE）は作成(C)と読み取り(R)
                        $result[$tableName] = 'C,R';
                    }
                }
            }
            
            // メインのテーブル処理
            switch ($queryType) {
                case 'SELECT':
                    $this->processSelectQuery($parsed, $query, $result);
                    break;
                    
                case 'INSERT':
                    $this->processInsertQuery($parsed, $query, $result);
                    break;
                    
                case 'UPDATE':
                    $this->processUpdateQuery($parsed, $query, $result);
                    break;
                    
                case 'DELETE':
                    $this->processDeleteQuery($parsed, $query, $result);
                    break;
                    
                case 'DROP':
                    $this->processDropQuery($parsed, $query, $result);
                    break;
                    
                case 'TRUNCATE':
                    $this->processTruncateQuery($parsed, $query, $result);
                    break;
                    
                case 'CREATE':
                    $this->processCreateQuery($parsed, $query, $result);
                    break;
            }
        } catch (\Exception $e) {
            // PHPSQLParserが解析に失敗した場合は正規表現でフォールバック
            $this->fallbackTableOperations($query, $result);
        }
        
        // テーブル名に注釈を追加
        return $this->addTableAnnotations($result);
    }

    /**
     * SELECT クエリの処理
     */
    private function processSelectQuery(array $parsed, string $query, array &$result): void
    {
        // FROMで指定されたテーブル
        if (isset($parsed['FROM'])) {
            foreach ($parsed['FROM'] as $fromItem) {
                $tableName = $this->getTableNameFromClauseItem($fromItem);
                if ($tableName) {
                    $result[$tableName] = 'R';
                }
            }
        }
        
        // JOIN句で指定されたテーブル
        if (isset($parsed['JOIN'])) {
            foreach ($parsed['JOIN'] as $joinItem) {
                $tableName = $this->getTableNameFromClauseItem($joinItem);
                if ($tableName) {
                    $result[$tableName] = 'R';
                }
            }
        }
        
        // SELECT INTO TEMP 構文の処理
        if (isset($parsed['INTO']) && isset($parsed['INTO']['no_quotes']['parts'][0])) {
            $intoTable = $parsed['INTO']['no_quotes']['parts'][0];
            if (strpos(strtoupper($query), 'INTO TEMP') !== false || 
                strpos(strtoupper($query), 'INTO TEMPORARY') !== false) {
                $result[$intoTable] = 'C';
            }
        }
    }
    
    /**
     * INSERT クエリの処理
     */
    private function processInsertQuery(array $parsed, string $query, array &$result): void
    {
        // INSERT先のテーブル
        if (isset($parsed['INSERT'][0]['no_quotes']['parts'][0])) {
            $tableName = $parsed['INSERT'][0]['no_quotes']['parts'][0];
            $result[$tableName] = 'C';
        } elseif (isset($parsed['INSERT'][0]['table'])) {
            $tableName = $parsed['INSERT'][0]['table'];
            $result[$tableName] = 'C';
        }
        
        // INSERT ... SELECT の場合、SELECTのテーブルも処理
        if (isset($parsed['SELECT'])) {
            $this->processSelectQuery($parsed, $query, $result);
        }
    }
    
    /**
     * UPDATE クエリの処理
     */
    private function processUpdateQuery(array $parsed, string $query, array &$result): void
    {
        // UPDATE対象のテーブル
        if (isset($parsed['UPDATE'])) {
            foreach ($parsed['UPDATE'] as $updateItem) {
                if (isset($updateItem['no_quotes']['parts'][0])) {
                    $tableName = $updateItem['no_quotes']['parts'][0];
                    $result[$tableName] = 'U';
                } elseif (isset($updateItem['table'])) {
                    $tableName = $updateItem['table'];
                    $result[$tableName] = 'U';
                }
            }
        }
        
        // JOIN句のテーブル（読み取り操作）
        if (isset($parsed['JOIN'])) {
            foreach ($parsed['JOIN'] as $joinItem) {
                $tableName = $this->getTableNameFromClauseItem($joinItem);
                if ($tableName && (!isset($result[$tableName]) || $result[$tableName] !== 'U')) {
                    $result[$tableName] = 'R';
                }
            }
        }
    }
    
    /**
     * DELETE クエリの処理
     */
    private function processDeleteQuery(array $parsed, string $query, array &$result): void
    {
        // DELETE対象のテーブル
        if (isset($parsed['FROM'])) {
            foreach ($parsed['FROM'] as $fromItem) {
                $tableName = $this->getTableNameFromClauseItem($fromItem);
                if ($tableName) {
                    $result[$tableName] = 'D';
                }
            }
        }
        
        // DELETE FROM テーブル名 の形式
        if (isset($parsed['DELETE']) && !empty($parsed['DELETE'])) {
            foreach ($parsed['DELETE'] as $deleteItem) {
                if (isset($deleteItem['no_quotes']['parts'][0])) {
                    $tableName = $deleteItem['no_quotes']['parts'][0];
                    $result[$tableName] = 'D';
                } elseif (is_string($deleteItem)) {
                    $tableName = $deleteItem;
                    $result[$tableName] = 'D';
                }
            }
        }
        
        // JOIN句のテーブル（読み取り操作）
        if (isset($parsed['JOIN'])) {
            foreach ($parsed['JOIN'] as $joinItem) {
                $tableName = $this->getTableNameFromClauseItem($joinItem);
                if ($tableName && (!isset($result[$tableName]) || $result[$tableName] !== 'D')) {
                    $result[$tableName] = 'R';
                }
            }
        }
    }
    
    /**
     * DROP クエリの処理
     */
    private function processDropQuery(array $parsed, string $query, array &$result): void
    {
        // DROP TABLE テーブル名 の形式
        if (isset($parsed['DROP']) && isset($parsed['DROP']['object_list'])) {
            foreach ($parsed['DROP']['object_list'] as $object) {
                if (isset($object['no_quotes']['parts'][0])) {
                    $tableName = $object['no_quotes']['parts'][0];
                    $result[$tableName] = 'D';
                } elseif (is_string($object)) {
                    $result[$object] = 'D';
                }
            }
        }
        
        // フォールバック：正規表現で抽出
        if (empty($result)) {
            if (preg_match('/DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?([^\s;]+)/i', $this->getOriginalQuery($parsed), $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'D';
            }
        }
    }
    
    /**
     * TRUNCATE クエリの処理
     */
    private function processTruncateQuery(array $parsed, string $query, array &$result): void
    {
        // TRUNCATE TABLE テーブル名 の形式
        if (isset($parsed['TRUNCATE']) && isset($parsed['TRUNCATE']['table'])) {
            $tableName = $parsed['TRUNCATE']['table'];
            $result[$tableName] = 'D';
        }
        
        // フォールバック：正規表現で抽出
        if (empty($result)) {
            if (preg_match('/TRUNCATE\s+(?:TABLE\s+)?([^\s;,]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'D';
            }
        }
    }
    
    /**
     * CREATE クエリの処理
     */
    private function processCreateQuery(array $parsed, string $query, array &$result): void
    {
        // CREATE TABLE の処理
        if (isset($parsed['CREATE']) && isset($parsed['CREATE']['table']['no_quotes']['parts'][0])) {
            $tableName = $parsed['CREATE']['table']['no_quotes']['parts'][0];
            $result[$tableName] = 'C';
            
            // CREATE TABLE AS SELECT の場合、SELECTのテーブルも処理
            if (isset($parsed['SELECT'])) {
                $this->processSelectQuery($parsed, $query, $result);
            }
        }
        
        // フォールバック：正規表現で抽出
        if (empty($result) || !isset($result[$tableName])) {
            if (preg_match('/CREATE\s+(?:TEMPORARY\s+)?TABLE\s+([^\s(;]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'C';
            }
        }
    }
    
    /**
     * テーブル名に注釈を追加
     */
    private function addTableAnnotations(array $tables): array
    {
        $result = [];
        
        foreach ($tables as $table => $operation) {
            $annotatedTable = $table;
            $annotations = [];
            
            // ビュー注釈
            if (in_array($table, $this->viewNames, true)) {
                $annotations[] = 'view';
            }
            
            // テンポラリテーブル注釈
            if (strpos(strtolower($table), 'temp') !== false || 
                preg_match('/^(tmp|temp)_/i', $table)) {
                $annotations[] = 'temp';
            }
            
            // 複数候補テーブル注釈
            if ($this->hasMultipleCandidatesForTable($table)) {
                $annotations[] = 'multi';
            }
            
            // 注釈を追加
            if (!empty($annotations)) {
                $annotatedTable = $table . '@' . implode(',', $annotations);
            }
            
            $result[$annotatedTable] = $operation;
        }
        
        return $result;
    }
    
    /**
     * 元のクエリ文字列を取得（パース結果からの再構築）
     */
    private function getOriginalQuery(array $parsed): string
    {
        if (isset($parsed['_original_query'])) {
            return $parsed['_original_query'];
        }
        
        // パース結果から元のクエリを再構築するのは困難なので、
        // パース前にクエリを保存しておくことが推奨
        return '';
    }

    /**
     * フォールバック：正規表現でテーブル操作を抽出
     */
    private function fallbackTableOperations(string $query, array &$result = []): array
    {
        $upperQuery = strtoupper($query);
        
        // SELECT操作
        if (strpos($upperQuery, 'SELECT') === 0) {
            if (preg_match_all('/FROM\s+([^\s,(;]+)/i', $query, $matches)) {
                foreach ($matches[1] as $table) {
                    $tableName = trim($table, '`"[]');
                    $result[$tableName] = 'R';
                }
            }
            
            // JOIN句のテーブル
            if (preg_match_all('/JOIN\s+([^\s,(;]+)/i', $query, $matches)) {
                foreach ($matches[1] as $table) {
                    $tableName = trim($table, '`"[]');
                    $result[$tableName] = 'R';
                }
            }
            
            // SELECT INTO TEMP
            if (preg_match('/INTO\s+TEMP\s+([^\s,(;]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'C';
            }
        }
        
        // INSERT操作
        elseif (strpos($upperQuery, 'INSERT') === 0) {
            if (preg_match('/INSERT\s+INTO\s+([^\s(;]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'C';
            }
        }
        
        // UPDATE操作
        elseif (strpos($upperQuery, 'UPDATE') === 0) {
            if (preg_match('/UPDATE\s+([^\s,;]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'U';
            }
            
            // JOIN句のテーブル
            if (preg_match_all('/JOIN\s+([^\s,(;]+)/i', $query, $matches)) {
                foreach ($matches[1] as $table) {
                    $tableName = trim($table, '`"[]');
                    if (!isset($result[$tableName]) || $result[$tableName] !== 'U') {
                        $result[$tableName] = 'R';
                    }
                }
            }
        }
        
        // DELETE操作
        elseif (strpos($upperQuery, 'DELETE') === 0) {
            if (preg_match('/FROM\s+([^\s,;]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'D';
            }
            
            // DELETE specific_table FROM table の形式
            elseif (preg_match('/DELETE\s+[^\s,;]+\s+FROM\s+([^\s,;]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'D';
            }
            
            // JOIN句のテーブル
            if (preg_match_all('/JOIN\s+([^\s,(;]+)/i', $query, $matches)) {
                foreach ($matches[1] as $table) {
                    $tableName = trim($table, '`"[]');
                    if (!isset($result[$tableName]) || $result[$tableName] !== 'D') {
                        $result[$tableName] = 'R';
                    }
                }
            }
        }
        
        // DROP操作
        elseif (strpos($upperQuery, 'DROP') === 0) {
            if (preg_match('/DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?([^\s;,]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'D';
            }
        }
        
        // TRUNCATE操作
        elseif (strpos($upperQuery, 'TRUNCATE') === 0) {
            if (preg_match('/TRUNCATE\s+(?:TABLE\s+)?([^\s;,]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'D';
            }
        }
        
        // CREATE操作
        elseif (strpos($upperQuery, 'CREATE') === 0) {
            if (preg_match('/CREATE\s+(?:TEMPORARY\s+)?TABLE\s+([^\s(;,]+)/i', $query, $matches)) {
                $tableName = trim($matches[1], '`"[]');
                $result[$tableName] = 'C';
            }
        }
        
        // WITH句（CTE）の処理
        if (preg_match_all('/WITH\s+([^\s(;,]+)\s+AS\s*\(/i', $query, $matches)) {
            foreach ($matches[1] as $cte) {
                $cteName = trim($cte, '`"[]');
                $result[$cteName] = 'C,R';
            }
        }
        
        return $result;
    }

    /**
     * ビュー名リストを設定
     */
    public function setViewNames(array $viewNames): void
    {
        $this->viewNames = $viewNames;
    }

    private function getQueryType(array $parsed): string
    {
        if (isset($parsed['SELECT'])) return 'SELECT';
        if (isset($parsed['INSERT'])) return 'INSERT';
        if (isset($parsed['UPDATE'])) return 'UPDATE';
        if (isset($parsed['DELETE'])) return 'DELETE';
        if (isset($parsed['CREATE'])) return 'CREATE';
        if (isset($parsed['DROP'])) return 'DROP';
        if (isset($parsed['TRUNCATE'])) return 'TRUNCATE';
        if (isset($parsed['WITH'])) return 'WITH';
        return 'UNKNOWN';
    }

    private function getTableNameFromClauseItem(array $item): ?string
    {
        if (isset($item['table'])) {
            return $item['table'];
        }
        if (isset($item['no_quotes']['parts'][0])) {
            return $item['no_quotes']['parts'][0];
        }
        if (isset($item['base_expr'])) {
            return $item['base_expr'];
        }
        return null;
    }

    /**
     * 指定されたテーブル名が複数の候補を持つ変数に含まれているかチェック
     *
     * @param string $tableName テーブル名
     * @return bool 複数候補がある場合はtrue
     */
    private function hasMultipleCandidatesForTable(string $tableName): bool
    {
        foreach ($this->tableCandidates as $candidates) {
            if (count($candidates) > 1 && in_array($tableName, $candidates)) {
                return true;
            }
        }
        
        return false;
    }
} 