<?php
declare(strict_types=1);

namespace App\Utils\Analysis;

use PhpParser\Node;
use PhpParser\Node\Stmt\Function_;
use PhpParser\Node\Stmt\ClassMethod;
use PhpParser\Node\Expr\Assign;
use PhpParser\Node\Expr\Variable;
use PhpParser\Node\Scalar\String_;
use PhpParser\Node\Expr\BinaryOp\Concat;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;
use PhpParser\ParserFactory;
use App\Utils\ErrorHandling\ErrorHandler;
use App\Utils\StringAnalysis\StringAnalyzer;

/**
 * 関数を解析するノードビジター
 */
class FunctionVisitor extends NodeVisitorAbstract
{
    /**
     * SQLクエリ解析器
     */
    private SqlQueryParser $sqlParser;
    
    /**
     * SQL検出器
     */
    private SqlDetector $sqlDetector;
    
    /**
     * 抽出された関数情報
     */
    private array $functions = [];
    
    /**
     * 文字列解析ツール
     */
    private StringAnalyzer $stringAnalyzer;
    
    /**
     * 現在解析中の関数名
     */
    private ?string $currentFunction = null;
    
    /**
     * 現在の関数内の変数マップ
     */
    private array $functionVariables = [];
    
    /**
     * コンストラクタ
     */
    public function __construct(SqlQueryParser $sqlParser, SqlDetector $sqlDetector, StringAnalyzer $stringAnalyzer)
    {
        $this->sqlParser = $sqlParser;
        $this->sqlDetector = $sqlDetector;
        $this->stringAnalyzer = $stringAnalyzer;
    }
    
    /**
     * ノード訪問時の処理
     */
    public function enterNode(Node $node)
    {
        // 関数定義を処理
        if ($node instanceof Function_ || $node instanceof ClassMethod) {
            // 新しい関数に入る
            $this->currentFunction = $node->name->toString();
            $this->functionVariables = [];
        }
        
        // 変数代入を追跡
        if ($node instanceof Assign && $node->var instanceof Variable && is_string($node->var->name)) {
            $varName = $node->var->name;
            
            // 文字列リテラルを処理
            if ($node->expr instanceof String_) {
                $this->functionVariables[$varName] = $node->expr->value;
            }
            // 文字列連結を処理
            elseif ($node->expr instanceof Concat) {
                $resolvedString = $this->stringAnalyzer->analyze($node->expr);
                if ($resolvedString !== null) {
                    $this->functionVariables[$varName] = $resolvedString;
                }
            }
            
            // SQL検出
            if (isset($this->functionVariables[$varName]) && $this->sqlDetector->detect($this->functionVariables[$varName])) {
                $this->analyzeSql($this->functionVariables[$varName]);
            }
        }
        
        return null;
    }
    
    /**
     * ノード離脱時の処理
     */
    public function leaveNode(Node $node)
    {
        // 関数定義を処理
        if (($node instanceof Function_ || $node instanceof ClassMethod) && $node->name->toString() === $this->currentFunction) {
            $functionBody = $this->extractFunctionBody($node);
            $this->analyzeFunctionBody($functionBody);
            
            // 関数を離れる
            $this->currentFunction = null;
            $this->functionVariables = [];
        }
        
        return null;
    }
    
    /**
     * 関数本体を抽出する
     */
    private function extractFunctionBody(Node $node): string
    {
        $prettyPrinter = new \PhpParser\PrettyPrinter\Standard();
        return $prettyPrinter->prettyPrint($node->stmts);
    }
    
    /**
     * 関数本体を解析してSQLを検出する
     */
    private function analyzeFunctionBody(string $functionBody): void
    {
        // SQL文を抽出して解析
        if (preg_match_all('/[\'"](.+?)[\'"]/s', $functionBody, $matches)) {
            foreach ($matches[1] as $potentialSql) {
                if ($this->sqlDetector->detect($potentialSql)) {
                    $this->analyzeSql($potentialSql);
                }
            }
        }
    }
    
    /**
     * SQLを解析してCRUD操作を追跡する
     */
    private function analyzeSql(string $sql): void
    {
        if ($this->currentFunction === null) {
            return;
        }
        
        $tableOperations = $this->sqlParser->getTableOperations($sql);
        
        if (empty($tableOperations)) {
            return;
        }
        
        // 現在の関数のエントリを確保
        $functionExists = false;
        foreach ($this->functions as &$function) {
            if ($function['name'] === $this->currentFunction) {
                $functionExists = true;
                break;
            }
        }
        
        if (!$functionExists) {
            $this->functions[] = [
                'name' => $this->currentFunction,
                'crud' => []
            ];
        }
        
        // CRUD操作を追加
        foreach ($this->functions as &$function) {
            if ($function['name'] === $this->currentFunction) {
                foreach ($tableOperations as $table => $operations) {
                    if (!isset($function['crud'][$table])) {
                        $function['crud'][$table] = [];
                    }
                    
                    // 操作を追加（重複しないように）
                    foreach ($operations as $operation) {
                        if (!in_array($operation, $function['crud'][$table])) {
                            $function['crud'][$table][] = $operation;
                        }
                    }
                }
                break;
            }
        }
    }
    
    /**
     * 抽出された関数情報を取得
     */
    public function getFunctions(): array
    {
        return $this->functions;
    }
}

/**
 * 関数を解析するクラス
 */
class FunctionAnalyzer
{
    /**
     * SQLクエリ解析器
     */
    private SqlQueryParser $sqlParser;
    
    /**
     * SQL検出器
     */
    private SqlDetector $sqlDetector;
    
    /**
     * 文字列解析ツール
     */
    private StringAnalyzer $stringAnalyzer;
    
    /**
     * エラーハンドラ
     */
    private ?ErrorHandler $errorHandler;
    
    /**
     * コンストラクタ
     */
    public function __construct(?ErrorHandler $errorHandler = null)
    {
        $this->sqlParser = new SqlQueryParser();
        $this->sqlDetector = new SqlDetector();
        $this->stringAnalyzer = new StringAnalyzer($errorHandler);
        $this->errorHandler = $errorHandler;
    }
    
    /**
     * ファイルを解析して関数とそのCRUD操作を取得
     *
     * @param string $filePath 解析対象のファイルパス
     * @return array 関数情報の配列
     */
    public function analyzeFile(string $filePath): array
    {
        if (!file_exists($filePath)) {
            if ($this->errorHandler) {
                $this->errorHandler->handle("File not found: $filePath");
            }
            return [];
        }
        
        $code = file_get_contents($filePath);
        if ($code === false) {
            if ($this->errorHandler) {
                $this->errorHandler->handle("Could not read file: $filePath");
            }
            return [];
        }
        
        return $this->analyze($code);
    }
    
    /**
     * コードを解析して関数とそのCRUD操作を取得
     *
     * @param string $code 解析対象のコード
     * @return array 関数情報の配列
     */
    public function analyze(string $code): array
    {
        try {
            // シンボルテーブルの構築
            $variables = $this->stringAnalyzer->extractVariablesFromCode($code);
            $constants = $this->stringAnalyzer->extractConstantsFromCode($code);
            
            $this->stringAnalyzer->setVariables($variables);
            $this->stringAnalyzer->setConstants($constants);
            
            // AST解析
            $parser = (new ParserFactory)->createForNewestSupportedVersion();
            $ast = $parser->parse($code);
            
            if ($ast === null) {
                return $this->fallbackAnalyze($code);
            }
            
            // 関数定義を走査
            $traverser = new NodeTraverser();
            $visitor = new FunctionVisitor($this->sqlParser, $this->sqlDetector, $this->stringAnalyzer);
            
            $traverser->addVisitor($visitor);
            $traverser->traverse($ast);
            
            $functions = $visitor->getFunctions();
            
            // 結果が空の場合はフォールバック
            if (empty($functions)) {
                return $this->fallbackAnalyze($code);
            }
            
            return $functions;
            
        } catch (\Exception $e) {
            if ($this->errorHandler) {
                $this->errorHandler->handle('AST解析エラー: ' . $e->getMessage());
            }
            
            // AST解析失敗時はフォールバック解析
            return $this->fallbackAnalyze($code);
        }
    }
    
    /**
     * 正規表現を使ったフォールバック解析
     */
    private function fallbackAnalyze(string $code): array
    {
        $functions = [];
        
        // 正規表現で関数を抽出
        if (preg_match_all('/function\s+([a-zA-Z0-9_]+)\s*\(.*?\)\s*\{(.*?)\}/s', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $functionName = $match[1];
                $functionBody = $match[2];
                $crud = [];
                
                // SQL文を抽出して解析
                if (preg_match_all('/[\'"](.+?)[\'"]/s', $functionBody, $sqlMatches)) {
                    foreach ($sqlMatches[1] as $potentialSql) {
                        if ($this->sqlDetector->detect($potentialSql)) {
                            $tableOperations = $this->sqlParser->getTableOperations($potentialSql);
                            foreach ($tableOperations as $table => $operations) {
                                if (!isset($crud[$table])) {
                                    $crud[$table] = [];
                                }
                                
                                foreach ($operations as $operation) {
                                    if (!in_array($operation, $crud[$table])) {
                                        $crud[$table][] = $operation;
                                    }
                                }
                            }
                        }
                    }
                }
                
                // 変数からSQLを抽出
                if (preg_match_all('/\$([a-zA-Z0-9_]+)\s*=\s*[\'"](.+?)[\'"]/s', $functionBody, $varMatches, PREG_SET_ORDER)) {
                    $vars = [];
                    foreach ($varMatches as $varMatch) {
                        $varName = $varMatch[1];
                        $varValue = $varMatch[2];
                        $vars[$varName] = $varValue;
                    }
                    
                    // 変数を使ったSQL実行を検出
                    if (preg_match_all('/(?:query|exec|prepare)\s*\(\s*\$([a-zA-Z0-9_]+)/s', $functionBody, $execMatches, PREG_SET_ORDER)) {
                        foreach ($execMatches as $execMatch) {
                            $sqlVarName = $execMatch[1];
                            if (isset($vars[$sqlVarName]) && $this->sqlDetector->detect($vars[$sqlVarName])) {
                                $tableOperations = $this->sqlParser->getTableOperations($vars[$sqlVarName]);
                                foreach ($tableOperations as $table => $operations) {
                                    if (!isset($crud[$table])) {
                                        $crud[$table] = [];
                                    }
                                    
                                    foreach ($operations as $operation) {
                                        if (!in_array($operation, $crud[$table])) {
                                            $crud[$table][] = $operation;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                if (!empty($crud)) {
                    $functions[] = [
                        'name' => $functionName,
                        'crud' => $crud
                    ];
                }
            }
        }
        
        // クラスメソッドも抽出
        if (preg_match_all('/function\s+([a-zA-Z0-9_]+)\s*\(.*?\)\s*\{(.*?)\}/s', $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $methodName = $match[1];
                $methodBody = $match[2];
                $crud = [];
                
                // SQL文を抽出して解析
                if (preg_match_all('/[\'"](.+?)[\'"]/s', $methodBody, $sqlMatches)) {
                    foreach ($sqlMatches[1] as $potentialSql) {
                        if ($this->sqlDetector->detect($potentialSql)) {
                            $tableOperations = $this->sqlParser->getTableOperations($potentialSql);
                            foreach ($tableOperations as $table => $operations) {
                                if (!isset($crud[$table])) {
                                    $crud[$table] = [];
                                }
                                
                                foreach ($operations as $operation) {
                                    if (!in_array($operation, $crud[$table])) {
                                        $crud[$table][] = $operation;
                                    }
                                }
                            }
                        }
                    }
                }
                
                if (!empty($crud)) {
                    // 既存の関数と名前が重複しないか確認
                    $exists = false;
                    foreach ($functions as $func) {
                        if ($func['name'] === $methodName) {
                            $exists = true;
                            break;
                        }
                    }
                    
                    if (!$exists) {
                        $functions[] = [
                            'name' => $methodName,
                            'crud' => $crud
                        ];
                    }
                }
            }
        }
        
        return $functions;
    }
    
    /**
     * SQLクエリ解析器を設定
     */
    public function setSqlParser(SqlQueryParser $parser): void
    {
        $this->sqlParser = $parser;
    }
    
    /**
     * SQL検出器を設定
     */
    public function setSqlDetector(SqlDetector $detector): void
    {
        $this->sqlDetector = $detector;
    }
    
    /**
     * 文字列解析ツールを設定
     */
    public function setStringAnalyzer(StringAnalyzer $analyzer): void
    {
        $this->stringAnalyzer = $analyzer;
    }
} 