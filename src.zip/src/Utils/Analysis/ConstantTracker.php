<?php
declare(strict_types=1);

namespace App\Utils\Analysis;

use PhpParser\Node;
use PhpParser\Node\Stmt\Const_;
use PhpParser\Node\Stmt\ClassConst;
use PhpParser\Node\Expr\FuncCall;
use PhpParser\Node\Name;
use App\Utils\StringAnalysis\StringAnalyzer;

/**
 * 定数の定義と使用を追跡するクラス
 */
class ConstantTracker
{
    /**
     * 定数の値を格納する配列
     * @var array
     */
    private array $constants = [];

    /**
     * 文字列解析器
     */
    private StringAnalyzer $stringAnalyzer;

    /**
     * コンストラクタ
     */
    public function __construct()
    {
        $this->stringAnalyzer = new StringAnalyzer();
        $this->initPredefinedConstants();
    }

    /**
     * 定義済み定数の初期化
     */
    private function initPredefinedConstants(): void
    {
        // PHPの組み込み定数
        $predefinedConstants = [
            'PHP_VERSION' => PHP_VERSION,
            'PHP_OS' => PHP_OS,
            'TRUE' => 'true',
            'FALSE' => 'false',
            'NULL' => 'null',
        ];
        
        foreach ($predefinedConstants as $name => $value) {
            $this->constants[$name] = (string)$value;
        }
    }

    /**
     * ノードから定数の定義を追跡する
     *
     * @param Node $node 解析対象のノード
     * @return void
     */
    public function track(Node $node): void
    {
        // const による定義
        if ($node instanceof Const_) {
            foreach ($node->consts as $const) {
                $constName = $const->name->toString();
                $value = $this->stringAnalyzer->analyze($const->value);
                
                if ($value !== null) {
                    $this->constants[$constName] = $value;
                }
            }
        }
        
        // クラス定数の処理
        if ($node instanceof ClassConst) {
            foreach ($node->consts as $const) {
                $constName = $const->name->toString();
                $value = $this->stringAnalyzer->analyze($const->value);
                
                if ($value !== null) {
                    $this->constants[$constName] = $value;
                }
            }
        }
        
        // define() 関数による定義
        if ($node instanceof FuncCall && $node->name instanceof Name) {
            $funcName = $node->name->toString();
            if ($funcName === 'define' && isset($node->args[0]) && isset($node->args[1])) {
                $this->trackDefineCall($node);
            }
        }
    }

    /**
     * define() 関数呼び出しから定数を追跡する
     *
     * @param FuncCall $node define関数のノード
     * @return void
     */
    private function trackDefineCall(FuncCall $node): void
    {
        // 第1引数（定数名）を取得
        $nameArg = $node->args[0]->value;
        $constName = null;
        
        if ($nameArg instanceof Node\Scalar\String_) {
            $constName = $nameArg->value;
        }
        
        // 定数名が取得できない場合は終了
        if ($constName === null) {
            return;
        }
        
        // 第2引数（定数値）を取得
        $valueArg = $node->args[1]->value;
        
        // 定数の値が単純な値の場合に追跡
        if ($valueArg instanceof Node\Scalar\String_) {
            $this->constants[$constName] = $valueArg->value;
        } elseif ($valueArg instanceof Node\Scalar\LNumber) {
            $this->constants[$constName] = (string)$valueArg->value;
        } elseif ($valueArg instanceof Node\Scalar\DNumber) {
            $this->constants[$constName] = (string)$valueArg->value;
        }
    }

    /**
     * 特定の定数の値を取得する
     *
     * @param string $name 定数名
     * @return string|null 定数の値、存在しない場合はnull
     */
    public function getValue(string $name): ?string
    {
        return $this->constants[$name] ?? null;
    }

    /**
     * 登録されているすべての定数を取得する
     *
     * @return array 定数名をキー、値を値とする連想配列
     */
    public function getConstants(): array
    {
        return $this->constants;
    }

    /**
     * 定数の値を設定する
     *
     * @param string $name 定数名
     * @param string $value 定数の値
     * @return void
     */
    public function setValue(string $name, string $value): void
    {
        $this->constants[$name] = $value;
    }

    /**
     * 定数情報をクリアする
     *
     * @return void
     */
    public function clear(): void
    {
        $this->constants = [];
    }
} 