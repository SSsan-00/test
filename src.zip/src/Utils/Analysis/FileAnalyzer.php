<?php
declare(strict_types=1);

namespace App\Utils\Analysis;

use App\Model\AnalysisResult;
use App\Utils\ErrorHandling\ErrorHandler;
use RuntimeException;

/**
 * ファイル解析を行うクラス
 */
class FileAnalyzer
{
    /**
     * ビュー名のリスト
     */
    private array $viewNames;
    
    /**
     * ストアドプロシージャ名のリスト
     */
    private array $procNames;
    
    /**
     * エラーハンドラ
     */
    private ErrorHandler $errorHandler;
    
    /**
     * SQLクエリ解析器
     */
    private SqlQueryAnalyzer $sqlAnalyzer;
    
    /**
     * 関数解析器
     */
    private FunctionAnalyzer $functionAnalyzer;
    
    /**
     * インクルード解析器
     */
    private IncludeAnalyzer $includeAnalyzer;
    
    /**
     * 外部アクセス解析器
     */
    private ExternalAccessAnalyzer $externalAnalyzer;
    
    /**
     * ストアドプロシージャ解析器
     */
    private StoredProcedureAnalyzer $procAnalyzer;
    
    /**
     * コンストラクタ
     *
     * @param array $viewNames ビュー名のリスト
     * @param array $procNames ストアドプロシージャ名のリスト
     * @param ErrorHandler|null $errorHandler エラーハンドラ
     */
    public function __construct(array $viewNames = [], array $procNames = [], ?ErrorHandler $errorHandler = null)
    {
        $this->viewNames = $viewNames;
        $this->procNames = $procNames;
        $this->errorHandler = $errorHandler ?? new ErrorHandler();
        
        // 各種解析クラスの初期化
        $this->sqlAnalyzer = new SqlQueryAnalyzer();
        $this->functionAnalyzer = new FunctionAnalyzer();
        $this->includeAnalyzer = new IncludeAnalyzer();
        $this->externalAnalyzer = new ExternalAccessAnalyzer();
        $this->procAnalyzer = new StoredProcedureAnalyzer($procNames);
    }
    
    /**
     * ファイルを解析する
     *
     * @param string $filePath 解析対象のファイルパス
     * @return AnalysisResult 解析結果
     */
    public function analyzeFile(string $filePath): AnalysisResult
    {
        if (!file_exists($filePath)) {
            throw new RuntimeException("File not found: {$filePath}");
        }
        
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        
        // 解析結果オブジェクトの初期化
        $result = new AnalysisResult($filePath);
        
        try {
            // ファイルタイプに応じた解析
            switch ($extension) {
                case 'php':
                case 'inc':
                    // PHPファイルの解析
                    $this->analyzePHPFile($filePath, $result);
                    break;
                    
                case 'html':
                    // HTMLファイルの解析
                    $this->analyzeHTMLFile($filePath, $result);
                    break;
                    
                case 'js':
                    // JavaScriptファイルの解析
                    $this->analyzeJSFile($filePath, $result);
                    break;
                    
                default:
                    $this->errorHandler->handle("Unsupported file type: {$extension}");
                    break;
            }
        } catch (\Exception $e) {
            $this->errorHandler->handle("{$filePath}: {$e->getMessage()}");
        }
        
        return $result;
    }
    
    /**
     * PHPファイルを解析する
     */
    private function analyzePHPFile(string $filePath, AnalysisResult $result): void
    {
        // SQL解析
        $this->sqlAnalyzer->analyzeFile($filePath, $result);
        
        // 関数解析
        $functions = $this->functionAnalyzer->analyzeFile($filePath);
        foreach ($functions as $function) {
            $result->addFunctionCrud($function['name'], $function['crud']);
        }
        
        // インクルード解析
        $includes = $this->includeAnalyzer->analyzeFile($filePath);
        foreach ($includes as $include) {
            $result->addInclude($include);
        }
        
        // 外部アクセス解析
        $externalAccesses = $this->externalAnalyzer->analyzeFile($filePath);
        foreach ($externalAccesses as $access) {
            $result->addExternalAccess($access);
        }
        
        // ストアドプロシージャ解析
        $procedures = $this->procAnalyzer->analyzeFile($filePath);
        foreach ($procedures as $procedure) {
            $result->addProcedureCall($procedure);
        }
    }
    
    /**
     * HTMLファイルを解析する
     */
    private function analyzeHTMLFile(string $filePath, AnalysisResult $result): void
    {
        // 外部アクセス解析のみ実行
        $externalAccesses = $this->externalAnalyzer->analyzeFile($filePath);
        foreach ($externalAccesses as $access) {
            $result->addExternalAccess($access);
        }
    }
    
    /**
     * JavaScriptファイルを解析する
     */
    private function analyzeJSFile(string $filePath, AnalysisResult $result): void
    {
        // 外部アクセス解析のみ実行
        $externalAccesses = $this->externalAnalyzer->analyzeFile($filePath);
        foreach ($externalAccesses as $access) {
            $result->addExternalAccess($access);
        }
    }
} 