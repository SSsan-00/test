<?php

namespace App\Utils\ValueResolution;

use App\Utils\Analysis\AnalysisResult;
use App\Utils\ErrorHandling\ErrorHandler;
use PhpParser\Node;
use PhpParser\Node\Expr\Variable;
use PhpParser\Node\Expr\ConstFetch;
use PhpParser\Node\Name;

class ValueResolver
{
    private AnalysisResult $result;
    private ErrorHandler $errorHandler;

    public function __construct(AnalysisResult $result, ErrorHandler $errorHandler)
    {
        $this->result = $result;
        $this->errorHandler = $errorHandler;
    }

    public function resolveVariable(Variable $node, int $depth = 0): ?string
    {
        $varName = is_string($node->name) ? $node->name : null;
        if ($varName !== null) {
            $variables = $this->result->getVariables();
            if (isset($variables[$varName])) {
                $value = $variables[$varName];
                if ($value instanceof Node) {
                    return $this->resolve($value, $depth + 1);
                }
                if (is_string($value)) {
                    return $value;
                }
            }
            $this->errorHandler->handle("Variable $varName is undefined");
            return null;
        }
        return null;
    }

    public function resolveConstant(ConstFetch $node, int $depth = 0): ?string
    {
        $constName = $node->name instanceof Name ? $node->name->toString() : null;
        if ($constName !== null) {
            $constants = $this->result->getConstants();
            if (isset($constants[$constName])) {
                $value = $constants[$constName];
                if ($value instanceof Node) {
                    return $this->resolve($value, $depth + 1);
                }
                if (is_string($value)) {
                    return $value;
                }
            }
            $this->errorHandler->handle("Constant $constName is undefined");
            return null;
        }
        return null;
    }

    public function resolve(Node $node, int $depth = 0): ?string
    {
        if ($node instanceof Variable) {
            return $this->resolveVariable($node, $depth);
        }
        if ($node instanceof ConstFetch) {
            return $this->resolveConstant($node, $depth);
        }
        if ($node instanceof \PhpParser\Node\Scalar\String_) {
            return $node->value;
        }
        if ($node instanceof \PhpParser\Node\Scalar\EncapsedStringPart) {
            return $node->value;
        }
        return null;
    }
} 