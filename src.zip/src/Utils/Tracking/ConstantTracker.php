<?php

namespace App\Utils\Tracking;

use PhpParser\Node;
use PhpParser\Node\Stmt\Const_;
use App\Utils\ErrorHandling\ErrorHandler;
use App\Utils\Analysis\AnalysisResult;
use App\Utils\StringAnalysis\StringAnalyzer;

class ConstantTracker
{
    private AnalysisResult $result;
    private ErrorHandler $errorHandler;
    private StringAnalyzer $stringAnalyzer;

    public function __construct(
        AnalysisResult $result,
        ErrorHandler $errorHandler,
        StringAnalyzer $stringAnalyzer
    ) {
        $this->result = $result;
        $this->errorHandler = $errorHandler;
        $this->stringAnalyzer = $stringAnalyzer;
    }

    public function track(Node $node): void
    {
        if (!$node instanceof Const_) {
            return;
        }

        foreach ($node->consts as $const) {
            $constName = $const->name->name;
            $value = $this->stringAnalyzer->analyze($const->value);
            
            if ($value !== null) {
                $this->result->setConstant($constName, $value);
            }
        }
    }
} 