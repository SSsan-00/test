<?php

namespace App\Utils\Tracking;

use PhpParser\Node;
use PhpParser\Node\Expr\Assign;
use PhpParser\Node\Expr\Variable;
use PhpParser\Node\Scalar\String_;
use PhpParser\Node\Expr\AssignOp\Concat as AssignOpConcat;
use App\Utils\ErrorHandling\ErrorHandler;
use App\Utils\Analysis\AnalysisResult;
use App\Utils\StringAnalysis\StringAnalyzer;

class VariableTracker
{
    private AnalysisResult $result;
    private ErrorHandler $errorHandler;
    private StringAnalyzer $stringAnalyzer;

    public function __construct(
        AnalysisResult $result,
        ErrorHandler $errorHandler,
        StringAnalyzer $stringAnalyzer
    ) {
        $this->result = $result;
        $this->errorHandler = $errorHandler;
        $this->stringAnalyzer = $stringAnalyzer;
    }

    public function track(Node $node): void
    {
        if ($node instanceof Assign) {
        if (!$node->var instanceof Variable) {
            return;
        }
        $varName = is_string($node->var->name) ? $node->var->name : null;
        if ($varName === null) {
            return;
        }
            if ($node->expr instanceof AssignOpConcat) {
                $value = $this->stringAnalyzer->analyze($node->expr);
            } else {
        $value = $this->stringAnalyzer->analyze($node->expr);
            }
        if ($value !== null) {
            $this->result->setVariable($varName, $value);
            }
        } elseif ($node instanceof AssignOpConcat) {
            if (!$node->var instanceof Variable) {
                return;
            }
            $varName = is_string($node->var->name) ? $node->var->name : null;
            if ($varName === null) {
                return;
            }
            $variables = $this->result->getVariables();
            $current = $variables[$varName] ?? '';
            $right = $this->stringAnalyzer->analyze($node->expr);
            if ($right !== null) {
                $this->result->setVariable($varName, $current . $right);
            }
        }
    }
} 