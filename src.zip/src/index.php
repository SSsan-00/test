<?php
/**
 * 静的解析ツール
 * 
 * PHP 8.4以上で動作する、指定ディレクトリ以下のphp/inc/html/jsファイルを
 * 静的解析して5シート構成のExcelに出力するCLIツール
 * 
 * 使用方法:
 * php src/index.php <TARGET_DIR> [OUTPUT.xlsx]
 * 
 * <TARGET_DIR>: 解析対象ディレクトリ（デフォルト: ./src）
 * [OUTPUT.xlsx]: 出力ファイル（デフォルト: ../output/analysis.xlsx）
 */

// PHPバージョンチェック
if (PHP_VERSION_ID < 80400) {
    fwrite(STDERR, "ERROR: PHP 8.4以上が必要です。現在のバージョン: " . PHP_VERSION . "\n");
    exit(1);
}

// Composerのオートローダーを読み込み
$autoloadFile = __DIR__ . '/../vendor/autoload.php';
if (!file_exists($autoloadFile)) {
    fwrite(STDERR, "ERROR: vendor/autoload.phpが見つかりません。Composerの依存関係をインストールしてください。\n");
    exit(1);
}
require_once $autoloadFile;

// 未処理例外のハンドラを設定
set_exception_handler(function (\Throwable $e) {
    fwrite(STDERR, "ERROR: " . $e->getMessage() . "\n");
    exit(1);
});

// PhpSpreadsheetのキャッシュ設定
try {
    PhpOffice\PhpSpreadsheet\Settings::setCache(null);
} catch (\Exception $e) {
    // キャッシュ設定に失敗しても処理を続行
}

// 必要なクラスをインポート
use App\Utils\Analysis\SqlQueryAnalyzer;
use App\Utils\Analysis\SqlQueryParser;
use App\Utils\FileManagement\FileLoader;
use App\Utils\Analysis\FunctionAnalyzer;
use App\Utils\Analysis\IncludeAnalyzer;
use App\Utils\Analysis\ExternalAccessAnalyzer;
use App\Utils\Analysis\StoredProcedureAnalyzer;
use App\Model\InputData;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/**
 * コマンドライン引数を解析
 */
$targetDir = $argv[1] ?? './src';
$outputFile = $argv[2] ?? './output/analysis.xlsx';

// 出力ディレクトリの確認と作成
$outputDir = dirname($outputFile);
if (!is_dir($outputDir)) {
    if (!mkdir($outputDir, 0777, true)) {
        fwrite(STDERR, "ERROR: 出力ディレクトリの作成に失敗しました: {$outputDir}\n");
        exit(1);
    }
}

try {
    // 入力データの読み込み
    $inputData = new InputData();
    
    // views.txtとprocs.txtを読み込む
    try {
        $views = FileLoader::readLines(__DIR__ . '/../input/views.txt');
        $inputData->setViews($views);
        
        $procedures = FileLoader::readLines(__DIR__ . '/../input/procs.txt');
        $inputData->setStoredProcedures($procedures);
    } catch (\Exception $e) {
        fwrite(STDERR, "WARNING: 入力ファイルの読み込みに失敗しました: {$e->getMessage()}\n");
        // 入力ファイルがなくても処理は続行
    }
    
    // 解析対象のファイルを取得
    $files = [];
    if (is_file($targetDir)) {
        $files[] = $targetDir;
    } elseif (is_dir($targetDir)) {
        $files = FileLoader::getFilesRecursively($targetDir, ['php', 'inc', 'html', 'js']);
    } else {
        fwrite(STDERR, "ERROR: 指定されたパスが存在しません: {$targetDir}\n");
        exit(1);
    }
    
    if (empty($files)) {
        fwrite(STDERR, "WARNING: 解析対象のファイルが見つかりませんでした。\n");
    }
    
    // 解析用オブジェクトの初期化
    $sqlAnalyzer = new SqlQueryAnalyzer();
    $sqlParser = new SqlQueryParser();
    $functionAnalyzer = new FunctionAnalyzer();
    $includeAnalyzer = new IncludeAnalyzer();
    $externalAnalyzer = new ExternalAccessAnalyzer();
    $procAnalyzer = new StoredProcedureAnalyzer($inputData->getStoredProcedures());
    
    // 解析結果を格納する配列
    $fileCrudData = [];     // ファイル単位のCRUD
    $funcCrudData = [];     // 関数単位のCRUD
    $includeData = [];      // インクルード情報
    $externalData = [];     // 外部アクセス情報
    $procedureData = [];    // ストアドプロシージャ情報
    
    // 各ファイルを解析
    foreach ($files as $file) {
        try {
            // 相対パスの作成（出力用）
            $relativePath = is_absolute_path($file) ? $file : makeRelativePath($file, $targetDir);
            echo "Processing: {$relativePath}\n";
            
            // SQL解析
            $analysisResult = $sqlAnalyzer->analyzeFile($file);
            $queries = $analysisResult->getQueries();
            
            // ファイル単位のCRUD情報を収集
            foreach ($queries as $query) {
                if ($sqlParser->isValidSqlQuery($query['query'])) {
                    $tableOperations = $sqlParser->getTableOperations($query['query']);
                    foreach ($tableOperations as $table => $operation) {
                        $fileCrudData[] = [
                            'file' => $relativePath,
                            'table' => $table,
                            'operation' => $operation
                        ];
                    }
                }
            }
            
            // 関数解析
            $functions = $functionAnalyzer->analyzeFile($file);
            foreach ($functions as $function) {
                foreach ($function['crud'] as $table => $operation) {
                    $funcCrudData[] = [
                        'file' => $relativePath,
                        'function' => $function['name'],
                        'table' => $table,
                        'operation' => $operation
                    ];
                }
            }
            
            // インクルード解析
            $includes = $includeAnalyzer->analyzeFile($file);
            foreach ($includes as $include) {
                $includeData[] = [
                    'file' => $relativePath,
                    'include' => $include['path'],
                    'depth' => $include['depth']
                ];
            }
            
            // 外部アクセス解析
            $externalAccesses = $externalAnalyzer->analyzeFile($file);
            foreach ($externalAccesses as $access) {
                $externalData[] = [
                    'file' => $relativePath,
                    'type' => $access['type'],
                    'url' => $access['url']
                ];
            }
            
            // ストアドプロシージャ解析
            $procedures = $procAnalyzer->analyzeFile($file);
            foreach ($procedures as $procedure) {
                $procedureData[] = [
                    'file' => $relativePath,
                    'procedure' => $procedure['name'],
                    'table' => $procedure['table'] ?? '',
                    'crud' => $procedure['crud'] ?? '',
                    'args' => $procedure['args'] ?? ''
                ];
            }
            
        } catch (\Exception $e) {
            fwrite(STDERR, "[WARN] {$file}: {$e->getMessage()}\n");
            continue;
        }
    }
    
    // Excel出力
    $spreadsheet = new Spreadsheet();
    
    // シート1: ファイル単位のCRUD
    createFileCrudSheet($spreadsheet, $fileCrudData);
    
    // シート2: 関数単位のCRUD
    createFunctionCrudSheet($spreadsheet, $funcCrudData);
    
    // シート3: ストアドプロシージャ
    createProcedureSheet($spreadsheet, $procedureData);
    
    // シート4: インクルード
    createIncludeSheet($spreadsheet, $includeData);
    
    // シート5: 外部アクセス
    createExternalSheet($spreadsheet, $externalData);
    
    // Excelファイルの保存
    $writer = new Xlsx($spreadsheet);
    $writer->save($outputFile);
    
    echo "解析完了: {$outputFile}\n";
    
} catch (\Exception $e) {
    fwrite(STDERR, "ERROR: {$e->getMessage()}\n");
    exit(1);
}

/**
 * パスが絶対パスかどうかを判定
 */
function is_absolute_path(string $path): bool {
    return $path[0] === '/' || $path[0] === '\\' || 
           (strlen($path) > 1 && ctype_alpha($path[0]) && $path[1] === ':');
}

/**
 * 相対パスを作成
 */
function makeRelativePath(string $path, string $basePath): string {
    $path = realpath($path);
    $basePath = realpath($basePath);
    
    if (strpos($path, $basePath) === 0) {
        $relativePath = substr($path, strlen($basePath));
        return ltrim($relativePath, '/\\');
    }
    
    return $path;
}

/**
 * ファイル単位のCRUDシートを作成
 */
function createFileCrudSheet(Spreadsheet $spreadsheet, array $data): void {
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('File-CRUD');
    
    // ヘッダー設定
    $sheet->setCellValue('A1', 'file');
    $sheet->setCellValue('B1', 'table');
    $sheet->setCellValue('C1', 'C');
    $sheet->setCellValue('D1', 'R');
    $sheet->setCellValue('E1', 'U');
    $sheet->setCellValue('F1', 'D');
    
    // データ設定
    $row = 2;
    $currentFile = '';
    
    foreach ($data as $item) {
        // ファイル名が変わったら空行を挿入
        if ($currentFile !== '' && $currentFile !== $item['file']) {
            $row++;
        }
        
        // ファイル名は最初の1回のみ出力
        $sheet->setCellValue('A' . $row, ($currentFile !== $item['file']) ? $item['file'] : '');
        $sheet->setCellValue('B' . $row, $item['table']);
        
        // CRUD操作を対応するセルに設定
        $operations = str_split($item['operation']);
        foreach ($operations as $op) {
            switch ($op) {
                case 'C': $sheet->setCellValue('C' . $row, 'x'); break;
                case 'R': $sheet->setCellValue('D' . $row, 'x'); break;
                case 'U': $sheet->setCellValue('E' . $row, 'x'); break;
                case 'D': $sheet->setCellValue('F' . $row, 'x'); break;
            }
        }
        
        $currentFile = $item['file'];
        $row++;
    }
}

/**
 * 関数単位のCRUDシートを作成
 */
function createFunctionCrudSheet(Spreadsheet $spreadsheet, array $data): void {
    $sheet = $spreadsheet->createSheet();
    $sheet->setTitle('Func-CRUD');
    
    // ヘッダー設定
    $sheet->setCellValue('A1', 'file');
    $sheet->setCellValue('B1', 'function');
    $sheet->setCellValue('C1', 'table');
    $sheet->setCellValue('D1', 'C');
    $sheet->setCellValue('E1', 'R');
    $sheet->setCellValue('F1', 'U');
    $sheet->setCellValue('G1', 'D');
    
    // データ設定
    $row = 2;
    $currentFile = '';
    
    foreach ($data as $item) {
        // ファイル名が変わったら空行を挿入
        if ($currentFile !== '' && $currentFile !== $item['file']) {
            $row++;
        }
        
        // ファイル名は最初の1回のみ出力
        $sheet->setCellValue('A' . $row, ($currentFile !== $item['file']) ? $item['file'] : '');
        $sheet->setCellValue('B' . $row, $item['function']);
        $sheet->setCellValue('C' . $row, $item['table']);
        
        // CRUD操作を対応するセルに設定
        $operations = str_split($item['operation']);
        foreach ($operations as $op) {
            switch ($op) {
                case 'C': $sheet->setCellValue('D' . $row, 'x'); break;
                case 'R': $sheet->setCellValue('E' . $row, 'x'); break;
                case 'U': $sheet->setCellValue('F' . $row, 'x'); break;
                case 'D': $sheet->setCellValue('G' . $row, 'x'); break;
            }
        }
        
        $currentFile = $item['file'];
        $row++;
    }
}

/**
 * ストアドプロシージャシートを作成
 */
function createProcedureSheet(Spreadsheet $spreadsheet, array $data): void {
    $sheet = $spreadsheet->createSheet();
    $sheet->setTitle('Procedures');
    
    // ヘッダー設定
    $sheet->setCellValue('A1', 'file');
    $sheet->setCellValue('B1', 'procedure');
    $sheet->setCellValue('C1', 'table');
    $sheet->setCellValue('D1', 'CRUD');
    $sheet->setCellValue('E1', 'args');
    
    // データ設定
    $row = 2;
    $currentFile = '';
    
    foreach ($data as $item) {
        // ファイル名が変わったら空行を挿入
        if ($currentFile !== '' && $currentFile !== $item['file']) {
            $row++;
        }
        
        // ファイル名は最初の1回のみ出力
        $sheet->setCellValue('A' . $row, ($currentFile !== $item['file']) ? $item['file'] : '');
        $sheet->setCellValue('B' . $row, $item['procedure']);
        $sheet->setCellValue('C' . $row, $item['table']);
        $sheet->setCellValue('D' . $row, $item['crud']);
        $sheet->setCellValue('E' . $row, $item['args']);
        
        $currentFile = $item['file'];
        $row++;
    }
}

/**
 * インクルードシートを作成
 */
function createIncludeSheet(Spreadsheet $spreadsheet, array $data): void {
    $sheet = $spreadsheet->createSheet();
    $sheet->setTitle('Includes');
    
    // ヘッダー設定
    $sheet->setCellValue('A1', 'file');
    $sheet->setCellValue('B1', 'include');
    $sheet->setCellValue('C1', 'depth');
    
    // データ設定
    $row = 2;
    $currentFile = '';
    
    foreach ($data as $item) {
        // ファイル名が変わったら空行を挿入
        if ($currentFile !== '' && $currentFile !== $item['file']) {
            $row++;
        }
        
        // ファイル名は最初の1回のみ出力
        $sheet->setCellValue('A' . $row, ($currentFile !== $item['file']) ? $item['file'] : '');
        $sheet->setCellValue('B' . $row, $item['include']);
        $sheet->setCellValue('C' . $row, $item['depth']);
        
        $currentFile = $item['file'];
        $row++;
    }
}

/**
 * 外部アクセスシートを作成
 */
function createExternalSheet(Spreadsheet $spreadsheet, array $data): void {
    $sheet = $spreadsheet->createSheet();
    $sheet->setTitle('External');
    
    // ヘッダー設定
    $sheet->setCellValue('A1', 'file');
    $sheet->setCellValue('B1', 'type');
    $sheet->setCellValue('C1', 'url');
    
    // データ設定
    $row = 2;
    $currentFile = '';
    
    foreach ($data as $item) {
        // ファイル名が変わったら空行を挿入
        if ($currentFile !== '' && $currentFile !== $item['file']) {
            $row++;
        }
        
        // ファイル名は最初の1回のみ出力
        $sheet->setCellValue('A' . $row, ($currentFile !== $item['file']) ? $item['file'] : '');
        $sheet->setCellValue('B' . $row, $item['type']);
        $sheet->setCellValue('C' . $row, $item['url']);
        
        $currentFile = $item['file'];
        $row++;
    }
} 