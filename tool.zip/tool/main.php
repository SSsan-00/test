<?php
// テスト: ビューを使用するSQL
$sql_view = "SELECT * FROM view_users WHERE status = 'active'";

// テスト: ストアドプロシージャを呼び出し
$sql_sp = "CALL proc_add_user('Taro', 'taro@example.com')";
?>