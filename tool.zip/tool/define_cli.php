#!/usr/bin/env php
<?php

require_once './includes_check.php'; // include解決用
require_once './find_define.php';          // define抽出用

$target = $argv[1] ?? '';
if (!file_exists($target)) {
    echo "対象ファイルが存在しません: $target\n";
    exit(1);
}

// 統合コード取得
$visited = [];
$code = collectCodeWithIncludes($target, $visited);

// define 抽出
$defines = extractDefines($code);

echo "===== 抽出された定数一覧 =====\n";
foreach ($defines as $key => $val) {
    echo "$key = \"$val\"\n";
}
