<?php
#!/usr/bin/env php
/**
 * analyzer.php — 完全対応 PHP ソースコード解析ツール（文字列結合再構築対応）
 *
 * - include/require の再帰解決
 * - define() 定数の抽出・展開
 * - 変数代入の評価
 * - ユーザー定義関数の戻りSQL評価
 * - 文字列結合（.）再構築（AST解析）
 * - php-sql-parser による CRUD 判定
 */

require 'vendor/autoload.php';
use PHPSQLParser\PHPSQLParser;
use PhpParser\ParserFactory;
use PhpParser\Node;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;
use PhpParser\Node\Expr;

function collectCodeWithIncludes(string $filepath, array &$visited = [], string $baseDir = ''): string {
    $baseDir = $baseDir ?: dirname($filepath);
    $realpath = realpath($filepath);
    if (!$realpath || isset($visited[$realpath])) return '';
    $visited[$realpath] = true;

    $code = file_get_contents($realpath);
    $merged = $code;
    if (preg_match_all('/\b(include|require)(_once)?\s*\(?\s*[\"\'](.+?)[\"\']\s*\)?\s*;/', $code, $m)) {
        foreach ($m[3] as $inc) {
            $path = realpath($baseDir . DIRECTORY_SEPARATOR . $inc);
            if ($path && file_exists($path)) {
                $merged .= "\n" . collectCodeWithIncludes($path, $visited, dirname($path));
            }
        }
    }
    return $merged;
}

function extractDefines(string $code): array {
    $defs = [];
    if (preg_match_all('/define\s*\(\s*[\"\'](\w+)[\"\']\s*,\s*[\"\'](.+?)[\"\']\s*\)\s*;/', $code, $m, PREG_SET_ORDER)) {
        foreach ($m as $d) $defs[$d[1]] = $d[2];
    }
    return $defs;
}

function extractSQLReturningFunctions(string $code): array {
    $parser = (new ParserFactory())->createForNewestSupportedVersion();
    $ast = $parser->parse($code);
    $functions = [];

    $traverser = new NodeTraverser();
    $traverser->addVisitor(new class($functions) extends NodeVisitorAbstract {
        private $functions;
        public function __construct(&$functions) { $this->functions = &$functions; }
        public function enterNode(Node $node) {
            if ($node instanceof Node\Stmt\Function_) {
                $name = $node->name->toString();
                foreach ($node->stmts as $stmt) {
                    if ($stmt instanceof Node\Stmt\Return_ && $stmt->expr instanceof Node\Scalar\String_) {
                        $this->functions[$name] = $stmt->expr->value;
                    }
                }
            }
        }
    });
    $traverser->traverse($ast);
    return $functions;
}

function evaluateConcatExpr($expr, $variables, $defines, $functions): string {
    if ($expr instanceof Node\Scalar\String_) {
        return $expr->value;
    } elseif ($expr instanceof Node\Expr\Variable && is_string($expr->name)) {
        return $variables[$expr->name] ?? $defines[$expr->name] ?? '';
    } elseif ($expr instanceof Node\Expr\ConstFetch) {
        return $defines[$expr->name->toString()] ?? '';
    } elseif ($expr instanceof Expr\FuncCall && $expr->name instanceof Node\Name) {
        $fname = $expr->name->toString();
        return $functions[$fname] ?? '';
    } elseif ($expr instanceof Node\Expr\BinaryOp\Concat) {
        return evaluateConcatExpr($expr->left, $variables, $defines, $functions) .
               evaluateConcatExpr($expr->right, $variables, $defines, $functions);
    }
    return '';
}

function resolveSQLWithAST(string $code, array $defines, array $functions, array $vars): array {
    $parser = (new ParserFactory())->createForNewestSupportedVersion();
    $ast = $parser->parse($code);
    $sqls = [];

    $traverser = new NodeTraverser();
    $traverser->addVisitor(new class($sqls, $defines, $functions, $vars) extends NodeVisitorAbstract {
        private $sqls, $defines, $functions, $vars;
        public function __construct(&$sqls, $defines, $functions, $vars) {
            $this->sqls = &$sqls;
            $this->defines = $defines;
            $this->functions = $functions;
            $this->vars = $vars;
        }
        public function enterNode(Node $node) {
            if ($node instanceof Expr\Assign && $node->var instanceof Node\Expr\Variable && is_string($node->var->name)) {
                $varName = $node->var->name;
                $sql = evaluateConcatExpr($node->expr, $this->vars, $this->defines, $this->functions);
                if (stripos($sql, 'select') !== false || stripos($sql, 'insert') !== false || stripos($sql, 'update') !== false || stripos($sql, 'delete') !== false) {
                    $this->sqls[$varName] = $sql;
                }
            }
        }
    });
    $traverser->traverse($ast);
    return $sqls;
}

function analyzeSQL(string $sql): array {
    $parser = new PHPSQLParser();
    $parsed = $parser->parse($sql);
    $result = [];
    if (isset($parsed['INSERT'])) { $tables = $parsed['INSERT']; $type = 'C'; }
    elseif (isset($parsed['UPDATE'])) { $tables = $parsed['UPDATE']; $type = 'U'; }
    elseif (isset($parsed['DELETE'])) { $tables = $parsed['FROM'];   $type = 'D'; }
    elseif (isset($parsed['FROM']))   { $tables = $parsed['FROM'];   $type = 'R'; }
    else { return []; }
    foreach ($tables as $t) {
        if ($t['expr_type'] === 'table') $result[$t['table']] = $type;
    }
    if (isset($parsed['JOIN'])) {
        foreach ($parsed['JOIN'] as $j) {
            if ($j['expr_type'] === 'table') $result[$j['table']] = 'R';
        }
    }
    return $result;
}

function getTargetFiles(string $path): array {
    $targets = [];
    if (is_file($path)) {
        $targets[] = realpath($path);
    } elseif (is_dir($path)) {
        $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));
        foreach ($rii as $file) {
            if ($file->isFile()) {
                $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if (in_array($ext, ['php', 'inc'])) {
                    $targets[] = $file->getRealPath();
                }
            }
        }
    }
    return $targets;
}

$input = $argv[1] ?? '';
if (!$input || !file_exists($input)) {
    fwrite(STDERR, "Usage: php analyzer.php /path/to/file_or_directory\n");
    exit(1);
}

$files = getTargetFiles($input);

foreach ($files as $target) {
    echo "=== $target ===\n";
    $visited = [];
    $code = collectCodeWithIncludes($target, $visited);
    $defines = extractDefines($code);
    $functions = extractSQLReturningFunctions($code);
    $lines = explode("\n", $code);

    // 変数の代入抽出（正規表現ベース）
    $vars = [];
    foreach ($lines as $line) {
        if (preg_match('/\$(\w+)\s*=\s*\"(.+)\"\s*;/', $line, $m) || preg_match('/\$(\w+)\s*=\s*\'(.*)\'\s*;/', $line, $m)) {
            $vars[$m[1]] = $m[2];
        }
    }

    // ASTベースでSQL構築式の再構築
    $sqls = resolveSQLWithAST($code, $defines, $functions, $vars);

    foreach ($sqls as $var => $sql) {
        $result = analyzeSQL($sql);
        foreach ($result as $table => $crud) {
            echo "Var: \$$var | Table: $table | Op: $crud\n";
        }
    }
    echo "\n";
}
