<?php
#!/usr/bin/env php
/**
 * analyzer.php — 完全版 PHP ソースコード解析ツール
 *
 * - 抽出: SQL文字列, CTE, サブクエリ, 一時テーブル
 * - 解析: PHP-SQL-Parser + 正規表現フォールバック
 * - CRUD分類 (C/R/U/D), 注釈 (@cte, @temp)
 */

require 'vendor/autoload.php';
use PHPSQLParser\PHPSQLParser;

// SQL文字列を抽出
function extractSQLStrings(string $code): array {
    preg_match_all('/\$\w+\s*=\s*"(.+?)";/s', $code, $m);
    return $m[1] ?? [];
}

// CTE (WITH句) を抽出
function extractCTEs(string $sql): array {
    $ctes = [];
    if (preg_match_all('/WITH\s+(\w+)\s+AS\s*\((.*?)\)\s*(?=SELECT)/is', $sql, $m)) {
        foreach ($m[1] as $i => $name) {
            $ctes[$name] = $m[2][$i];
        }
    }
    return $ctes;
}

// サブクエリ (FROM (...)) を抽出
function extractSubqueries(string $sql): array {
    preg_match_all('/FROM\s*\(\s*(SELECT.+?)\)\s*(?:\w+)?/is', $sql, $m);
    return $m[1] ?? [];
}

// 一時テーブル検出
function detectTempTables(string $sql): array {
    $temps = [];
    // CREATE TEMP[TORARY] TABLE
    if (preg_match('/CREATE\s+TEMP(?:ORARY)?\s+TABLE\s+(\w+)/i', $sql, $m)) {
        $temps[] = ['table'=>$m[1],'op'=>'C','note'=>'@temp'];
    }
    // SELECT ... INTO temp
    if (preg_match('/SELECT\b.+?\bINTO\s+(\w+)/is', $sql, $m)) {
        $temps[] = ['table'=>$m[1],'op'=>'C','note'=>'@temp'];
    }
    return $temps;
}

// SQL解析 (sub_treeを有効)
function parseSQL(string $sql): array {
    $parser = new PHPSQLParser();
    return $parser->parse($sql, true);
}

// collectTables: parsed構造からテーブルとCRUDを取得
function collectTables(array $parsed): array {
    $res = [];
    foreach (['FROM','JOIN','UPDATE','INSERT','DELETE'] as $clause) {
        if (empty($parsed[$clause])) continue;
        foreach ($parsed[$clause] as $entry) {
            $expr = $entry['expr_type'] ?? '';
            if ($expr === 'table') {
                $name = $entry['table'];
                $op = $clause === 'INSERT' ? 'C' : ($clause==='UPDATE'?'U':($clause==='DELETE'?'D':'R'));
                $res[$name] = $op;
            } elseif ($expr === 'subquery' && !empty($entry['sub_tree'])) {
                $sub = collectTables($entry['sub_tree']);
                foreach ($sub as $t => $o) { $res[$t] = $o; }
            }
        }
    }
    return $res;
}

// メイン
$input = $argv[1] ?? '';
if (!$input || !file_exists($input)) {
    fwrite(STDERR,"Usage: php analyzer.php /path/to/file.php\n"); exit(1);
}

$code = file_get_contents($input);
$sqls = extractSQLStrings($code);

foreach ($sqls as $sql) {
    $result = [];
    // 一時テーブル
    foreach (detectTempTables($sql) as $tmp) {
        $result[$tmp['table']] = ['op'=>$tmp['op'],'note'=>$tmp['note']];
    }
    // CTE
    foreach (extractCTEs($sql) as $cteName => $sub) {
        $result[$cteName] = ['op'=>'@cte','note'=>''];
        $parsed = parseSQL($sub);
        foreach (collectTables($parsed) as $t => $o) {
            if (!isset($result[$t])) $result[$t]=['op'=>$o,'note'=>''];
        }
    }
    // サブクエリ
    foreach (extractSubqueries($sql) as $sub) {
        $parsed = parseSQL($sub);
        foreach (collectTables($parsed) as $t => $o) {
            if (!isset($result[$t])) $result[$t]=['op'=>$o,'note'=>''];
        }
    }
    // 本文
    $parsed = parseSQL($sql);
    foreach (collectTables($parsed) as $t => $o) {
        if (!isset($result[$t])) $result[$t]=['op'=>$o,'note'=>''];
    }
    // 出力
    foreach ($result as $t => $info) {
        echo "Table: $t | Op: {$info['op']}";
        if ($info['note']) echo " | 注釈: {$info['note']}";
        echo "\n";
    }
    echo "\n";
}
