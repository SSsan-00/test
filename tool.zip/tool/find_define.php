<?php

/**
 * 統合コード内から define 定義を抽出して連想配列として返す
 * 例: define("TBL_USERS", "users"); → ['TBL_USERS' => 'users']
 */
function extractDefines(string $code): array {
    $defines = [];

    if (preg_match_all('/define\s*\(\s*[\'"](\w+)[\'"]\s*,\s*[\'"](.+?)[\'"]\s*\)\s*;/', $code, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $defines[$m[1]] = $m[2];
        }
    }

    return $defines;
}
