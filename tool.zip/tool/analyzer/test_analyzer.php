<?php
declare(strict_types=1);

// 必要なクラスと関数を直接インポート
use PhpParser\{ParserFactory, NodeTraverser, NodeVisitorAbstract, Error as PhpParserError};
use PhpParser\Node;
use PhpParser\Node\Expr\BinaryOp\Concat;
use PhpParser\Node\Scalar\String_;
use PhpParser\Node\Expr\Variable;
use PHPSQLParser\PHPSQLParser;
use PhpOffice\PhpSpreadsheet\{Spreadsheet, Writer\Xlsx, IOFactory};
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

require_once __DIR__ . '/vendor/autoload.php';

// テスト用のディレクトリ構造を確認
$inputDir = __DIR__ . '/../input';
$outputDir = __DIR__ . '/../output';

if (!is_dir($inputDir)) {
    die("入力ディレクトリが見つかりません: {$inputDir}\n");
}

if (!is_dir($outputDir)) {
    die("出力ディレクトリが見つかりません: {$outputDir}\n");
}

// テスト実行
echo "=== アナライザーテスト開始 ===\n";

// 1. メタデータの読み込みテスト
echo "\n1. メタデータ読み込みテスト:\n";
$views = [];
$procedures = [];
$crudData = [];
$logData = [];

// メタデータ読み込み関数
function loadMetaData(string $baseDir, array &$views, array &$procedures, array &$crudData, array &$logData): void {
    foreach (['view_list.txt' => &$views, 'procedure_list.txt' => &$procedures] as $f => &$dest) {
        $fp = "{$baseDir}/{$f}";
        if (is_file($fp)) {
            $dest = array_filter(array_map('trim', file($fp)));
        }
    }
}

loadMetaData(__DIR__, $views, $procedures, $crudData, $logData);

echo "ビュー一覧:\n";
print_r($views);
echo "\nプロシージャ一覧:\n";
print_r($procedures);

// 2. ファイル走査テスト
echo "\n2. ファイル走査テスト:\n";
function fileGenerator(string $dir): \Generator {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
    foreach ($it as $f) {
        if ($f->isDir())
            continue;
        if (!preg_match('/\.(php|inc|js|html)$/i', $f->getFilename()))
            continue;
        yield $f->getPathname();
    }
}

$files = iterator_to_array(fileGenerator($inputDir));
echo "検出されたファイル数: " . count($files) . "\n";
foreach ($files as $file) {
    echo "- " . basename($file) . "\n";
}

// 3. SQL解析テスト
echo "\n3. SQL解析テスト:\n";
function stripComments(string $code, string $file, array &$logData): string {
    $patterns = [
        '/<!--.*?-->/s',
        '/\/\*.*?\*\//s',
        '/\/\/[^\n]*/',
        '/#(?!\{).*?$/m'
    ];
    $clean = @preg_replace($patterns, '', $code);
    if ($clean === null) {
        $logData[] = ['file' => $file, 'line' => 0, 'msg' => 'preg_replace 失敗 — コメント除去スキップ'];
        return $code;
    }
    return $clean;
}

function analyzeWithPhpParser(string $code): array {
    $parser = (new ParserFactory())->createForNewestSupportedVersion();
    $ast = $parser->parse($code);
    
    $visitor = new class extends NodeVisitorAbstract {
        private $fragments = [];
        
        public function leaveNode(Node $node) {
            if ($node instanceof Concat) {
                $this->extractSqlFromConcat($node);
            } elseif ($node instanceof String_) {
                $this->extractSqlFromString($node);
            }
        }

        private function extractSqlFromConcat(Concat $node) {
            $left = $this->getStringValue($node->left);
            $right = $this->getStringValue($node->right);
            
            if ($left !== null && $right !== null) {
                $sql = $left . $right;
                if (preg_match('/\b(SELECT|INSERT|UPDATE|DELETE|WITH)\b/i', $sql)) {
                    $this->fragments[] = $sql;
                }
            }
        }

        private function extractSqlFromString(String_ $node) {
            $sql = $node->value;
            if (preg_match('/\b(SELECT|INSERT|UPDATE|DELETE|WITH)\b/i', $sql)) {
                $this->fragments[] = $sql;
            }
        }

        private function getStringValue($node): ?string {
            if ($node instanceof String_) {
                return $node->value;
            } elseif ($node instanceof Variable) {
                return null;
            }
            return null;
        }

        public function getFragments(): array {
            return $this->fragments;
        }
    };

    $traverser = new NodeTraverser();
    $traverser->addVisitor($visitor);
    $traverser->traverse($ast);
    
    return $visitor->getFragments();
}

$sampleFile = $inputDir . '/php/sample_queries.php';
if (file_exists($sampleFile)) {
    $code = file_get_contents($sampleFile);
    $codeClean = stripComments($code, 'sample_queries.php', $logData);
    
    try {
        $sqlFragments = analyzeWithPhpParser($codeClean);
        echo "抽出されたSQLフラグメント数: " . count($sqlFragments) . "\n";
        foreach ($sqlFragments as $fragment) {
            echo "- " . substr($fragment, 0, 50) . "...\n";
        }
    } catch (Exception $e) {
        echo "解析エラー: " . $e->getMessage() . "\n";
    }
} else {
    echo "サンプルファイルが見つかりません\n";
}

// 4. CRUD解析テスト
echo "\n4. CRUD解析テスト:\n";
function analyzeSQL(string $sql, array $views, array $procedures): array {
    // CALLステートメントの検出
    if (preg_match('/CALL\s+(\w+)/i', $sql, $matches)) {
        $procName = $matches[1];
        if (in_array($procName, $procedures)) {
            return ["{$procName}@proc" => ['C' => 1, 'R' => 1, 'U' => 1, 'D' => 1]];
        }
    }

    try {
        $parser = new PHPSQLParser();
        $tree = $parser->parse($sql);

        if (!is_array($tree)) {
            throw new Exception("SQLの解析に失敗しました");
        }

        $resolver = new CrudResolver($views, $procedures);
        return $resolver->resolve($tree);
    } catch (Exception $e) {
        error_log("SQL解析エラー: " . $e->getMessage());
        return [];
    }
}

class CrudResolver {
    public function __construct(
        private array $views,
        private array $procedures
    ) {
    }

    public function resolve(array $sqlTree): array {
        $crudOps = [];
        
        // クエリタイプの判定
        $type = '';
        if (isset($sqlTree['SELECT'])) {
            $type = 'SELECT';
        } elseif (isset($sqlTree['INSERT'])) {
            $type = 'INSERT';
        } elseif (isset($sqlTree['UPDATE'])) {
            $type = 'UPDATE';
        } elseif (isset($sqlTree['DELETE'])) {
            $type = 'DELETE';
        }
        
        // テーブル名の抽出
        $tables = $this->extractTables($sqlTree);
        
        foreach ($tables as $table) {
            $crudOps[$table] = [
                'C' => ($type === 'INSERT') ? 1 : 0,
                'R' => ($type === 'SELECT') ? 1 : 0,
                'U' => ($type === 'UPDATE') ? 1 : 0,
                'D' => ($type === 'DELETE') ? 1 : 0
            ];
            
            // ビュー/プロシージャのチェック
            if (in_array($table, $this->views)) {
                $crudOps["{$table}@view"] = $crudOps[$table];
            }
            if (in_array($table, $this->procedures)) {
                $crudOps["{$table}@proc"] = $crudOps[$table];
            }
        }
        
        return $crudOps;
    }
    
    private function extractTables(array $sqlTree): array {
        $tables = [];
        
        // FROM句のテーブル
        if (isset($sqlTree['FROM'])) {
            foreach ($sqlTree['FROM'] as $from) {
                if (isset($from['table'])) {
                    $tables[] = $from['table'];
                }
            }
        }
        
        // INSERT/UPDATEのテーブル
        if (isset($sqlTree['INSERT'])) {
            foreach ($sqlTree['INSERT'] as $insert) {
                if (isset($insert['table'])) {
                    $tables[] = $insert['table'];
                }
            }
        }
        if (isset($sqlTree['UPDATE'])) {
            foreach ($sqlTree['UPDATE'] as $update) {
                if (isset($update['table'])) {
                    $tables[] = $update['table'];
                }
            }
        }
        
        // WITH句のテーブル
        if (isset($sqlTree['WITH'])) {
            foreach ($sqlTree['WITH'] as $with) {
                if (isset($with['name'])) {
                    $tables[] = $with['name'];
                }
            }
        }
        
        return array_unique($tables);
    }
}

if (!empty($sqlFragments)) {
    foreach ($sqlFragments as $sql) {
        try {
            $crudOps = analyzeSQL($sql, $views, $procedures);
            echo "SQL: " . substr($sql, 0, 50) . "...\n";
            echo "CRUD操作:\n";
            print_r($crudOps);
        } catch (Exception $e) {
            echo "CRUD解析エラー: " . $e->getMessage() . "\n";
        }
    }
}

// 5. エクスポートテスト
echo "\n5. エクスポートテスト:\n";
function exportExcel(array $crudData, array $logData, string $outputDir): void {
    $ss = new Spreadsheet();

    $ws = $ss->getActiveSheet()->setTitle('File-CRUD');
    $row = 1;
    foreach ($crudData as $file => $tables) {
        $first = true;
        foreach ($tables as $table => $ops) {
            if ($first) {
                $ws->setCellValue("A{$row}", $file);
                $first = false;
            }
            $ws->setCellValue("B{$row}", $table);
            $ws->setCellValue("C{$row}", $ops['C'] ? '○' : '');
            $ws->setCellValue("D{$row}", $ops['R'] ? '○' : '');
            $ws->setCellValue("E{$row}", $ops['U'] ? '○' : '');
            $ws->setCellValue("F{$row}", $ops['D'] ? '○' : '');
            $row++;
        }
        $row++;
    }

    $logWs = $ss->createSheet()->setTitle('LOG');
    $logWs->fromArray(['file', 'line', 'message'], null, 'A1');
    $logWs->fromArray(array_map(fn($l) => array_values($l), $logData), null, 'A2');

    $name = $outputDir . '/analyze_result_' . date('Ymd_His') . '.xlsx';
    (new Xlsx($ss))->save($name);
    echo "Excel 出力完了: {$name}\n";
}

try {
    exportExcel($crudData, $logData, $outputDir);
    echo "Excelファイルのエクスポートに成功しました\n";
} catch (Exception $e) {
    echo "エクスポートエラー: " . $e->getMessage() . "\n";
}

echo "\n=== アナライザーテスト終了 ===\n"; 