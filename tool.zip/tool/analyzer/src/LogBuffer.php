<?php

declare(strict_types=1);

namespace Analyzer;

class LogBuffer
{
    private static array $logs = [];

    public static function add(string $level, string $message, string $file = '', int $line = 0): void
    {
        $log = [
            'level' => $level,
            'message' => $message,
            'file' => $file,
            'line' => $line,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        self::$logs[] = $log;

        if ($level === 'ERROR') {
            fwrite(STDERR, sprintf(
                "ERROR: %s (%s:%d)\n",
                $message,
                $file,
                $line
            ));
        }
    }

    public static function getLogs(): array
    {
        return self::$logs;
    }

    public static function clear(): void
    {
        self::$logs = [];
    }
} 