<?php

declare(strict_types=1);

namespace Analyzer;

class FallbackAnalyzer {
    private const SQL_PATTERNS = [
        'SELECT' => [
            '/\bSELECT\b.*?\bFROM\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bSELECT\b.*?\bJOIN\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bSELECT\b.*?\bINTO\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ],
        'INSERT' => [
            '/\bINSERT\s+INTO\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bINSERT\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ],
        'UPDATE' => [
            '/\bUPDATE\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bUPDATE\b.*?\bSET\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ],
        'DELETE' => [
            '/\bDELETE\s+FROM\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bDELETE\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ],
        'WITH' => [
            '/\bWITH\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bWITH\s+RECURSIVE\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ]
    ];
    
    private const VARIABLE_PATTERN = '/\$([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*([^;]+);/';
    private const FUNCTION_PATTERN = '/function\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\((.*?)\)\s*{/';
    private const INCLUDE_PATTERN = '/(include|require)(?:_once)?\s*\(?\s*[\'"]([^\'"]*)[\'"]\s*\)?/';
    
    public function analyzeSQL(string $code): array {
        $results = [];
        $code = $this->preprocessCode($code);
        
        foreach (self::SQL_PATTERNS as $type => $patterns) {
            foreach ($patterns as $pattern) {
                if (preg_match_all($pattern, $code, $matches)) {
                    foreach ($matches[1] as $table) {
                        $table = trim($table);
                        if (!empty($table)) {
                            $results[] = [
                                'type' => $type,
                                'table' => $table,
                                'sql' => $matches[0][0] ?? ''
                            ];
                        }
                    }
                }
            }
        }
        
        // 変数内のSQLを検出
        $variables = $this->analyzeVariables($code);
        foreach ($variables as $varName => $value) {
            if (preg_match('/\b(SELECT|INSERT|UPDATE|DELETE|WITH)\b/i', $value)) {
                $results[] = [
                    'type' => 'VARIABLE',
                    'table' => $varName,
                    'sql' => $value
                ];
            }
        }
        
        return $results;
    }
    
    private function preprocessCode(string $code): string {
        // コメントを除去
        $code = preg_replace('/\/\*.*?\*\//s', '', $code);
        $code = preg_replace('/\/\/.*?$/m', '', $code);
        $code = preg_replace('/#.*?$/m', '', $code);
        
        // 文字列リテラルを一時的に置換
        $strings = [];
        $code = preg_replace_callback('/[\'"](.*?)[\'"]/s', function($matches) use (&$strings) {
            $key = '___STRING_' . count($strings) . '___';
            $strings[$key] = $matches[0];
            return $key;
        }, $code);
        
        // 文字列を元に戻す
        foreach ($strings as $key => $value) {
            $code = str_replace($key, $value, $code);
        }
        
        return $code;
    }
    
    public function analyzeVariables(string $code): array {
        $variables = [];
        if (preg_match_all(self::VARIABLE_PATTERN, $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $variables[$match[1]] = trim($match[2]);
            }
        }
        return $variables;
    }
    
    public function analyzeFunctions(string $code): array {
        $functions = [];
        if (preg_match_all(self::FUNCTION_PATTERN, $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $functions[$match[1]] = [
                    'params' => $this->parseParameters($match[2]),
                    'body' => $this->extractFunctionBody($code, $match[0])
                ];
            }
        }
        return $functions;
    }
    
    public function analyzeIncludes(string $code): array {
        $includes = [];
        if (preg_match_all(self::INCLUDE_PATTERN, $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $includes[] = [
                    'type' => $match[1],
                    'path' => $match[2]
                ];
            }
        }
        return $includes;
    }
    
    private function parseParameters(string $paramString): array {
        $params = [];
        $paramString = trim($paramString);
        if (empty($paramString)) {
            return $params;
        }
        
        $paramParts = explode(',', $paramString);
        foreach ($paramParts as $param) {
            $param = trim($param);
            if (strpos($param, '$') === 0) {
                $params[] = substr($param, 1);
            }
        }
        return $params;
    }
    
    private function extractFunctionBody(string $code, string $functionStart): string {
        $startPos = strpos($code, $functionStart) + strlen($functionStart);
        $level = 0;
        $body = '';
        
        for ($i = $startPos; $i < strlen($code); $i++) {
            if ($code[$i] === '{') {
                $level++;
            } elseif ($code[$i] === '}') {
                $level--;
                if ($level === 0) {
                    break;
                }
            }
            $body .= $code[$i];
        }
        
        return trim($body);
    }
} 