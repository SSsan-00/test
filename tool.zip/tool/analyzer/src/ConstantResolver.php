<?php

declare(strict_types=1);

namespace Analyzer;

use PhpParser\Node;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;

class ConstantResolver
{
    private array $constants = [];
    private array $conditionalConstants = [];

    public function __construct()
    {
        $this->constants = get_defined_constants(true)['user'] ?? [];
    }

    public function collectConstants(array $ast): void
    {
        $visitor = new class($this->constants, $this->conditionalConstants) extends NodeVisitorAbstract {
            private array $constants;
            private array $conditionalConstants;
            private array $currentCondition = [];

            public function __construct(array &$constants, array &$conditionalConstants)
            {
                $this->constants = &$constants;
                $this->conditionalConstants = &$conditionalConstants;
            }

            public function enterNode(Node $node)
            {
                if ($node instanceof Node\Stmt\If_) {
                    $this->enterCondition($node->cond);
                    return null;
                }

                if ($node instanceof Node\Expr\FuncCall && $node->name instanceof Node\Name) {
                    if ($node->name->toString() === 'define') {
                        if (isset($node->args[0], $node->args[1])) {
                            $name = $this->evaluateValue($node->args[0]->value);
                            $value = $this->evaluateValue($node->args[1]->value);
                            if (is_string($name)) {
                                if (!empty($this->currentCondition)) {
                                    $this->conditionalConstants[$name][] = [
                                        'value' => $value,
                                        'condition' => $this->currentCondition
                                    ];
                                } else {
                                    $this->constants[$name] = $value;
                                }
                            }
                        }
                    }
                }
            }

            public function leaveNode(Node $node)
            {
                if ($node instanceof Node\Stmt\If_) {
                    array_pop($this->currentCondition);
                }
            }

            private function enterCondition(Node $condition)
            {
                $condStr = $this->getConditionString($condition);
                if ($condStr) {
                    $this->currentCondition[] = $condStr;
                }
            }

            private function getConditionString(Node $node): string
            {
                if ($node instanceof Node\Expr\BinaryOp\Equal) {
                    $left = $this->evaluateValue($node->left);
                    $right = $this->evaluateValue($node->right);
                    return "{$left} === {$right}";
                }
                if ($node instanceof Node\Expr\BinaryOp\BooleanAnd) {
                    $left = $this->getConditionString($node->left);
                    $right = $this->getConditionString($node->right);
                    return "({$left} && {$right})";
                }
                return '';
            }

            private function evaluateValue(Node $node)
            {
                if ($node instanceof Node\Scalar\String_) {
                    return $node->value;
                } elseif ($node instanceof Node\Scalar\LNumber) {
                    return $node->value;
                } elseif ($node instanceof Node\Scalar\DNumber) {
                    return $node->value;
                } elseif ($node instanceof Node\Expr\ConstFetch) {
                    $constName = $node->name->toString();
                    if (defined($constName)) {
                        return constant($constName);
                    }
                    return null;
                }
                return null;
            }
        };

        $traverser = new NodeTraverser();
        $traverser->addVisitor($visitor);
        $traverser->traverse($ast);
    }

    public function resolveConstant(string $name)
    {
        // 通常の定数値を確認
        if (isset($this->constants[$name])) {
            return $this->constants[$name];
        }

        // 条件付き定数値を確認
        if (isset($this->conditionalConstants[$name])) {
            $values = array_map(function($item) {
                return $item['value'];
            }, $this->conditionalConstants[$name]);
            return $values;
        }

        return null;
    }

    public function resolveString(string $str): string
    {
        return preg_replace_callback('/\b([A-Z][A-Z0-9_]*)\b/', function($matches) {
            $values = $this->resolveConstant($matches[1]);
            if (is_array($values)) {
                // 配列の各要素を文字列に変換
                $stringValues = array_map(function($value) {
                    if (is_array($value)) {
                        return implode('|', array_map('strval', $value));
                    }
                    return strval($value);
                }, $values);
                return '[' . implode('|', $stringValues) . ']';
            }
            return $values !== null ? strval($values) : $matches[0];
        }, $str);
    }
} 