<?php

declare(strict_types=1);

namespace Analyzer\Util;

class LogBuffer
{
    private static array $logs = [];

    public static function add(string $file, int $line, string $message): void
    {
        self::$logs[] = [
            'file' => $file,
            'line' => $line,
            'msg' => $message
        ];
    }

    public static function getLogs(): array
    {
        return self::$logs;
    }

    public static function clear(): void
    {
        self::$logs = [];
    }
} 