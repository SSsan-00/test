<?php

declare(strict_types=1);

namespace Analyzer;

use PhpParser\Node;
use PhpParser\Node\Expr;
use PhpParser\Node\Scalar;
use PhpParser\NodeVisitorAbstract;
use PhpParser\ParserFactory;
use PhpParser\Error as PhpParserError;

class VariableResolver extends NodeVisitorAbstract
{
    private array $variables = [];
    private array $conditionalVariables = [];
    private array $objectProperties = [];

    public function resolveVariables(Node $node): array
    {
        $this->variables = [];
        $this->conditionalVariables = [];
        $this->objectProperties = [];
        
        $this->traverseNode($node);
        
        return $this->variables;
    }

    private function traverseNode(Node $node): void
    {
        if ($node instanceof Node\Expr\Assign) {
            $this->handleAssignment($node);
        } elseif ($node instanceof Node\Stmt\If_) {
            $this->handleConditional($node);
        }

        foreach ($node->getSubNodeNames() as $name) {
            $subNode = $node->$name;
            if ($subNode instanceof Node) {
                $this->traverseNode($subNode);
            } elseif (is_array($subNode)) {
                foreach ($subNode as $item) {
                    if ($item instanceof Node) {
                        $this->traverseNode($item);
                    }
                }
            }
        }
    }

    private function handleAssignment(Node\Expr\Assign $node): void
    {
        $varName = $this->getVariableName($node->var);
        if ($varName !== null) {
            $this->variables[$varName] = $this->evaluateValue($node->expr);
        }
    }

    private function handleConditional(Node\Stmt\If_ $node): void
    {
        $condition = $this->evaluateValue($node->cond);
        foreach ($node->stmts as $stmt) {
            if ($stmt instanceof Node\Expr\Assign) {
                $varName = $this->getVariableName($stmt->var);
                if ($varName !== null) {
                    $this->conditionalVariables[$varName] = [
                        'condition' => $condition,
                        'value' => $this->evaluateValue($stmt->expr)
                    ];
                }
            }
        }
    }

    private function getVariableName(Node $node): ?string
    {
        if ($node instanceof Node\Expr\Variable) {
            return is_string($node->name) ? $node->name : null;
        } elseif ($node instanceof Node\Expr\PropertyFetch) {
            $objName = $this->getVariableName($node->var);
            $propName = $node->name instanceof Node\Identifier ? $node->name->toString() : null;
            return $objName && $propName ? "{$objName}->{$propName}" : null;
        }
        return null;
    }

    private function evaluateValue(Node $node): mixed
    {
        if ($node instanceof Scalar\String_) {
            return $this->resolveString($node->value);
        } elseif ($node instanceof Scalar\LNumber) {
            return $node->value;
        } elseif ($node instanceof Expr\Array_) {
            return $this->evaluateArray($node);
        } elseif ($node instanceof Expr\BinaryOp\Concat) {
            return $this->evaluateValue($node->left) . $this->evaluateValue($node->right);
        } elseif ($node instanceof Expr\Variable) {
            $varName = is_string($node->name) ? $node->name : null;
            return $varName ? ($this->variables[$varName] ?? null) : null;
        }
        return null;
    }

    private function evaluateArray(Expr\Array_ $node): array
    {
        $result = [];
        foreach ($node->items as $item) {
            if ($item === null) continue;
            
            $key = $item->key ? $this->evaluateValue($item->key) : null;
            $value = $this->evaluateValue($item->value);
            
            if ($key !== null) {
                $result[$key] = $value;
            } else {
                $result[] = $value;
            }
        }
        return $result;
    }

    public function resolveString(string $value): string
    {
        // 変数展開を処理
        return preg_replace_callback('/\$\{([^}]+)\}|\$([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)/', function($matches) {
            $varName = $matches[1] ?? $matches[2];
            return (string)($this->variables[$varName] ?? $matches[0]);
        }, $value);
    }

    public function getFallbackValue(string $code): mixed
    {
        try {
            $parser = (new ParserFactory())->createForNewestSupportedVersion();
            $ast = $parser->parse('<?php ' . $code . ';');
            if ($ast === null || empty($ast)) {
                return $this->fallbackRegexParse($code);
            }
            return $this->evaluateValue($ast[0]);
        } catch (PhpParserError $e) {
            return $this->fallbackRegexParse($code);
        }
    }

    private function fallbackRegexParse(string $code): mixed
    {
        // 文字列リテラルを抽出
        if (preg_match('/^["\'](.*)["\']\s*$/', $code, $matches)) {
            return $matches[1];
        }
        
        // 配列リテラルを抽出
        if (preg_match('/^\[(.*)\]$/', $code, $matches)) {
            $items = explode(',', $matches[1]);
            return array_map('trim', $items);
        }
        
        // 数値を抽出
        if (is_numeric($code)) {
            return $code * 1;
        }
        
        return $code;
    }
} 