#!/usr/bin/env php
<?php
/**
 * analyzer.php — PHP/JS/HTML 静的解析ツール
 *
 *  ├─ A1  メタデータ読み込み（ビュー・PROC・Excel）
 *  ├─ A2  引数チェック
 *  ├─ A3  対象ファイル走査
 *  ├─ B*  ファイル処理ループ（AST or fallback → SQL 復元 → CRUD 判定）
 *  └─ E1  Excel 出力（File-CRUD / LOG）
 *
 * 依存:
 *   composer require \
 *     nikic/php-parser:^5.4 \
 *     greenlion/php-sql-parser:^4.7 \
 *     phpoffice/phpspreadsheet:^4.2
 *
 * 開発用:
 *   composer require --dev phpunit/phpunit:^12.1
 *
 * 実行:
 *   php analyzer.php <target_dir>
 */

declare(strict_types=1);

namespace Analyzer;

use PhpParser\{ParserFactory, NodeTraverser, NodeVisitorAbstract, Error as PhpParserError, Node};
use PhpParser\Node\Expr\BinaryOp\Concat;
use PhpParser\Node\Scalar\String_;
use PhpParser\Node\Expr\Variable;
use PhpParser\Node\Expr\FuncCall;
use PhpParser\Node\Expr\MethodCall;
use PhpParser\Node\Expr\New_;
use PhpParser\Node\Name;
use PhpParser\Node\Identifier;
use PHPSQLParser\PHPSQLParser;
use PhpOffice\PhpSpreadsheet\{Spreadsheet, Writer\Xlsx, IOFactory};
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use RecursiveIteratorIterator;
use RecursiveDirectoryIterator;

require_once __DIR__ . '/vendor/autoload.php';

date_default_timezone_set('Asia/Tokyo');
error_reporting(E_ALL);

/*========================================================
  グローバル保持領域
========================================================*/
$views = [];   // view 一覧
$procedures = [];   // procedure 一覧
$crudData = [];   // ['file']['table@flag'] = ['C'=>0,'R'=>0,'U'=>0,'D'=>0]
$logData = [];   // [['file'=>, 'line'=>, 'msg'=>], …]

/*========================================================
  クラス定義
========================================================*/

final class IncludeResolver {
    private array $includePaths = [];
    private array $resolvedIncludes = [];

    public function __construct() {
        $this->includePaths = explode(PATH_SEPARATOR, get_include_path());
    }

    private function getLineNumber(string $code, string $search): int {
        $lines = explode("\n", $code);
        foreach ($lines as $lineNumber => $line) {
            if (strpos($line, $search) !== false) {
                return $lineNumber + 1;
            }
        }
        return 0;
    }

    public function resolveIncludes(string $file, string $code, array $stack, array &$log): string {
        // 循環参照チェック
        if (in_array($file, $stack)) {
            $log[] = [
                'file' => $file,
                'line' => 0,
                'msg' => "循環参照を検出: " . implode(' -> ', $stack) . " -> {$file}"
            ];
            return $code;
        }

        // スタックに現在のファイルを追加
        $stack[] = $file;
        
        // インクルードパターン
        $patterns = [
            'include' => '/include\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?/',
            'include_once' => '/include_once\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?/',
            'require' => '/require\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?/',
            'require_once' => '/require_once\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?/'
        ];

        $resolvedCode = $code;
        
        foreach ($patterns as $type => $pattern) {
            if (preg_match_all($pattern, $code, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $match) {
                    $includePath = trim($match[1]);
                    $resolvedPath = $this->resolveIncludePath($includePath, $file);
                    
                    if ($resolvedPath === null) {
                        $log[] = [
                            'file' => $file,
                            'line' => 0,
                            'msg' => "インクルードファイルが見つかりません: {$includePath}"
                        ];
                        continue;
                    }

                    // インクルードファイルの内容を読み込む
                    $includedCode = file_get_contents($resolvedPath);
                    if ($includedCode === false) {
                        $log[] = [
                            'file' => $file,
                            'line' => 0,
                            'msg' => "インクルードファイルの読み込みに失敗: {$resolvedPath}"
                        ];
                        continue;
                    }

                    // インクルード情報を記録
                    $this->resolvedIncludes[$file][] = [
                        'path' => $resolvedPath,
                        'type' => $type,
                        'line' => $this->getLineNumber($code, $match[0])
                    ];

                    // 再帰的にインクルードを解決
                    $resolvedIncludedCode = $this->resolveIncludes($resolvedPath, $includedCode, $stack, $log);
                    
                    // インクルード文を解決済みコードで置換
                    $resolvedCode = str_replace($match[0], $resolvedIncludedCode, $resolvedCode);
                }
            }
        }

        return $resolvedCode;
    }

    private function resolveIncludePath(string $path, string $currentFile): ?string {
        // __DIR__を現在のファイルのディレクトリパスに置換
        if (strpos($path, '__DIR__') !== false) {
            $dirPath = dirname($currentFile);
            $path = str_replace('__DIR__', "'{$dirPath}'", $path);
        }

        // パスの連結を評価
        if (strpos($path, '.') !== false) {
            $parts = array_map('trim', explode('.', $path));
            $parts = array_map(function($part) {
                return trim($part, "'\"");
            }, $parts);
            $path = implode('', $parts);
        }

        // 絶対パスの場合
        if (strpos($path, '/') === 0) {
            return file_exists($path) ? $path : null;
        }

        // 相対パスの場合
        $currentDir = dirname($currentFile);
        $absPath = realpath($currentDir . '/' . $path);
        
        if ($absPath !== false) {
            return $absPath;
        }

        // PHPのインクルードパスをチェック
        foreach ($this->includePaths as $includePath) {
            $absPath = realpath($includePath . '/' . $path);
            if ($absPath !== false) {
                return $absPath;
            }
        }

        return null;
    }

    public function getResolvedIncludes(): array {
        return $this->resolvedIncludes;
    }
}

/*========================================================
  エントリポイント
========================================================*/

if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    if (count($argv) < 2) {
        echo "使用方法: php analyzer.php <入力ディレクトリ> [出力ディレクトリ]\n";
        exit(0);
    }
    // メイン処理
    $inputDir = $argv[1];
    $outputDir = $argv[2] ?? 'output';

    if (!is_dir($inputDir)) {
        die("入力ディレクトリが見つかりません: {$inputDir}\n");
    }

    // 出力ディレクトリが存在しない場合は作成
    if (!is_dir($outputDir)) {
        if (!mkdir($outputDir, 0755, true)) {
            die("出力ディレクトリの作成に失敗しました: {$outputDir}\n");
        }
        echo "出力ディレクトリを作成しました: {$outputDir}\n";
    }

    /*―――  A1 : メタデータ読み込み  ―――*/
    loadMetaData(__DIR__, $views, $procedures, $crudData, $logData);

    /*―――  A3 : 対象ファイル走査 & 本解析  ―――*/
    foreach (fileGenerator($inputDir) as $absPath) {
        $relPath = substr($absPath, strlen($inputDir) + 1);
        $codeRaw = file_get_contents($absPath) ?: '';
        $codeClean = stripComments($codeRaw, $relPath, $logData);

        // include/require 展開（未実装: TODO）
        $codeMerged = resolveIncludes($absPath, $codeClean, [], $logData);

        // AST or fallback で SQL 断片抽出
        try {
            $sqlFragments = analyzeWithPhpParser($codeMerged, $relPath, $logData);
        } catch (PhpParserError $e) {
            $logData[] = [
                'file' => $relPath,
                'line' => $e->getStartLine(),
                'msg' => "PhpParserError: {$e->getMessage()} — fallback"
            ];
            $sqlFragments = fallbackParse($codeMerged);
        }

        // 外部リソースの解析
        $externalAnalyzer = new ExternalResourceAnalyzer();
        $externalResources = $externalAnalyzer->analyze($codeMerged);
        if (!empty($externalResources)) {
            $logData[] = [
                'file' => $relPath,
                'line' => 0,
                'msg' => "外部リソース検出: " . implode(', ', $externalResources)
            ];
        }

        // 断片 → 完全 SQL へ結合（未実装: TODO）
        $sqlList = assembleSQL($sqlFragments);

        // 各 SQL を CRUD 解析
        foreach ($sqlList as $sql) {
            try {
                $crudOps = analyzeSQL($sql, $views, $procedures);
                mergeCrud($crudData, $relPath, $crudOps);
            } catch (\Throwable $e) {
                $logData[] = [
                    'file' => $relPath,
                    'line' => 0,
                    'msg' => "SQL 解析失敗: {$e->getMessage()}"
                ];
            }
        }

        // メモリ開放
        gc_collect_cycles();
    }

    /*―――  E1 : Excel 出力  ―――*/
    exportExcel($crudData, $logData, $outputDir);
    exit(0);
}

/*========================================================
  A1 : メタデータ読み込み
========================================================*/
/**
 * view / procedure 一覧 & 既存 Excel CRUD をロードし
 *   $views, $procedures, $crudData に注入する
 */
function loadMetaData(
    string $baseDir,
    array &$views,
    array &$procedures,
    array &$crudData,
    array &$logData
): void {
    // ── txt リスト ──
    foreach (['view_list.txt' => &$views, 'procedure_list.txt' => &$procedures] as $f => &$dest) {
        $fp = "{$baseDir}/{$f}";
        if (is_file($fp)) {
            $dest = array_filter(array_map('trim', file($fp)));
        }
    }

    // ── Excel マトリクス (任意) ──
    $xlsx = glob("{$baseDir}/meta_matrix*.xlsx")[0] ?? null;
    if ($xlsx && is_file($xlsx)) {
        try {
            $ws = IOFactory::createReader('Xlsx')->load($xlsx)
                ->getSheetByName('Proc-TableMatrix');
            if ($ws instanceof Worksheet) {
                $crudData = preloadCrudFromMatrix($ws);
                $logData[] = [
                    'file' => '(meta)',
                    'line' => 0,
                    'msg' => "Excel プリロード: '" . basename($xlsx) . "' から CRUD 初期化"
                ];
            }
        } catch (\Throwable $e) {
            $logData[] = [
                'file' => '(meta)',
                'line' => 0,
                'msg' => "Excel 読込失敗: {$e->getMessage()}"
            ];
        }
    }
}

/**
 * Proc-TableMatrix シート → CRUD 配列へ変換
 */
function preloadCrudFromMatrix(Worksheet $ws): array
{
    $crud = [];
    $maxCol = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($ws->getHighestColumn());
    $maxRow = $ws->getHighestRow();

    // 1 行目 = プロシージャ名
    $proc = [];
    for ($c = 2; $c <= $maxCol; $c++) {
        $proc[$c] = trim((string) $ws->getCell([$c, 1])->getValue());
    }

    // 2 行目以降 = テーブル × CRUD
    for ($r = 2; $r <= $maxRow; $r++) {
        $table = trim((string) $ws->getCell([1, $r])->getValue());
        if ($table === '')
            continue;

        for ($c = 2; $c <= $maxCol; $c++) {
            $cell = strtoupper((string) $ws->getCell([$c, $r])->getValue());
            if ($cell === '')
                continue;
            $key = "{$proc[$c]}@proc";
            $crud[$key][$table] ??= ['C' => 0, 'R' => 0, 'U' => 0, 'D' => 0];
            foreach (str_split($cell) as $flag) {
                if (isset($crud[$key][$table][$flag]))
                    $crud[$key][$table][$flag] = 1;
            }
        }
    }
    return $crud;
}

/*========================================================
  A3 : ファイル走査 (Generator)
========================================================*/
function fileGenerator(string $dir): \Generator
{
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
    foreach ($it as $f) {
        if ($f->isDir())
            continue;
        if (!preg_match('/\.(php|inc|js|html)$/i', $f->getFilename()))
            continue;
        yield $f->getPathname();
    }
}

/*========================================================
  B0 : 共通ユーティリティ
========================================================*/
/** コメント除去（HTML・C/PHP ブロック・行コメント） */
function stripComments(string $code, string $file, array &$logData): string
{
    $patterns = [
        '/<!--.*?-->/s',            // HTML
        '/\/\*.*?\*\//s',           // C/PHP ブロック
        '/\/\/[^\n]*/',             // //
        '/#(?!\{).*?$/m'            // # （bash 風）※#{…} テンプレート除外
    ];
    $clean = @preg_replace($patterns, '', $code);
    if ($clean === null) {
        $logData[] = ['file' => $file, 'line' => 0, 'msg' => 'preg_replace 失敗 — コメント除去スキップ'];
        return $code;
    }
    return $clean;
}

/*―――  include/require 解決 ―――*/
function resolveIncludes(string $file, string $code, array $stack, array &$log): string
{
    // 循環参照チェック
    if (in_array($file, $stack)) {
        $log[] = [
            'file' => $file,
            'line' => 0,
            'msg' => "循環参照を検出: " . implode(' -> ', $stack) . " -> {$file}"
        ];
        return $code;
    }

    // スタックに現在のファイルを追加
    $stack[] = $file;
    
    // インクルードパターン
    $patterns = [
        'include' => '/include\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?/',
        'include_once' => '/include_once\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?/',
        'require' => '/require\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?/',
        'require_once' => '/require_once\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?/'
    ];

    $resolvedCode = $code;
    
    foreach ($patterns as $type => $pattern) {
        if (preg_match_all($pattern, $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $includePath = trim($match[1]);
                $resolvedPath = resolveIncludePath($includePath, $file);
                
                if ($resolvedPath === null) {
                    $log[] = [
                        'file' => $file,
                        'line' => 0,
                        'msg' => "インクルードファイルが見つかりません: {$includePath}"
                    ];
                    continue;
                }

                // インクルードファイルの内容を読み込む
                $includedCode = file_get_contents($resolvedPath);
                if ($includedCode === false) {
                    $log[] = [
                        'file' => $file,
                        'line' => 0,
                        'msg' => "インクルードファイルの読み込みに失敗: {$resolvedPath}"
                    ];
                    continue;
                }

                // インクルード情報を記録
                $log[] = [
                    'file' => $file,
                    'line' => 0,  // 行番号は0に設定
                    'msg' => "インクルード: {$includePath}"
                ];

                // 再帰的にインクルードを解決
                $resolvedIncludedCode = resolveIncludes($resolvedPath, $includedCode, $stack, $log);
                
                // インクルード文を解決済みコードで置換
                $resolvedCode = str_replace($match[0], $resolvedIncludedCode, $resolvedCode);
            }
        }
    }

    return $resolvedCode;
}

/**
 * インクルードパスを解決
 */
function resolveIncludePath(string $path, string $currentFile): ?string
{
    // __DIR__を現在のファイルのディレクトリパスに置換
    if (strpos($path, '__DIR__') !== false) {
        $dirPath = dirname($currentFile);
        $path = str_replace('__DIR__', "'{$dirPath}'", $path);
    }

    // パスの連結を評価
    if (strpos($path, '.') !== false) {
        $parts = array_map('trim', explode('.', $path));
        $parts = array_map(function($part) {
            return trim($part, "'\"");
        }, $parts);
        $path = implode('', $parts);
    }

    // 絶対パスの場合
    if (strpos($path, '/') === 0) {
        return file_exists($path) ? $path : null;
    }

    // 相対パスの場合
    $currentDir = dirname($currentFile);
    $absPath = realpath($currentDir . '/' . $path);
    
    if ($absPath !== false) {
        return $absPath;
    }

    // PHPのインクルードパスをチェック
    $includePaths = explode(PATH_SEPARATOR, get_include_path());
    foreach ($includePaths as $includePath) {
        $absPath = realpath($includePath . '/' . $path);
        if ($absPath !== false) {
            return $absPath;
        }
    }

    return null;
}

/*========================================================
  クラス定義
========================================================*/

class ConstantResolver
{
    private array $constants = [];
    private array $conditionalConstants = [];

    public function __construct()
    {
        $this->constants = get_defined_constants(true)['user'] ?? [];
    }

    public function collectConstants(array $ast): void
    {
        $visitor = new class($this->constants, $this->conditionalConstants) extends NodeVisitorAbstract {
            private array $constants;
            private array $conditionalConstants;
            private array $currentCondition = [];

            public function __construct(array &$constants, array &$conditionalConstants)
            {
                $this->constants = &$constants;
                $this->conditionalConstants = &$conditionalConstants;
            }

            public function enterNode(Node $node)
            {
                if ($node instanceof Node\Stmt\If_) {
                    $this->enterCondition($node->cond);
                    return null;
                }

                if ($node instanceof Node\Expr\FuncCall && $node->name instanceof Node\Name) {
                    if ($node->name->toString() === 'define') {
                        if (isset($node->args[0], $node->args[1])) {
                            $name = $this->evaluateValue($node->args[0]->value);
                            $value = $this->evaluateValue($node->args[1]->value);
                            if (is_string($name)) {
                                if (!empty($this->currentCondition)) {
                                    $this->conditionalConstants[$name][] = [
                                        'value' => $value,
                                        'condition' => $this->currentCondition
                                    ];
                                } else {
                                    $this->constants[$name] = $value;
                                }
                            }
                        }
                    }
                }
            }

            public function leaveNode(Node $node)
            {
                if ($node instanceof Node\Stmt\If_) {
                    array_pop($this->currentCondition);
                }
            }

            private function enterCondition(Node $condition)
            {
                $condStr = $this->getConditionString($condition);
                if ($condStr) {
                    $this->currentCondition[] = $condStr;
                }
            }

            private function getConditionString(Node $node): string
            {
                if ($node instanceof Node\Expr\BinaryOp\Equal) {
                    $left = $this->evaluateValue($node->left);
                    $right = $this->evaluateValue($node->right);
                    return "{$left} === {$right}";
                }
                if ($node instanceof Node\Expr\BinaryOp\BooleanAnd) {
                    $left = $this->getConditionString($node->left);
                    $right = $this->getConditionString($node->right);
                    return "({$left} && {$right})";
                }
                return '';
            }

            private function evaluateValue(Node $node)
            {
                if ($node instanceof Node\Scalar\String_) {
                    return $node->value;
                } elseif ($node instanceof Node\Scalar\LNumber) {
                    return $node->value;
                } elseif ($node instanceof Node\Scalar\DNumber) {
                    return $node->value;
                } elseif ($node instanceof Node\Expr\ConstFetch) {
                    $constName = $node->name->toString();
                    if (defined($constName)) {
                        return constant($constName);
                    }
                    return null;
                }
                return null;
            }
        };

        $traverser = new NodeTraverser();
        $traverser->addVisitor($visitor);
        $traverser->traverse($ast);
    }

    public function resolveConstant(string $name)
    {
        // 通常の定数値を確認
        if (isset($this->constants[$name])) {
            return $this->constants[$name];
        }

        // 条件付き定数値を確認
        if (isset($this->conditionalConstants[$name])) {
            $values = array_map(function($item) {
                return $item['value'];
            }, $this->conditionalConstants[$name]);
            return $values;
        }

        return null;
    }

    public function resolveString(string $str): string
    {
        return preg_replace_callback('/\b([A-Z][A-Z0-9_]*)\b/', function($matches) {
            $values = $this->resolveConstant($matches[1]);
            if (is_array($values)) {
                // 配列の各要素を文字列に変換
                $stringValues = array_map(function($value) {
                    if (is_array($value)) {
                        return implode('|', array_map('strval', $value));
                    }
                    return strval($value);
                }, $values);
                return '[' . implode('|', $stringValues) . ']';
            }
            return $values !== null ? strval($values) : $matches[0];
        }, $str);
    }
}

class VariableResolver
{
    private array $variables = [];
    private array $assignments = [];
    private array $conditionalValues = [];
    private array $objects = [];
    private array $arrays = [];

    public function __construct()
    {
        $this->variables = [];
    }

    public function collectVariables(array $ast): void
    {
        try {
            $visitor = new class($this->variables, $this->assignments, $this->conditionalValues, $this->objects, $this->arrays) extends NodeVisitorAbstract {
                private array $variables;
                private array $assignments;
                private array $conditionalValues;
                private array $objects;
                private array $arrays;
                private array $currentCondition = [];

                public function __construct(
                    array &$variables,
                    array &$assignments,
                    array &$conditionalValues,
                    array &$objects,
                    array &$arrays
                ) {
                    $this->variables = &$variables;
                    $this->assignments = &$assignments;
                    $this->conditionalValues = &$conditionalValues;
                    $this->objects = &$objects;
                    $this->arrays = &$arrays;
                }

                public function enterNode(Node $node)
                {
                    if ($node instanceof Node\Stmt\If_) {
                        $this->enterCondition($node->cond);
                        return null;
                    }

                    if ($node instanceof Node\Expr\Assign) {
                        if ($node->var instanceof Node\Expr\Variable) {
                            $this->handleVariableAssignment($node);
                        } elseif ($node->var instanceof Node\Expr\ArrayDimFetch) {
                            $this->handleArrayAssignment($node);
                        } elseif ($node->var instanceof Node\Expr\PropertyFetch) {
                            $this->handlePropertyAssignment($node);
                        }
                    } elseif ($node instanceof Node\Expr\New_) {
                        $this->handleNewObject($node);
                    }
                }

                private function handleVariableAssignment(Node\Expr\Assign $node): void
                {
                    if ($node->var instanceof Node\Expr\Variable) {
                        $varName = $node->var->name;
                        $value = $this->evaluateValue($node->expr);
                        
                        if (!empty($this->currentCondition)) {
                            $this->conditionalValues[$varName][] = [
                                'value' => $value,
                                'condition' => $this->currentCondition
                            ];
                        } else {
                            $this->variables[$varName] = $value;
                            $this->assignments[$varName][] = [
                                'value' => $value,
                                'line' => $node->getLine()
                            ];
                        }
                    }
                }

                private function handleArrayAssignment(Node\Expr\Assign $node): void
                {
                    if ($node->var instanceof Node\Expr\ArrayDimFetch && $node->var->var !== null && $node->var->dim !== null) {
                        $array = $this->evaluateArray($node->var->var);
                        $dim = $this->evaluateValue($node->var->dim);
                        $value = $this->evaluateValue($node->expr);

                        if (is_array($array) && $dim !== null) {
                            $array[$dim] = $value;
                            $this->arrays[spl_object_hash($node->var->var)] = $array;
                        }
                    }
                }

                private function handlePropertyAssignment(Node\Expr\Assign $node): void
                {
                    if ($node->var instanceof Node\Expr\PropertyFetch) {
                        $object = $this->evaluateValue($node->var->var);
                        $property = $node->var->name instanceof Node\Identifier ? $node->var->name->name : null;
                        $value = $this->evaluateValue($node->expr);

                        if (is_object($object) && $property !== null) {
                            $object->$property = $value;
                            $this->objects[spl_object_hash($node->var)] = $object;
                        }
                    }
                }

                private function handleNewObject(Node\Expr\New_ $node): void
                {
                    // オブジェクトの生成はスキップし、クラス名のみを記録
                    if ($node->class instanceof Node\Name) {
                        $className = $node->class->toString();
                        $this->objects[spl_object_hash($node)] = $className;
                    }
                }

                private function evaluateArray($node): ?array
                {
                    if ($node instanceof Node\Expr\Variable) {
                        return $this->arrays[spl_object_hash($node)] ?? null;
                    }
                    return null;
                }

                private function evaluateValue(?Node $node)
                {
                    if ($node === null) {
                        return null;
                    }

                    if ($node instanceof Node\Scalar\String_) {
                        return $node->value;
                    } elseif ($node instanceof Node\Scalar\LNumber) {
                        return $node->value;
                    } elseif ($node instanceof Node\Scalar\DNumber) {
                        return $node->value;
                    } elseif ($node instanceof Node\Expr\ConstFetch) {
                        $constName = $node->name->toString();
                        if (defined($constName)) {
                            return constant($constName);
                        }
                        return null;
                    } elseif ($node instanceof Node\Expr\Variable) {
                        $value = $this->variables[$node->name] ?? null;
                        if (is_array($value)) {
                            return '[' . implode(', ', array_map('strval', $value)) . ']';
                        }
                        return $value;
                    } elseif ($node instanceof Node\Expr\ArrayDimFetch) {
                        $value = $this->evaluateArrayAccess($node);
                        if (is_array($value)) {
                            return '[' . implode(', ', array_map('strval', $value)) . ']';
                        }
                        return $value;
                    } elseif ($node instanceof Node\Expr\PropertyFetch) {
                        $value = $this->evaluatePropertyAccess($node);
                        if (is_array($value)) {
                            return '[' . implode(', ', array_map('strval', $value)) . ']';
                        }
                        return $value;
                    } elseif ($node instanceof Node\Expr\MethodCall) {
                        $value = $this->evaluateMethodCall($node);
                        if (is_array($value)) {
                            return '[' . implode(', ', array_map('strval', $value)) . ']';
                        }
                        return $value;
                    } elseif ($node instanceof Node\Expr\BinaryOp\Concat) {
                        $left = $this->evaluateValue($node->left);
                        $right = $this->evaluateValue($node->right);
                        return strval($left) . strval($right);
                    }
                    return null;
                }

                private function evaluateArrayAccess(Node\Expr\ArrayDimFetch $node)
                {
                    $array = $this->evaluateValue($node->var);
                    $dim = $this->evaluateValue($node->dim);
                    
                    if (is_array($array) && $dim !== null) {
                        return $array[$dim] ?? null;
                    }
                    return null;
                }

                private function evaluatePropertyAccess(Node\Expr\PropertyFetch $node)
                {
                    $object = $this->evaluateValue($node->var);
                    $property = $node->name->name;
                    
                    if (is_object($object)) {
                        return $object->$property ?? null;
                    }
                    return null;
                }

                private function evaluateMethodCall(Node\Expr\MethodCall $node)
                {
                    $object = $this->evaluateValue($node->var);
                    $method = $node->name->name;
                    
                    if (is_object($object) && method_exists($object, $method)) {
                        $args = array_map([$this, 'evaluateValue'], $node->args);
                        return $object->$method(...$args);
                    }
                    return null;
                }

                private function enterCondition(Node $condition)
                {
                    $condStr = $this->getConditionString($condition);
                    if ($condStr) {
                        $this->currentCondition[] = $condStr;
                    }
                }

                private function getConditionString(Node $node): string
                {
                    if ($node instanceof Node\Expr\BinaryOp\Equal) {
                        $left = $this->evaluateValue($node->left);
                        $right = $this->evaluateValue($node->right);
                        return "{$left} === {$right}";
                    }
                    if ($node instanceof Node\Expr\BinaryOp\BooleanAnd) {
                        $left = $this->getConditionString($node->left);
                        $right = $this->getConditionString($node->right);
                        return "({$left} && {$right})";
                    }
                    return '';
                }
            };

            $traverser = new NodeTraverser();
            $traverser->addVisitor($visitor);
            $traverser->traverse($ast);
        } catch (\Throwable $e) {
            // パース失敗時のフォールバック
            $code = $this->getAstCode($ast);
            $this->fallbackParseVariables($code);
            LogBuffer::add("変数解析でフォールバック処理を実行: {$e->getMessage()}", 'WARN', __FILE__);
        }
    }

    private function fallbackParseVariables(string $code): void
    {
        // 変数代入のパターン
        $patterns = [
            // 通常の変数代入
            '/\$([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\s*=\s*([\'"].*?[\'"]|\d+(?:\.\d+)?)/m',
            // 配列代入
            '/\$([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\s*=\s*\[(.*?)\]/s',
            // オブジェクト代入
            '/\$([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\s*=\s*new\s+([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)/m'
        ];

        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $code, $matches)) {
                foreach ($matches[1] as $i => $varName) {
                    $value = $matches[2][$i];
                    // クォートを除去
                    $value = trim($value, "'\"");
                    $this->variables[$varName] = $value;
                }
            }
        }
    }

    private function getAstCode(array $ast): string
    {
        $code = '';
        foreach ($ast as $node) {
            if ($node instanceof Node) {
                $startLine = $node->getStartLine();
                $endLine = $node->getEndLine();
                $lines = file($node->getAttribute('filePath', ''));
                $code .= implode('', array_slice($lines, $startLine - 1, $endLine - $startLine + 1));
            }
        }
        return $code;
    }

    public function resolveVariable(string $name)
    {
        // 通常の変数値を確認
        if (isset($this->variables[$name])) {
            return $this->variables[$name];
        }

        // 条件付き変数値を確認
        if (isset($this->conditionalValues[$name])) {
            $values = array_map(function($item) {
                return $item['value'];
            }, $this->conditionalValues[$name]);
            return $values;
        }

        return null;
    }

    public function resolveString(string $str): string
    {
        return preg_replace_callback('/\$\{?([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)(?:->([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*))?(?:\[([^\]]+)\])?\}?/', 
            function($matches) {
                $varName = $matches[1];
                $property = $matches[2] ?? null;
                $arrayKey = $matches[3] ?? null;

                $value = $this->resolveVariable($varName);
                
                if ($property !== null && is_object($value)) {
                    $value = $value->$property ?? null;
                }
                
                if ($arrayKey !== null && is_array($value)) {
                    $key = trim($arrayKey, "'\"");
                    $value = $value[$key] ?? null;
                }

                if (is_array($value)) {
                    $stringValues = array_map(function($v) {
                        if (is_array($v)) {
                            return '[' . implode(', ', array_map('strval', $v)) . ']';
                        }
                        return strval($v);
                    }, $value);
                    return '[' . implode(', ', $stringValues) . ']';
                }
                return $value !== null ? strval($value) : $matches[0];
            }, 
            $str
        );
    }
}

class FunctionResolver
{
    private array $functions = [];
    private array $methods = [];
    private array $tablePatterns = [
        'SELECT' => '/\bFROM\s+([a-zA-Z0-9_]+)/i',
        'INSERT' => '/\bINTO\s+([a-zA-Z0-9_]+)/i',
        'UPDATE' => '/\bUPDATE\s+([a-zA-Z0-9_]+)/i',
        'DELETE' => '/\bFROM\s+([a-zA-Z0-9_]+)/i'
    ];
    private array $callStack = [];
    private array $functionDependencies = [];
    private int $maxRecursionDepth = 10;

    public function collectFunctions(array $ast): void
    {
        $visitor = new class($this->functions, $this->methods) extends NodeVisitorAbstract {
            private array $functions;
            private array $methods;

            public function __construct(array &$functions, array &$methods)
            {
                $this->functions = &$functions;
                $this->methods = &$methods;
            }

            public function enterNode(Node $node)
            {
                if ($node instanceof Node\Stmt\Function_) {
                    $this->functions[$node->name->toString()] = [
                        'node' => $node,
                        'params' => $node->params,
                        'stmts' => $node->stmts
                    ];
                } elseif ($node instanceof Node\Stmt\ClassMethod) {
                    $class = $this->findParentClass($node);
                    if ($class) {
                        $this->methods[$class->name->toString()][$node->name->toString()] = [
                            'node' => $node,
                            'params' => $node->params,
                            'stmts' => $node->stmts
                        ];
                    }
                }
            }

            private function findParentClass(Node $node): ?Node\Stmt\Class_
            {
                do {
                    $node = $node->getAttribute('parent');
                    if ($node instanceof Node\Stmt\Class_) {
                        return $node;
                    }
                } while ($node !== null);
                return null;
            }
        };

        $traverser = new NodeTraverser();
        $traverser->addVisitor($visitor);
        $traverser->traverse($ast);
    }

    public function resolveFunctionCall(Node\Expr\FuncCall $node): ?array
    {
        try {
            if (!$node->name instanceof Node\Name) {
                return null;
            }

            $name = $node->name->getLast();
            
            // 循環参照チェック
            if (in_array($name, $this->callStack)) {
                return ['tables' => [], 'crud' => [], 'warning' => "循環参照を検出: " . implode(' -> ', $this->callStack) . " -> {$name}"];
            }

            // 再帰深度チェック
            if (count($this->callStack) >= $this->maxRecursionDepth) {
                return ['tables' => [], 'crud' => [], 'warning' => "最大再帰深度({$this->maxRecursionDepth})に到達"];
            }

            if (!isset($this->functions[$name])) {
                return null;
            }

            // コールスタックに追加
            $this->callStack[] = $name;

            $function = $this->functions[$name];
            $args = $this->resolveArguments($node->args, $function['params']);
            
            // 関数本体の解析
            $result = $this->analyzeFunctionBody($function['stmts'], $args);
            
            // 依存関係の記録
            $this->functionDependencies[$name] = array_merge(
                $this->functionDependencies[$name] ?? [],
                $result['tables'] ?? []
            );

            // コールスタックから削除
            array_pop($this->callStack);

            return $result;
        } catch (\Throwable $e) {
            // パース失敗時のフォールバック
            $functionCode = $this->getFunctionCode($function['node']);
            $result = $this->fallbackParseFunctionBody($functionCode);
            if ($result) {
                $result['warning'] = "パース失敗によるフォールバック処理: {$e->getMessage()}";
            }
            return $result;
        }
    }

    public function resolveMethodCall(Node\Expr\MethodCall $node): ?array
    {
        try {
            if (!$node->var instanceof Node\Expr\Variable) {
                return null;
            }

            $varName = $node->var->name instanceof Node\Identifier 
                ? $node->var->name->name 
                : ($node->var->name instanceof Node\Expr\Variable 
                    ? $node->var->name->name 
                    : (string)$node->var->name);
            $methodName = $node->name instanceof Node\Identifier ? $node->name->name : (string)$node->name;
            
            // メソッド呼び出しの完全な識別子を生成
            $fullMethodName = "{$varName}::{$methodName}";
            
            // 循環参照チェック
            if (in_array($fullMethodName, $this->callStack)) {
                return ['tables' => [], 'crud' => [], 'warning' => "循環参照を検出: " . implode(' -> ', $this->callStack) . " -> {$fullMethodName}"];
            }

            // 再帰深度チェック
            if (count($this->callStack) >= $this->maxRecursionDepth) {
                return ['tables' => [], 'crud' => [], 'warning' => "最大再帰深度({$this->maxRecursionDepth})に到達"];
            }

            // クラスインスタンスの特定（簡易実装）
            foreach ($this->methods as $className => $classMethods) {
                if (isset($classMethods[$methodName])) {
                    // コールスタックに追加
                    $this->callStack[] = $fullMethodName;

                    $method = $classMethods[$methodName];
                    $args = $this->resolveArguments($node->args, $method['params']);
                    
                    // メソッド本体の解析
                    $result = $this->analyzeFunctionBody($method['stmts'], $args);
                    
                    // 依存関係の記録
                    $this->functionDependencies[$fullMethodName] = array_merge(
                        $this->functionDependencies[$fullMethodName] ?? [],
                        $result['tables'] ?? []
                    );

                    // コールスタックから削除
                    array_pop($this->callStack);

                    return $result;
                }
            }

            return null;
        } catch (\Throwable $e) {
            // パース失敗時のフォールバック
            $methodCode = $this->getMethodCode($method['node']);
            $result = $this->fallbackParseFunctionBody($methodCode);
            if ($result) {
                $result['warning'] = "パース失敗によるフォールバック処理: {$e->getMessage()}";
            }
            return $result;
        }
    }

    private function resolveArguments(array $args, array $params): array
    {
        $resolved = [];
        foreach ($args as $i => $arg) {
            if (isset($params[$i])) {
                $paramName = $params[$i]->var->name;
                $resolved[$paramName] = $this->evaluateValue($arg->value);
            }
        }
        return $resolved;
    }

    private function evaluateValue(Node $node)
    {
        if ($node instanceof Node\Scalar\String_) {
            return $node->value;
        } elseif ($node instanceof Node\Scalar\LNumber) {
            return $node->value;
        } elseif ($node instanceof Node\Scalar\DNumber) {
            return $node->value;
        } elseif ($node instanceof Node\Expr\Array_) {
            $array = [];
            foreach ($node->items as $item) {
                $key = $item->key ? $this->evaluateValue($item->key) : null;
                $value = $this->evaluateValue($item->value);
                if ($key !== null) {
                    $array[$key] = $value;
                } else {
                    $array[] = $value;
                }
            }
            return $array;
        }
        return null;
    }

    private function analyzeFunctionBody(array $stmts, array $args): ?array
    {
        $result = ['tables' => [], 'crud' => []];
        
        foreach ($stmts as $stmt) {
            if ($stmt instanceof Node\Stmt\Return_) {
                $returnValue = $this->evaluateReturnValue($stmt->expr, $args);
                if (is_string($returnValue)) {
                    $this->extractTableAndCrud($returnValue, $result);
                }
            } elseif ($stmt instanceof Node\Expr\FuncCall) {
                // 関数呼び出しの解析
                $nestedResult = $this->resolveFunctionCall($stmt);
                if ($nestedResult) {
                    $result['tables'] = array_merge($result['tables'], $nestedResult['tables']);
                    foreach ($nestedResult['crud'] as $table => $ops) {
                        if (!isset($result['crud'][$table])) {
                            $result['crud'][$table] = $ops;
                        } else {
                            foreach ($ops as $op => $val) {
                                $result['crud'][$table][$op] |= $val;
                            }
                        }
                    }
                    if (isset($nestedResult['warning'])) {
                        $result['warning'] = $nestedResult['warning'];
                    }
                }
            } elseif ($stmt instanceof Node\Expr\MethodCall) {
                // メソッド呼び出しの解析
                $nestedResult = $this->resolveMethodCall($stmt);
                if ($nestedResult) {
                    $result['tables'] = array_merge($result['tables'], $nestedResult['tables']);
                    foreach ($nestedResult['crud'] as $table => $ops) {
                        if (!isset($result['crud'][$table])) {
                            $result['crud'][$table] = $ops;
                        } else {
                            foreach ($ops as $op => $val) {
                                $result['crud'][$table][$op] |= $val;
                            }
                        }
                    }
                    if (isset($nestedResult['warning'])) {
                        $result['warning'] = $nestedResult['warning'];
                    }
                }
            }
        }
        
        return $result;
    }

    private function evaluateReturnValue(Node $node, array $args): ?string
    {
        if ($node instanceof Node\Scalar\String_) {
            return $this->replaceArgs($node->value, $args);
        } elseif ($node instanceof Node\Expr\BinaryOp\Concat) {
            $left = $this->evaluateReturnValue($node->left, $args);
            $right = $this->evaluateReturnValue($node->right, $args);
            return $left . $right;
        }
        return null;
    }

    private function replaceArgs(string $sql, array $args): string
    {
        return preg_replace_callback('/\{(\$[a-zA-Z0-9_]+)\}/', function($matches) use ($args) {
            $varName = substr($matches[1], 1); // Remove $
            return $args[$varName] ?? $matches[0];
        }, $sql);
    }

    private function extractTableAndCrud(string $sql, array &$result): void
    {
        $sql = trim($sql);
        
        // クエリタイプの判定
        $type = '';
        foreach (['SELECT', 'INSERT', 'UPDATE', 'DELETE'] as $queryType) {
            if (preg_match("/^\s*{$queryType}\b/i", $sql)) {
                $type = $queryType;
                break;
            }
        }
        
        if ($type && isset($this->tablePatterns[$type])) {
            if (preg_match($this->tablePatterns[$type], $sql, $matches)) {
                $table = $matches[1];
                $result['tables'][] = $table;
                $result['crud'][$table] = [
                    'C' => ($type === 'INSERT') ? 1 : 0,
                    'R' => ($type === 'SELECT') ? 1 : 0,
                    'U' => ($type === 'UPDATE') ? 1 : 0,
                    'D' => ($type === 'DELETE') ? 1 : 0
                ];
            }
        }
    }

    /**
     * 関数の依存関係グラフを取得
     */
    public function getFunctionDependencies(): array
    {
        return $this->functionDependencies;
    }

    private function fallbackParseFunctionBody(string $code): ?array
    {
        $result = ['tables' => [], 'crud' => []];
        
        // SQLパターンの検出
        $patterns = [
            'select' => '/SELECT\s+.*?\bFROM\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            'insert' => '/INSERT\s+INTO\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            'update' => '/UPDATE\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            'delete' => '/DELETE\s+FROM\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ];

        foreach ($patterns as $type => $pattern) {
            if (preg_match_all($pattern, $code, $matches)) {
                foreach ($matches[1] as $table) {
                    $result['tables'][] = $table;
                    $result['crud'][$table] = [
                        'C' => ($type === 'insert') ? 1 : 0,
                        'R' => ($type === 'select') ? 1 : 0,
                        'U' => ($type === 'update') ? 1 : 0,
                        'D' => ($type === 'delete') ? 1 : 0
                    ];
                }
            }
        }

        return $result;
    }

    private function getFunctionCode(Node\Stmt\Function_ $node): string
    {
        $startLine = $node->getStartLine();
        $endLine = $node->getEndLine();
        $lines = file($node->getAttribute('filePath', ''));
        return implode('', array_slice($lines, $startLine - 1, $endLine - $startLine + 1));
    }

    private function getMethodCode(Node\Stmt\ClassMethod $node): string
    {
        $startLine = $node->getStartLine();
        $endLine = $node->getEndLine();
        $lines = file($node->getAttribute('filePath', ''));
        return implode('', array_slice($lines, $startLine - 1, $endLine - $startLine + 1));
    }
}

/*―――  AST 解析 ―――*/
function analyzeWithPhpParser(string $code, string $file, array &$logData): array
{
    try {
        $parser = (new ParserFactory())->createForNewestSupportedVersion();
        $ast = $parser->parse($code);
        
        // 定数解決機能を初期化
        $constantResolver = new ConstantResolver();
        $constantResolver->collectConstants($ast);
        
        // 変数解決機能を初期化
        $variableResolver = new VariableResolver();
        $variableResolver->collectVariables($ast);
        
        // 関数解決機能を初期化
        $functionResolver = new FunctionResolver();
        $functionResolver->collectFunctions($ast);
        
        // インクルード解決機能を初期化
        $includeResolver = new IncludeResolver();
        $includeResolver->resolveIncludes($file, $code, [], $logData);
        
        $visitor = new class($constantResolver, $variableResolver, $functionResolver, $file) extends NodeVisitorAbstract {
            private $fragments = [];
            private $constantResolver;
            private $variableResolver;
            private $functionResolver;
            private $file;
            private $crudData = [];
            
            public function __construct(
                ConstantResolver $constantResolver,
                VariableResolver $variableResolver,
                FunctionResolver $functionResolver,
                string $file
            ) {
                $this->constantResolver = $constantResolver;
                $this->variableResolver = $variableResolver;
                $this->functionResolver = $functionResolver;
                $this->file = $file;
            }
            
            public function leaveNode(Node $node) {
                if ($node instanceof Node\Expr\FuncCall) {
                    $result = $this->functionResolver->resolveFunctionCall($node);
                    if ($result) {
                        foreach ($result['tables'] as $table) {
                            $this->fragments[] = "-- Table: {$table}";
                            if (isset($result['crud'][$table])) {
                                $this->crudData[$table] = $result['crud'][$table];
                            }
                        }
                    }
                } elseif ($node instanceof Node\Expr\MethodCall) {
                    $result = $this->functionResolver->resolveMethodCall($node);
                    if ($result) {
                        foreach ($result['tables'] as $table) {
                            $this->fragments[] = "-- Table: {$table}";
                            if (isset($result['crud'][$table])) {
                                $this->crudData[$table] = $result['crud'][$table];
                            }
                        }
                    }
                } elseif ($node instanceof Node\Expr\BinaryOp\Concat) {
                    $sql = $this->extractSqlFromConcat($node);
                    if ($sql) {
                        $this->fragments[] = $sql;
                        $this->analyzeSqlForCrud($sql);
                    }
                } elseif ($node instanceof Node\Scalar\String_) {
                    $sql = $this->extractSqlFromString($node);
                    if ($sql) {
                        $this->fragments[] = $sql;
                        $this->analyzeSqlForCrud($sql);
                    }
                }
            }

            private function extractSqlFromConcat(Node\Expr\BinaryOp\Concat $node): ?string {
                $left = $this->getStringValue($node->left);
                $right = $this->getStringValue($node->right);
                
                if ($left !== null && $right !== null) {
                    $sql = $left . $right;
                    // 定数と変数を解決
                    $sql = $this->constantResolver->resolveString($sql);
                    $sql = $this->variableResolver->resolveString($sql);
                    if (preg_match('/\b(SELECT|INSERT|UPDATE|DELETE|WITH)\b/i', $sql)) {
                        return $sql;
                    }
                }
                return null;
            }

            private function extractSqlFromString(Node\Scalar\String_ $node): ?string {
                $sql = $node->value;
                // 定数と変数を解決
                $sql = $this->constantResolver->resolveString($sql);
                $sql = $this->variableResolver->resolveString($sql);
                if (preg_match('/\b(SELECT|INSERT|UPDATE|DELETE|WITH)\b/i', $sql)) {
                    return $sql;
                }
                return null;
            }

            private function getStringValue($node): ?string {
                if ($node instanceof Node\Scalar\String_) {
                    $value = $this->constantResolver->resolveString($node->value);
                    return $this->variableResolver->resolveString($value);
                } elseif ($node instanceof Node\Expr\Variable) {
                    $value = $this->variableResolver->resolveVariable($node->name);
                    if (is_array($value)) {
                        return json_encode($value);
                    }
                    return $value !== null ? strval($value) : null;
                } elseif ($node instanceof Node\Expr\ConstFetch) {
                    $value = $this->constantResolver->resolveConstant($node->name->toString());
                    if (is_array($value)) {
                        return json_encode($value);
                    }
                    return $value !== null ? strval($value) : null;
                }
                return null;
            }

            private function analyzeSqlForCrud(string $sql): void {
                try {
                    $parser = new PHPSQLParser(false, true);
                    $parser->parse($sql);
                    $tree = $parser->parsed;

                    // クエリタイプの判定
                    $type = strtoupper($tree['type'] ?? '');
                    
                    // テーブル名の抽出
                    $tables = $this->extractTables($tree);
                    
                    foreach ($tables as $table) {
                        $this->crudData[$table] = [
                            'C' => ($type === 'INSERT') ? 1 : 0,
                            'R' => ($type === 'SELECT') ? 1 : 0,
                            'U' => ($type === 'UPDATE') ? 1 : 0,
                            'D' => ($type === 'DELETE') ? 1 : 0
                        ];
                    }
                } catch (\Exception $e) {
                    // SQL解析エラーは無視
                }
            }

            private function extractTables(array $sqlTree): array {
                $tables = [];
                
                // FROM句のテーブル
                if (isset($sqlTree['FROM'])) {
                    foreach ($sqlTree['FROM'] as $from) {
                        if (isset($from['table'])) {
                            $tables[] = $from['table'];
                        }
                    }
                }
                
                // INSERT/UPDATEのテーブル
                if (isset($sqlTree['INSERT'])) {
                    $tables[] = $sqlTree['INSERT'][1]['table'];
                }
                if (isset($sqlTree['UPDATE'])) {
                    $tables[] = $sqlTree['UPDATE'][0]['table'];
                }
                
                // WITH句のテーブル
                if (isset($sqlTree['WITH'])) {
                    foreach ($sqlTree['WITH'] as $with) {
                        if (isset($with['name'])) {
                            $tables[] = $with['name'];
                        }
                    }
                }
                
                return array_unique($tables);
            }

            public function getFragments(): array {
                return $this->fragments;
            }

            public function getCrudData(): array {
                return $this->crudData;
            }
        };

        $traverser = new NodeTraverser();
        $traverser->addVisitor($visitor);
        $traverser->traverse($ast);
        
        // CRUDデータをグローバル変数にマージ
        $crudData = $visitor->getCrudData();
        if (!empty($crudData)) {
            $GLOBALS['crudData'][$file] = $crudData;
        }
        
        $fragments = $visitor->getFragments();
        
        // 結果が空の場合はフォールバック処理を実行
        if (empty($fragments)) {
            $fallbackAnalyzer = new FallbackAnalyzer();
            $fragments = $fallbackAnalyzer->analyzeSQL($code);
            if (!empty($fragments)) {
                $logData[] = [
                    'file' => $file,
                    'line' => 0,
                    'msg' => "フォールバック処理でSQLを検出"
                ];
            }
        }
        
        return $fragments;
    } catch (PhpParserError $e) {
        $logData[] = [
            'file' => $file,
            'line' => $e->getStartLine(),
            'msg' => "PhpParserError: {$e->getMessage()} — fallback"
        ];
        return fallbackParse($code);
    } catch (\Throwable $e) {
        $logData[] = [
            'file' => $file,
            'line' => 0,
            'msg' => "解析エラー: {$e->getMessage()} — fallback"
        ];
        return fallbackParse($code);
    }
}

/*―――  fallbackParse ―――*/
function fallbackParse(string $code): array
{
    $sqlFragments = [];
    
    // SQL文のパターン
    $patterns = [
        // 文字列リテラル
        '/["\'](SELECT|INSERT|UPDATE|DELETE|WITH).*?["\']/is',
        // HEREDOC/NOWDOC
        '/<<<[\'"]?(\w+)[\'"]?\s+(SELECT|INSERT|UPDATE|DELETE|WITH).*?\1;/is',
        // 文字列結合
        '/\.\s*["\'](SELECT|INSERT|UPDATE|DELETE|WITH).*?["\']/is'
    ];

    foreach ($patterns as $pattern) {
        if (preg_match_all($pattern, $code, $matches)) {
            foreach ($matches[0] as $match) {
                // クォートを除去
                $sql = preg_replace('/^["\']|["\']$/', '', $match);
                $sqlFragments[] = $sql;
            }
        }
    }

    return $sqlFragments;
}

/*―――  SQL 文字列結合復元 ―――*/
function assembleSQL(array $fragments): array
{
    $assembled = [];
    $current = '';
    
    foreach ($fragments as $fragment) {
        // 文字列結合演算子（.=）の検出
        if (preg_match('/\.=$/', $current)) {
            $current = rtrim($current, '.=') . $fragment;
        } else {
            if ($current !== '') {
                $assembled[] = $current;
            }
            $current = $fragment;
        }
    }
    
    if ($current !== '') {
        $assembled[] = $current;
    }

    // sprintf の処理
    $final = [];
    foreach ($assembled as $sql) {
        if (preg_match('/sprintf\s*\(/', $sql)) {
            // 変数をプレースホルダーに置換
            $sql = preg_replace('/\$\w+/', '?', $sql);
        }
        $final[] = $sql;
    }

    return $final;
}

/*―――  SQL → CRUD 判定（ビュー/PROC 注釈付き） ―――*/
/**
 * @param string $sql SQL文
 * @param array $views ビュー一覧
 * @param array $procedures プロシージャ一覧
 * @return array CRUD操作の配列
 * @noinspection PhpUndefinedClassInspection
 */
function analyzeSQL(string $sql, array $views, array $procedures): array
{
    // 1) bool(false) を渡してコンストラクタの型要件を満たす
    $parser = new PHPSQLParser(false, true);
    // 2) ここで SQL をパース
    $parser->parse($sql);
    $tree = $parser->parsed;

    $resolver = new CrudResolver($views, $procedures);
    return $resolver->resolve($tree);
}

/*―――  CRUD 配列へマージ ―――*/
function mergeCrud(array &$dst, string $file, array $crudOps): void
{
    foreach ($crudOps as $table => $ops) {
        $dst[$file][$table] ??= ['C' => 0, 'R' => 0, 'U' => 0, 'D' => 0];
        foreach (['C', 'R', 'U', 'D'] as $c) {
            $dst[$file][$table][$c] += $ops[$c];
        }
    }
}

/*========================================================
  E1 : Excel 出力
========================================================*/
function exportExcel(array $crudData, array $logData, string $outputDir): void
{
    $ss = new Spreadsheet();

    // File-CRUD シート
    $ws = $ss->getActiveSheet()->setTitle('File-CRUD');
    $ws->fromArray(['ファイル', 'テーブル', 'C', 'R', 'U', 'D'], null, 'A1');
    $row = 2;
    foreach ($crudData as $file => $tables) {
        foreach ($tables as $table => $ops) {
            $ws->setCellValue("A{$row}", $file);
            $ws->setCellValue("B{$row}", $table);
            $ws->setCellValue("C{$row}", $ops['C'] ? '○' : '');
            $ws->setCellValue("D{$row}", $ops['R'] ? '○' : '');
            $ws->setCellValue("E{$row}", $ops['U'] ? '○' : '');
            $ws->setCellValue("F{$row}", $ops['D'] ? '○' : '');
            $row++;
        }
    }

    // LOG シート
    $logWs = $ss->createSheet()->setTitle('LOG');
    $logWs->fromArray(['ファイル', '行番号', 'メッセージ'], null, 'A1');
    $row = 2;
    foreach ($logData as $log) {
        $logWs->setCellValue("A{$row}", $log['file']);
        $logWs->setCellValue("B{$row}", $log['line']);
        $logWs->setCellValue("C{$row}", $log['msg']);
        $row++;
    }

    // External-Access シート
    $externalWs = $ss->createSheet()->setTitle('External-Access');
    $externalWs->fromArray(['ファイル', '行番号', 'ドメイン', 'タイプ'], null, 'A1');
    $row = 2;
    $externalData = [];
    foreach ($logData as $log) {
        if (strpos($log['msg'], '外部リソース検出:') !== false) {
            $parts = explode(':', $log['msg']);
            $domains = explode(', ', trim($parts[1]));
            foreach ($domains as $domain) {
                $externalWs->setCellValue("A{$row}", $log['file']);
                $externalWs->setCellValue("B{$row}", $log['line']);
                $externalWs->setCellValue("C{$row}", $domain);
                $externalWs->setCellValue("D{$row}", 'API');
                $externalData[] = [
                    'file' => $log['file'],
                    'line' => $log['line'],
                    'domain' => $domain,
                    'type' => 'API'
                ];
                $row++;
            }
        }
    }

    // Function-Dependencies シート
    $functionResolver = new FunctionResolver();
    $dependencies = $functionResolver->getFunctionDependencies();
    $depWs = $ss->createSheet()->setTitle('Function-Dependencies');
    $depWs->fromArray(['関数', '依存関係'], null, 'A1');
    $row = 2;
    foreach ($dependencies as $function => $deps) {
        $depWs->setCellValue("A{$row}", $function);
        $depWs->setCellValue("B{$row}", implode(', ', $deps));
        $row++;
    }

    // Include-Files シート
    $includeResolver = new IncludeResolver();
    $includes = $includeResolver->getResolvedIncludes();
    $includeWs = $ss->createSheet()->setTitle('Include-Files');
    $includeWs->fromArray(['ファイル', '行番号', 'インクルードパス', 'タイプ'], null, 'A1');
    $row = 2;
    foreach ($includes as $file => $fileIncludes) {
        foreach ($fileIncludes as $include) {
            $includeWs->setCellValue("A{$row}", $file);
            $includeWs->setCellValue("B{$row}", $include['line']);
            $includeWs->setCellValue("C{$row}", $include['path']);
            $includeWs->setCellValue("D{$row}", $include['type']);
            $row++;
        }
    }

    // Summary シート
    $summaryWs = $ss->createSheet()->setTitle('Summary');
    $summaryData = [
        ['統計項目', '値'],
        ['解析ファイル数', count($crudData)],
        ['テーブル数', count(array_unique(array_keys(array_merge(...array_values($crudData)))))],
        ['外部アクセス数', count($externalData)],
        ['関数依存関係数', count($dependencies)],
        ['インクルードファイル数', count($includes, COUNT_RECURSIVE) - count($includes)],
        ['エラー数', count(array_filter($logData, fn($l) => strpos($l['msg'], '失敗') !== false))]
    ];
    $summaryWs->fromArray($summaryData, null, 'A1');

    // 列幅の自動調整
    foreach ($ss->getAllSheets() as $sheet) {
        foreach (range('A', $sheet->getHighestColumn()) as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }
    }

    $name = $outputDir . '/analyze_result_' . date('Ymd_His') . '.xlsx';
    (new Xlsx($ss))->save($name);
    echo "Excel 出力完了: {$name}\n";
}

/*========================================================
  クラス定義
========================================================*/
class ExternalResourceAnalyzer {
    private $parser;
    private $traverser;
    private $externalResources = [];
    private $patterns = [
        'url' => [
            'fetch' => '/fetch\s*\(\s*[\'"]([^\'"]+)[\'"]/',
            'axios' => '/axios\.(?:get|post|put|delete|patch|head|options)\s*\(\s*[\'"]([^\'"]+)[\'"]/',
            'xhr' => '/\.open\s*\(\s*[\'"]\w+[\'"]\s*,\s*[\'"]([^\'"]+)[\'"]/',
            'jquery' => '/\$\s*\.(?:ajax|get|post|getJSON|getScript)\s*\(\s*[\'"]([^\'"]+)[\'"]/',
            'websocket' => '/new\s+WebSocket\s*\(\s*[\'"]([^\'"]+)[\'"]/'
        ],
        'domain' => '/(?:https?:\/\/|wss?:\/\/)([^\/\s]+)/'
    ];

    public function __construct() {
        $this->parser = (new ParserFactory())->createForNewestSupportedVersion();
        $this->traverser = new NodeTraverser();
        $this->traverser->addVisitor(new class($this) extends NodeVisitorAbstract {
            private $analyzer;

            public function __construct($analyzer) {
                $this->analyzer = $analyzer;
            }

            public function enterNode(Node $node) {
                if ($node instanceof FuncCall) {
                    $this->analyzer->analyzeFunctionCall($node);
                } elseif ($node instanceof MethodCall) {
                    $this->analyzer->analyzeMethodCall($node);
                } elseif ($node instanceof New_) {
                    $this->analyzer->analyzeNewExpression($node);
                }
            }
        });
    }

    public function analyze($code) {
        try {
            $ast = $this->parser->parse($code);
            $this->traverser->traverse($ast);
        } catch (PhpParserError $error) {
            // フォールバック処理
            $this->fallbackAnalysis($code);
        }
        return $this->externalResources;
    }

    public function analyzeFunctionCall(FuncCall $node) {
        if ($node->name instanceof Name) {
            $functionName = $node->name->toString();
            if (in_array($functionName, ['fetch', 'axios', 'jQuery', '$'])) {
                $this->extractUrlFromArguments($node->args);
            }
        }
    }

    public function analyzeMethodCall(MethodCall $node) {
        if ($node->name instanceof Identifier) {
            $methodName = $node->name->toString();
            if (in_array($methodName, ['get', 'post', 'put', 'delete', 'ajax', 'open'])) {
                $this->extractUrlFromArguments($node->args);
            }
        }
    }

    public function analyzeNewExpression(New_ $node) {
        if ($node->class instanceof Name) {
            $className = $node->class->toString();
            if ($className === 'WebSocket') {
                $this->extractUrlFromArguments($node->args);
            }
        }
    }

    private function extractUrlFromArguments(array $args) {
        foreach ($args as $arg) {
            if ($arg->value instanceof String_) {
                $url = $arg->value->value;
                $this->processUrl($url);
            }
        }
    }

    private function processUrl($url) {
        if (preg_match($this->patterns['domain'], $url, $matches)) {
            $domain = $matches[1];
            if (!in_array($domain, $this->externalResources)) {
                $this->externalResources[] = $domain;
            }
        }
    }

    private function fallbackAnalysis($code) {
        foreach ($this->patterns['url'] as $type => $pattern) {
            if (preg_match_all($pattern, $code, $matches)) {
                foreach ($matches[1] as $url) {
                    $this->processUrl($url);
                }
            }
        }
    }
}

class CrudResolver
{
    public function __construct(
        private array $views,
        private array $procedures
    ) {
    }

    public function resolve(array $sqlTree): array
    {
        $result = [];
        $tables = $this->extractTables($sqlTree);
        
        foreach ($tables as $table) {
            if (isset($this->views[$table])) {
                $result[$table] = ['R' => 1];
                continue;
            }
            
            if (isset($this->procedures[$table])) {
                $result[$table] = ['C' => 1, 'R' => 1, 'U' => 1, 'D' => 1];
                continue;
            }
            
            $result[$table] = $this->determineCrudOperations($sqlTree, $table);
        }
        
        return $result;
    }

    private function extractTables(array $sqlTree): array
    {
        $tables = [];
        if (!isset($sqlTree['FROM'])) {
            return $tables;
        }
        
        foreach ($sqlTree['FROM'] as $from) {
            if (isset($from['table'])) {
                $tables[] = $from['table'];
            }
        }
        
        return array_unique($tables);
    }

    private function determineCrudOperations(array $sqlTree, string $table): array
    {
        $type = strtoupper($sqlTree['type'] ?? '');
        return [
            'C' => ($type === 'INSERT') ? 1 : 0,
            'R' => ($type === 'SELECT') ? 1 : 0,
            'U' => ($type === 'UPDATE') ? 1 : 0,
            'D' => ($type === 'DELETE') ? 1 : 0
        ];
    }
}

class LogBuffer {
    private static array $logs = [];
    private const LOG_LEVELS = [
        'DEBUG' => 0,
        'INFO' => 1,
        'WARN' => 2,
        'ERROR' => 3
    ];

    public static function add(string $message, string $level = 'INFO', string $file = '', int $line = 0): void {
        self::$logs[] = [
            'message' => $message,
            'level' => $level,
            'file' => $file,
            'line' => $line,
            'timestamp' => date('Y-m-d H:i:s')
        ];

        if ($level === 'ERROR') {
            fwrite(STDERR, sprintf("[%s] %s (%s:%d)\n", $level, $message, $file, $line));
        }
    }

    public static function getLogs(): array {
        return self::$logs;
    }

    public static function clear(): void {
        self::$logs = [];
    }
}

class FallbackAnalyzer {
    private const SQL_PATTERNS = [
        'SELECT' => [
            '/\bSELECT\b.*?\bFROM\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bSELECT\b.*?\bJOIN\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bSELECT\b.*?\bINTO\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ],
        'INSERT' => [
            '/\bINSERT\s+INTO\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bINSERT\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ],
        'UPDATE' => [
            '/\bUPDATE\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bUPDATE\b.*?\bSET\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ],
        'DELETE' => [
            '/\bDELETE\s+FROM\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bDELETE\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ],
        'WITH' => [
            '/\bWITH\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is',
            '/\bWITH\s+RECURSIVE\b\s+([a-zA-Z_][a-zA-Z0-9_]*)/is'
        ]
    ];
    
    private const VARIABLE_PATTERN = '/\$([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*([^;]+);/';
    private const FUNCTION_PATTERN = '/function\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\((.*?)\)\s*{/';
    private const INCLUDE_PATTERN = '/(include|require)(?:_once)?\s*\(?\s*[\'"]([^\'"]*)[\'"]\s*\)?/';
    
    public function analyzeSQL(string $code): array {
        $results = [];
        $code = $this->preprocessCode($code);
        
        foreach (self::SQL_PATTERNS as $type => $patterns) {
            foreach ($patterns as $pattern) {
                if (preg_match_all($pattern, $code, $matches)) {
                    foreach ($matches[1] as $table) {
                        $table = trim($table);
                        if (!empty($table)) {
                            $results[] = [
                                'type' => $type,
                                'table' => $table,
                                'sql' => $matches[0][0] ?? ''
                            ];
                        }
                    }
                }
            }
        }
        
        // 変数内のSQLを検出
        $variables = $this->analyzeVariables($code);
        foreach ($variables as $varName => $value) {
            if (preg_match('/\b(SELECT|INSERT|UPDATE|DELETE|WITH)\b/i', $value)) {
                $results[] = [
                    'type' => 'VARIABLE',
                    'table' => $varName,
                    'sql' => $value
                ];
            }
        }
        
        return $results;
    }
    
    private function preprocessCode(string $code): string {
        // コメントを除去
        $code = preg_replace('/\/\*.*?\*\//s', '', $code);
        $code = preg_replace('/\/\/.*?$/m', '', $code);
        $code = preg_replace('/#.*?$/m', '', $code);
        
        // 文字列リテラルを一時的に置換
        $strings = [];
        $code = preg_replace_callback('/[\'"](.*?)[\'"]/s', function($matches) use (&$strings) {
            $key = '___STRING_' . count($strings) . '___';
            $strings[$key] = $matches[0];
            return $key;
        }, $code);
        
        // 文字列を元に戻す
        foreach ($strings as $key => $value) {
            $code = str_replace($key, $value, $code);
        }
        
        return $code;
    }
    
    public function analyzeVariables(string $code): array {
        $variables = [];
        if (preg_match_all(self::VARIABLE_PATTERN, $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $variables[$match[1]] = trim($match[2]);
            }
        }
        return $variables;
    }
    
    public function analyzeFunctions(string $code): array {
        $functions = [];
        if (preg_match_all(self::FUNCTION_PATTERN, $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $functions[$match[1]] = [
                    'params' => $this->parseParameters($match[2]),
                    'body' => $this->extractFunctionBody($code, $match[0])
                ];
            }
        }
        return $functions;
    }
    
    public function analyzeIncludes(string $code): array {
        $includes = [];
        if (preg_match_all(self::INCLUDE_PATTERN, $code, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $includes[] = [
                    'type' => $match[1],
                    'path' => $match[2]
                ];
            }
        }
        return $includes;
    }
    
    private function parseParameters(string $paramString): array {
        $params = [];
        $paramString = trim($paramString);
        if (empty($paramString)) {
            return $params;
        }
        
        $paramParts = explode(',', $paramString);
        foreach ($paramParts as $param) {
            $param = trim($param);
            if (strpos($param, '$') === 0) {
                $params[] = substr($param, 1);
            }
        }
        return $params;
    }
    
    private function extractFunctionBody(string $code, string $functionStart): string {
        $startPos = strpos($code, $functionStart) + strlen($functionStart);
        $level = 0;
        $body = '';
        
        for ($i = $startPos; $i < strlen($code); $i++) {
            if ($code[$i] === '{') {
                $level++;
            } elseif ($code[$i] === '}') {
                $level--;
                if ($level === 0) {
                    break;
                }
            }
            $body .= $code[$i];
        }
        
        return trim($body);
    }
}
