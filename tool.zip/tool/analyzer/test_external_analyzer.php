<?php
require_once __DIR__ . '/analyzer.php';

// テスト用のサンプルファイルのパス
$testFile = __DIR__ . '/../samples/js/external_access/test_external.js';

// テスト実行
echo "=== 外部リソース解析テスト ===\n";

// ファイルの内容を読み込む
$code = file_get_contents($testFile);
if ($code === false) {
    die("テストファイルの読み込みに失敗しました\n");
}

// ExternalResourceAnalyzerのインスタンスを作成
$analyzer = new ExternalResourceAnalyzer();

// 解析を実行
$resources = $analyzer->analyze($code);

// 結果の表示
echo "検出された外部リソース:\n";
foreach ($resources as $resource) {
    echo "- {$resource}\n";
}

// 期待される結果との比較
$expected = [
    'api.example.com',
    'another-api.example.com',
    'ws-api.example.com'
];

$missing = array_diff($expected, $resources);
$extra = array_diff($resources, $expected);

if (empty($missing) && empty($extra)) {
    echo "\nテスト成功: すべての外部リソースが正しく検出されました\n";
} else {
    echo "\nテスト失敗:\n";
    if (!empty($missing)) {
        echo "検出されなかったリソース:\n";
        foreach ($missing as $resource) {
            echo "- {$resource}\n";
        }
    }
    if (!empty($extra)) {
        echo "誤検出されたリソース:\n";
        foreach ($extra as $resource) {
            echo "- {$resource}\n";
        }
    }
} 