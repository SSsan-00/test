<?php

declare(strict_types=1);

namespace Tests;

use Analyzer\LogBuffer;
use PHPUnit\Framework\TestCase;

class LogBufferTest extends TestCase
{
    protected function setUp(): void
    {
        LogBuffer::clear();
    }

    public function testAddLog(): void
    {
        $message = 'Test log message';
        $file = 'test.php';
        $line = 42;
        
        LogBuffer::add('INFO', $message, $file, $line);
        
        $logs = LogBuffer::getLogs();
        $this->assertCount(1, $logs);
        
        $log = $logs[0];
        $this->assertEquals('INFO', $log['level']);
        $this->assertEquals($message, $log['message']);
        $this->assertEquals($file, $log['file']);
        $this->assertEquals($line, $log['line']);
        $this->assertMatchesRegularExpression('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $log['timestamp']);
    }

    public function testMultipleLogs(): void
    {
        LogBuffer::add('INFO', 'Info message');
        LogBuffer::add('WARN', 'Warning message');
        LogBuffer::add('ERROR', 'Error message');
        
        $logs = LogBuffer::getLogs();
        $this->assertCount(3, $logs);
        
        $this->assertEquals('INFO', $logs[0]['level']);
        $this->assertEquals('WARN', $logs[1]['level']);
        $this->assertEquals('ERROR', $logs[2]['level']);
    }

    public function testClearLogs(): void
    {
        LogBuffer::add('INFO', 'Test message');
        $this->assertCount(1, LogBuffer::getLogs());
        
        LogBuffer::clear();
        $this->assertCount(0, LogBuffer::getLogs());
    }

    public function testErrorOutput(): void
    {
        // Create a temporary stream for STDERR
        $tempStream = fopen('php://temp', 'w+');
        $originalStderr = STDERR;
        
        try {
            // Redirect STDERR to our temporary stream
            stream_set_blocking($tempStream, true);
            fclose(STDERR);
            define('STDERR', $tempStream);
            
            LogBuffer::add('ERROR', 'Test error message', 'test.php', 123);
            
            // Read the output from our temporary stream
            rewind($tempStream);
            $output = stream_get_contents($tempStream);
            
            $this->assertStringContainsString('ERROR: Test error message (test.php:123)', $output);
            
        } finally {
            // Restore original STDERR
            fclose($tempStream);
            define('STDERR', $originalStderr);
        }
    }
} 