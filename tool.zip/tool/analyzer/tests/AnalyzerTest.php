<?php

declare(strict_types=1);

namespace Analyzer\Tests;

use PHPUnit\Framework\TestCase;
use Analyzer\FallbackAnalyzer;
use Analyzer\ConstantResolver;
use Analyzer\VariableResolver;
use Analyzer\FunctionResolver;
use Analyzer\ExternalResourceAnalyzer;
use Analyzer\CrudResolver;
use PhpParser\ParserFactory;
use PhpParser\NodeTraverser;

class AnalyzerTest extends TestCase
{
    private FallbackAnalyzer $fallbackAnalyzer;
    private ConstantResolver $constantResolver;
    private VariableResolver $variableResolver;
    private FunctionResolver $functionResolver;
    private ExternalResourceAnalyzer $externalResourceAnalyzer;
    private CrudResolver $crudResolver;

    protected function setUp(): void
    {
        $this->fallbackAnalyzer = new FallbackAnalyzer();
        $this->constantResolver = new ConstantResolver();
        $this->variableResolver = new VariableResolver();
        $this->functionResolver = new FunctionResolver();
        $this->externalResourceAnalyzer = new ExternalResourceAnalyzer();
        $this->crudResolver = new CrudResolver([], []);
    }

    public function testFallbackAnalyzerBasicSQL(): void
    {
        $code = <<<'PHP'
        <?php
        $sql = "SELECT * FROM users WHERE id = 1";
        $insert = "INSERT INTO orders (user_id, amount) VALUES (1, 100)";
        $update = "UPDATE products SET price = 200 WHERE id = 1";
        $delete = "DELETE FROM cart WHERE user_id = 1";
        PHP;

        $results = $this->fallbackAnalyzer->analyzeSQL($code);
        
        $this->assertCount(4, $results);
        $this->assertEquals('SELECT', $results[0]['type']);
        $this->assertEquals('users', $results[0]['table']);
        $this->assertEquals('INSERT', $results[1]['type']);
        $this->assertEquals('orders', $results[1]['table']);
        $this->assertEquals('UPDATE', $results[2]['type']);
        $this->assertEquals('products', $results[2]['table']);
        $this->assertEquals('DELETE', $results[3]['type']);
        $this->assertEquals('cart', $results[3]['table']);
    }

    public function testFallbackAnalyzerComplexSQL(): void
    {
        $code = <<<'PHP'
        <?php
        $query = "SELECT u.name, o.amount 
                 FROM users u 
                 JOIN orders o ON u.id = o.user_id 
                 WHERE u.status = 'active'";
        
        $withQuery = "WITH recent_orders AS (
            SELECT * FROM orders WHERE created_at > NOW() - INTERVAL '7 days'
        )
        SELECT * FROM recent_orders";
        PHP;

        $results = $this->fallbackAnalyzer->analyzeSQL($code);
        
        $this->assertCount(3, $results);
        $this->assertEquals('SELECT', $results[0]['type']);
        $this->assertEquals('users', $results[0]['table']);
        $this->assertEquals('SELECT', $results[1]['type']);
        $this->assertEquals('orders', $results[1]['table']);
        $this->assertEquals('WITH', $results[2]['type']);
        $this->assertEquals('recent_orders', $results[2]['table']);
    }

    public function testFallbackAnalyzerVariableSQL(): void
    {
        $code = <<<'PHP'
        <?php
        $table = "users";
        $where = "status = 'active'";
        $sql = "SELECT * FROM {$table} WHERE {$where}";
        PHP;

        $results = $this->fallbackAnalyzer->analyzeSQL($code);
        
        $this->assertCount(2, $results);
        $this->assertEquals('SELECT', $results[0]['type']);
        $this->assertEquals('users', $results[0]['table']);
        $this->assertEquals('VARIABLE', $results[1]['type']);
        $this->assertEquals('table', $results[1]['table']);
    }

    public function testConstantResolver(): void
    {
        $code = <<<'PHP'
        <?php
        define('DB_HOST', 'localhost');
        define('DB_NAME', 'test_db');
        define('DB_USER', 'root');
        define('DB_PASS', 'password');
        PHP;

        $parser = (new ParserFactory())->createForNewestSupportedVersion();
        $ast = $parser->parse($code);
        
        $this->constantResolver->collectConstants($ast);
        
        $this->assertEquals('localhost', $this->constantResolver->resolveConstant('DB_HOST'));
        $this->assertEquals('test_db', $this->constantResolver->resolveConstant('DB_NAME'));
        $this->assertEquals('root', $this->constantResolver->resolveConstant('DB_USER'));
        $this->assertEquals('password', $this->constantResolver->resolveConstant('DB_PASS'));
    }

    public function testVariableResolver(): void
    {
        $code = <<<'PHP'
        <?php
        $host = 'localhost';
        $port = 3306;
        $config = [
            'database' => 'test_db',
            'username' => 'root'
        ];
        PHP;

        $parser = (new ParserFactory())->createForNewestSupportedVersion();
        $ast = $parser->parse($code);
        
        $this->variableResolver->collectVariables($ast);
        
        $this->assertEquals('localhost', $this->variableResolver->resolveVariable('host'));
        $this->assertEquals(3306, $this->variableResolver->resolveVariable('port'));
        $this->assertEquals(['database' => 'test_db', 'username' => 'root'], 
            $this->variableResolver->resolveVariable('config'));
    }

    public function testFunctionResolver(): void
    {
        $code = <<<'PHP'
        <?php
        function getUser($id) {
            return "SELECT * FROM users WHERE id = {$id}";
        }
        
        function getOrders($userId) {
            return "SELECT * FROM orders WHERE user_id = {$userId}";
        }
        PHP;

        $parser = (new ParserFactory())->createForNewestSupportedVersion();
        $ast = $parser->parse($code);
        
        $this->functionResolver->collectFunctions($ast);
        
        $result = $this->functionResolver->resolveFunctionCall(
            new \PhpParser\Node\Expr\FuncCall(
                new \PhpParser\Node\Name('getUser'),
                [new \PhpParser\Node\Arg(new \PhpParser\Node\Scalar\LNumber(1))]
            )
        );
        
        $this->assertNotNull($result);
        $this->assertContains('users', $result['tables']);
    }

    public function testExternalResourceAnalyzer(): void
    {
        $code = <<<'PHP'
        <?php
        fetch('https://api.example.com/users');
        axios.get('https://api.example.com/orders');
        new WebSocket('wss://ws.example.com');
        PHP;

        $results = $this->externalResourceAnalyzer->analyze($code);
        
        $this->assertCount(2, $results);
        $this->assertContains('api.example.com', $results);
        $this->assertContains('ws.example.com', $results);
    }

    public function testCrudResolver(): void
    {
        $sql = "SELECT * FROM users WHERE id = 1";
        $parser = new \PHPSQLParser\PHPSQLParser(false, true);
        $tree = $parser->parse($sql);
        
        $result = $this->crudResolver->resolve($tree);
        
        $this->assertArrayHasKey('users', $result);
        $this->assertEquals(1, $result['users']['R']);
        $this->assertEquals(0, $result['users']['C']);
        $this->assertEquals(0, $result['users']['U']);
        $this->assertEquals(0, $result['users']['D']);
    }
} 