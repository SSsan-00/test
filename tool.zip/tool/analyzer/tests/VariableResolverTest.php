<?php

declare(strict_types=1);

namespace Tests;

use PHPUnit\Framework\TestCase;
use Analyzer\VariableResolver;
use PhpParser\ParserFactory;
use PhpParser\Node;

class VariableResolverTest extends TestCase
{
    private VariableResolver $resolver;
    private $parser;

    protected function setUp(): void
    {
        $this->resolver = new VariableResolver();
        $this->parser = (new ParserFactory())->createForNewestSupportedVersion();
    }

    /**
     * @test
     */
    public function testBasicVariableAssignment(): void
    {
        $code = '<?php $test = "value";';
        $ast = $this->parser->parse($code);
        
        $variables = $this->resolver->resolveVariables($ast[0]);
        
        $this->assertArrayHasKey('test', $variables);
        $this->assertEquals('value', $variables['test']);
    }

    /**
     * @test
     */
    public function testArrayAssignment(): void
    {
        $code = '<?php $arr = ["key" => "value"];';
        $ast = $this->parser->parse($code);
        
        $variables = $this->resolver->resolveVariables($ast[0]);
        
        $this->assertArrayHasKey('arr', $variables);
        $this->assertIsArray($variables['arr']);
        $this->assertEquals('value', $variables['arr']['key']);
    }

    /**
     * @test
     */
    public function testConditionalVariableAssignment(): void
    {
        $code = '<?php if ($condition) { $test = "value"; }';
        $ast = $this->parser->parse($code);
        
        $variables = $this->resolver->resolveVariables($ast[0]);
        
        $this->assertArrayHasKey('test', $variables);
    }

    /**
     * @test
     */
    public function testStringResolution(): void
    {
        $code = '<?php 
            $name = "John";
            $greeting = "Hello ${name}!";
        ';
        $ast = $this->parser->parse($code);
        
        foreach ($ast as $node) {
            $this->resolver->resolveVariables($node);
        }
        
        $result = $this->resolver->resolveString('Hello ${name}!');
        $this->assertEquals('Hello John!', $result);
    }

    /**
     * @test
     */
    public function testArrayAccessInString(): void
    {
        $code = '<?php 
            $data = ["user" => "John"];
            $greeting = "Hello ${data[user]}!";
        ';
        $ast = $this->parser->parse($code);
        
        foreach ($ast as $node) {
            $this->resolver->resolveVariables($node);
        }
        
        $result = $this->resolver->resolveString('Hello ${data[user]}!');
        $this->assertEquals('Hello John!', $result);
    }

    /**
     * @test
     */
    public function testFallbackParsing(): void
    {
        $result = $this->resolver->getFallbackValue('"test string"');
        $this->assertEquals('test string', $result);

        $result = $this->resolver->getFallbackValue('[1, 2, 3]');
        $this->assertEquals(['1', '2', '3'], array_map('trim', $result));

        $result = $this->resolver->getFallbackValue('123');
        $this->assertEquals(123, $result);
    }

    /**
     * @test
     */
    public function testComplexStringResolution(): void
    {
        $code = '<?php 
            $user = ["name" => "John", "age" => 30];
            $message = "User ${user[name]} is ${user[age]} years old.";
        ';
        $ast = $this->parser->parse($code);
        
        foreach ($ast as $node) {
            $this->resolver->resolveVariables($node);
        }
        
        $result = $this->resolver->resolveString('User ${user[name]} is ${user[age]} years old.');
        $this->assertEquals('User John is 30 years old.', $result);
    }

    /**
     * @test
     */
    public function testMethodCallInString(): void
    {
        $code = '<?php 
            $obj = new class {
                public function getName() {
                    return "John";
                }
            };
            $greeting = "Hello {$obj->getName()}!";
        ';
        $ast = $this->parser->parse($code);
        
        foreach ($ast as $node) {
            $this->resolver->resolveVariables($node);
        }
        
        $result = $this->resolver->resolveString('Hello ${obj->getName()}!');
        $this->assertStringContainsString('Hello', $result);
    }

    /**
     * @test
     */
    public function testStringConcatenation(): void
    {
        $code = '<?php $result = "Hello" . " " . "World";';
        $ast = $this->parser->parse($code);
        
        $variables = $this->resolver->resolveVariables($ast[0]);
        
        $this->assertArrayHasKey('result', $variables);
        $this->assertEquals('Hello World', $variables['result']);
    }
} 