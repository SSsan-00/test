<?php
declare(strict_types=1);

use PHPUnit\Framework\TestCase;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

require_once dirname(__DIR__) . '/analyzer.php';

/**
 * メタデータ読み込みブロック (A1) の単体テスト
 */
final class MetaDataTest extends TestCase
{
    private string $tmpDir;

    protected function setUp(): void
    {
        $this->tmpDir = sys_get_temp_dir() . '/meta_test_' . uniqid();
        mkdir($this->tmpDir);
    }

    protected function tearDown(): void
    {
        exec('rm -rf ' . escapeshellarg($this->tmpDir));
    }

    public function testLoadMetaDataNormal(): void
    {
        /*--- view_list.txt ---*/
        file_put_contents("{$this->tmpDir}/view_list.txt", "v_users\nv_sales\n");

        /*--- procedure_list.txt ---*/
        file_put_contents("{$this->tmpDir}/procedure_list.txt", "p_insert\np_update\n");

        /*--- meta_matrix.xlsx ---*/
        $ss = new Spreadsheet();
        $ws = $ss->getActiveSheet()->setTitle('Proc-TableMatrix');
        $ws->fromArray(['', 'p_insert', 'p_update'], null, 'A1');
        $ws->fromArray(['users', 'CR', ''], null, 'A2');
        $ws->fromArray(['sales', '', 'D'], null, 'A3');
        (new Xlsx($ss))->save("{$this->tmpDir}/meta_matrix.xlsx");

        /*--- call loadMetaData ---*/
        $views = $procs = $crud = $log = [];
        loadMetaData($this->tmpDir, $views, $procs, $crud, $log);

        /*--- assertions ---*/
        $this->assertSame(['v_users', 'v_sales'], $views);
        $this->assertSame(['p_insert', 'p_update'], $procs);
        $this->assertArrayHasKey('p_insert@proc', $crud);
        $this->assertSame(['C'=>1,'R'=>1,'U'=>0,'D'=>0], $crud['p_insert@proc']['users']);
        $this->assertSame(['C'=>0,'R'=>0,'U'=>0,'D'=>1], $crud['p_update@proc']['sales']);
    }
}
