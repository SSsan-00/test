<?php
#!/usr/bin/env php
/**
 * analyzer.php — テーブルエイリアス解決対応版（AS句有無対応）
 */

require 'vendor/autoload.php';
use PHPSQLParser\PHPSQLParser;

function analyzeSQLWithAliasResolution(string $sql): array {
    $parser = new PHPSQLParser();
    $parsed = $parser->parse($sql);
    $tables = [];
    $types = [];

    // FROM 句
    if (isset($parsed['FROM'])) {
        foreach ($parsed['FROM'] as $entry) {
            if ($entry['expr_type'] === 'table') {
                $tables[$entry['table']] = true;
                $types[$entry['table']] = 'R';
            }
        }
    }

    // JOIN 句
    if (isset($parsed['JOIN'])) {
        foreach ($parsed['JOIN'] as $entry) {
            if ($entry['expr_type'] === 'table') {
                $tables[$entry['table']] = true;
                $types[$entry['table']] = 'R';
            }
        }
    }

    // INSERT / UPDATE / DELETE
    if (isset($parsed['INSERT'])) {
        foreach ($parsed['INSERT'] as $entry) {
            if ($entry['expr_type'] === 'table') {
                $tables[$entry['table']] = true;
                $types[$entry['table']] = 'C';
            }
        }
    }
    if (isset($parsed['UPDATE'])) {
        foreach ($parsed['UPDATE'] as $entry) {
            if ($entry['expr_type'] === 'table') {
                $tables[$entry['table']] = true;
                $types[$entry['table']] = 'U';
            }
        }
    }
    if (isset($parsed['DELETE'])) {
        foreach ($parsed['FROM'] as $entry) {
            if ($entry['expr_type'] === 'table') {
                $tables[$entry['table']] = true;
                $types[$entry['table']] = 'D';
            }
        }
    }

    $result = [];
    foreach ($tables as $table => $_) {
        $result[$table] = $types[$table] ?? 'R';
    }
    return $result;
}

$input = $argv[1] ?? '';
if (!$input || !file_exists($input)) {
    fwrite(STDERR, "Usage: php analyzer.php /path/to/file.php\n");
    exit(1);
}

$code = file_get_contents($input);
$sqls = [];
preg_match_all('/\$\w+\s*=\s*\"(.+?)\";/s', $code, $matches);
foreach ($matches[1] as $sql) {
    $sqls[] = $sql;
}

foreach ($sqls as $sql) {
    $result = analyzeSQLWithAliasResolution($sql);
    foreach ($result as $table => $crud) {
        echo "Table: $table | Op: $crud\n";
    }
}
