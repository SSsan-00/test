<?php
#!/usr/bin/env php
/**
 * analyzer.php — 引数付き関数にも対応した完全版 PHP ソースコード解析ツール
 */

require 'vendor/autoload.php';
use PHPSQLParser\PHPSQLParser;
use PhpParser\ParserFactory;
use PhpParser\Node;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;
use PhpParser\Node\Expr;

function collectCodeWithIncludes(string $filepath, array &$visited = [], string $baseDir = ''): string {
    $baseDir = $baseDir ?: dirname($filepath);
    $realpath = realpath($filepath);
    if (!$realpath || isset($visited[$realpath])) return '';
    $visited[$realpath] = true;
    $code = file_get_contents($realpath);
    $merged = $code;
    if (preg_match_all('/\b(include|require)(_once)?\s*\(?\s*["\'](.+?)["\']\s*\)?\s*;/', $code, $m)) {
        foreach ($m[3] as $inc) {
            $path = realpath($baseDir . DIRECTORY_SEPARATOR . $inc);
            if ($path && file_exists($path)) {
                $merged .= "\n" . collectCodeWithIncludes($path, $visited, dirname($path));
            }
        }
    }
    return $merged;
}

function extractParameterizedSQLFunctions(string $code): array {
    $parser = (new ParserFactory())->createForNewestSupportedVersion();
    $ast = $parser->parse($code);
    $result = [];
    $visitor = new class($result) extends NodeVisitorAbstract {
        public $result;
        public function __construct(&$result) { $this->result = &$result; }
        public function enterNode(Node $node) {
            if ($node instanceof Node\Stmt\Function_) {
                $funcName = $node->name->toString();
                $params = array_map(fn($p) => $p->var->name, $node->params);
                foreach ($node->stmts as $stmt) {
                    if ($stmt instanceof Node\Stmt\Return_) {
                        $sql = self::resolveConcat($stmt->expr, $params);
                        if (self::looksLikeSQL($sql)) {
                            $this->result[$funcName] = [
                                'args' => $params,
                                'template' => $sql
                            ];
                        }
                    }
                }
            }
        }
        private static function resolveConcat($expr, array $params): string {
            if ($expr instanceof Node\Scalar\String_) return $expr->value;
            elseif ($expr instanceof Node\Expr\BinaryOp\Concat) return self::resolveConcat($expr->left, $params) . self::resolveConcat($expr->right, $params);
            elseif ($expr instanceof Node\Expr\Variable && in_array($expr->name, $params)) return "__{$expr->name}__";
            else return '';
        }
        private static function looksLikeSQL(string $sql): bool {
            return preg_match('/\b(SELECT|INSERT|UPDATE|DELETE)\b/i', $sql);
        }
    };
    
    $traverser = new NodeTraverser();
    $traverser->addVisitor($visitor);
    $traverser->traverse($ast);
    return $visitor->result;
}

function extractFuncCallArgs(Node\Expr\FuncCall $call): array {
    $args = [];
    foreach ($call->args as $arg) {
        if ($arg->value instanceof Node\Scalar\String_) {
            $args[] = $arg->value->value;
        } else {
            return []; // 動的な引数は無視
        }
    }
    return $args;
}

function applyArgsToTemplate(string $template, array $argNames, array $argValues): ?string {
    if (count($argNames) !== count($argValues)) return null;
    $sql = $template;
    foreach ($argNames as $i => $name) {
        $sql = str_replace("__{$name}__", $argValues[$i], $sql);
    }
    return $sql;
}

function resolveSQLWithASTCalls(string $code, array $templates): array {
    $parser = (new ParserFactory())->createForNewestSupportedVersion();
    $ast = $parser->parse($code);
    $sqls = [];

    $traverser = new NodeTraverser();
    $traverser->addVisitor(new class($sqls, $templates) extends NodeVisitorAbstract {
        private $sqls, $templates;
        public function __construct(&$sqls, $templates) {
            $this->sqls = &$sqls;
            $this->templates = $templates;
        }
        public function enterNode(Node $node) {
            if ($node instanceof Node\Expr\Assign && $node->var instanceof Node\Expr\Variable && $node->expr instanceof Node\Expr\FuncCall) {
                $varName = $node->var->name;
                $funcName = $node->expr->name instanceof Node\Name ? $node->expr->name->toString() : null;
                if ($funcName && isset($this->templates[$funcName])) {
                    $argValues = extractFuncCallArgs($node->expr);
                    $sql = applyArgsToTemplate($this->templates[$funcName]['template'], $this->templates[$funcName]['args'], $argValues);
                    if ($sql !== null) {
                        $this->sqls[$varName] = $sql;
                    }
                }
            }
        }
    });
    $traverser->traverse($ast);
    return $sqls;
}

function analyzeSQL(string $sql): array {
    $parser = new PHPSQLParser();
    $parsed = $parser->parse($sql);
    $result = [];
    if (isset($parsed['INSERT'])) { $tables = $parsed['INSERT']; $type = 'C'; }
    elseif (isset($parsed['UPDATE'])) { $tables = $parsed['UPDATE']; $type = 'U'; }
    elseif (isset($parsed['DELETE'])) { $tables = $parsed['FROM'];   $type = 'D'; }
    elseif (isset($parsed['FROM']))   { $tables = $parsed['FROM'];   $type = 'R'; }
    else { return []; }
    foreach ($tables as $t) {
        if ($t['expr_type'] === 'table') $result[$t['table']] = $type;
    }
    if (isset($parsed['JOIN'])) {
        foreach ($parsed['JOIN'] as $j) {
            if ($j['expr_type'] === 'table') $result[$j['table']] = 'R';
        }
    }
    return $result;
}

function getTargetFiles(string $path): array {
    $targets = [];
    if (is_file($path)) {
        $targets[] = realpath($path);
    } elseif (is_dir($path)) {
        $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));
        foreach ($rii as $file) {
            if ($file->isFile()) {
                $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if (in_array($ext, ['php', 'inc'])) {
                    $targets[] = $file->getRealPath();
                }
            }
        }
    }
    return $targets;
}

$input = $argv[1] ?? '';
if (!$input || !file_exists($input)) {
    fwrite(STDERR, "Usage: php analyzer.php /path/to/file_or_directory\n");
    exit(1);
}

$files = getTargetFiles($input);

foreach ($files as $target) {
    echo "=== $target ===\n";
    $visited = [];
    $code = collectCodeWithIncludes($target, $visited);
    $templates = extractParameterizedSQLFunctions($code);
    $sqls = resolveSQLWithASTCalls($code, $templates);

    foreach ($sqls as $var => $sql) {
        $result = analyzeSQL($sql);
        foreach ($result as $table => $crud) {
            echo "Var: \$$var | Table: $table | Op: $crud\n";
        }
    }
    echo "\n";
}
