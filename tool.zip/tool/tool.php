#!/usr/bin/env php
<?php

function scanTargetFiles($dir, $extensions = ['php', 'inc', 'html', 'js']) {
    $files = [];

    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));

    foreach ($rii as $file) {
        if ($file->isDir()) continue;

        $ext = strtolower(pathinfo($file->getFilename(), PATHINFO_EXTENSION));
        if (in_array($ext, $extensions)) {
            $files[] = $file->getPathname();
        }
    }

    return $files;
}

// 実行
$targetDir = $argv[1] ?? '.';
$files = scanTargetFiles($targetDir);

echo "対象ファイル一覧:\n";
foreach ($files as $f) {
    echo "- " . $f . "\n";
}
