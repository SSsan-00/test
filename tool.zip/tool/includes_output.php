#!/usr/bin/env php
<?php

require_once './includes_check.php';

$targetFile = $argv[1] ?? 'main.php';
$visited = [];

$allCode = collectCodeWithIncludes($targetFile, $visited);
echo "===== 統合コード =====\n";
echo $allCode;
