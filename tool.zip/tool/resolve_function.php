<?php
#!/usr/bin/env php
/**
 * analyzer.php — 完全版 PHP ソースコード解析ツール（関数戻りSQL対応）
 *
 * - include/require の再帰解決
 * - define() 定数の抽出・展開
 * - SQL 文字列結合解決（=, .=, 定数・関数展開）
 * - ユーザー定義関数の戻りSQLに対応
 * - php-sql-parser による SQL 構文解析・CRUD判定
 *
 * 実行方法: php analyzer.php /path/to/file_or_directory
 */

require 'vendor/autoload.php';
use PHPSQLParser\PHPSQLParser;
use PhpParser\ParserFactory;
use PhpParser\Node;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;

function collectCodeWithIncludes(string $filepath, array &$visited = [], string $baseDir = ''): string {
    $baseDir = $baseDir ?: dirname($filepath);
    $realpath = realpath($filepath);
    if (!$realpath || isset($visited[$realpath])) return '';
    $visited[$realpath] = true;

    $code = file_get_contents($realpath);
    $merged = $code;
    if (preg_match_all('/\b(include|require)(_once)?\s*\(?\s*[\"\'](.+?)[\"\']\s*\)?\s*;/', $code, $m)) {
        foreach ($m[3] as $inc) {
            $path = realpath($baseDir . DIRECTORY_SEPARATOR . $inc);
            if ($path && file_exists($path)) {
                $merged .= "\n" . collectCodeWithIncludes($path, $visited, dirname($path));
            }
        }
    }
    return $merged;
}

function extractDefines(string $code): array {
    $defs = [];
    if (preg_match_all('/define\s*\(\s*[\"\'](\w+)[\"\']\s*,\s*[\"\'](.+?)[\"\']\s*\)\s*;/', $code, $m, PREG_SET_ORDER)) {
        foreach ($m as $d) { $defs[$d[1]] = $d[2]; }
    }
    return $defs;
}

function extractSQLReturningFunctions(string $code): array {
    try {
        $parser = (new ParserFactory())->createForNewestSupportedVersion();
        $ast = $parser->parse($code);
        if ($ast === null) {
            return [];
        }
        
        $functions = [];
        $traverser = new NodeTraverser();
        $visitor = new class($functions) extends NodeVisitorAbstract {
            private $functions;
            public function __construct(&$functions) { 
                $this->functions = &$functions; 
            }
            public function enterNode(Node $node) {
                if ($node instanceof Node\Stmt\Function_) {
                    $name = $node->name->toString();
                    foreach ($node->stmts as $stmt) {
                        if ($stmt instanceof Node\Stmt\Return_ && $stmt->expr instanceof Node\Scalar\String_) {
                            $this->functions[$name] = $stmt->expr->value;
                        }
                    }
                }
            }
        };
        $traverser->addVisitor($visitor);
        $traverser->traverse($ast);
        return $functions;
    } catch (\PhpParser\Error $e) {
        error_log("PHP Parser Error: " . $e->getMessage());
        return [];
    } catch (\Exception $e) {
        error_log("Unexpected Error: " . $e->getMessage());
        return [];
    }
}

function resolveSQLVarsWithFunctions(array $lines, array $defines, array $functionSQLs): array {
    $sqls = [];
    foreach ($lines as $line) {
        if (preg_match('/\$(\w+)\s*=\s*[\"\'](.+)[\"\']\s*;/', $line, $m)) {
            $sqls[$m[1]] = $m[2];
        } elseif (preg_match('/\$(\w+)\s*=\s*(\w+)\s*;/', $line, $m) && isset($defines[$m[2]])) {
            $sqls[$m[1]] = $defines[$m[2]];
        } elseif (preg_match('/\$(\w+)\s*=\s*(\w+)\(\s*\)\s*;/', $line, $m) && isset($functionSQLs[$m[2]])) {
            $sqls[$m[1]] = $functionSQLs[$m[2]];
        } elseif (preg_match('/\$(\w+)\s*\.\=\s*[\"\'](.+)[\"\']\s*;/', $line, $m) && isset($sqls[$m[1]])) {
            $sqls[$m[1]] .= $m[2];
        } elseif (preg_match('/\$(\w+)\s*\.\=\s*(\w+)\s*;/', $line, $m) && isset($defines[$m[2]])) {
            $sqls[$m[1]] .= $defines[$m[2]];
        }
    }
    return $sqls;
}

function analyzeSQL(string $sql): array {
    $parser = new PHPSQLParser();
    $parsed = $parser->parse($sql);
    $result = [];
    if (isset($parsed['INSERT'])) { $tables = $parsed['INSERT']; $type = 'C'; }
    elseif (isset($parsed['UPDATE'])) { $tables = $parsed['UPDATE']; $type = 'U'; }
    elseif (isset($parsed['DELETE'])) { $tables = $parsed['FROM'];   $type = 'D'; }
    elseif (isset($parsed['FROM']))   { $tables = $parsed['FROM'];   $type = 'R'; }
    else { return []; }
    foreach ($tables as $t) {
        if ($t['expr_type']==='table') $result[$t['table']] = $type;
    }
    if (isset($parsed['JOIN'])) {
        foreach ($parsed['JOIN'] as $j) {
            if ($j['expr_type']==='table') $result[$j['table']] = 'R';
        }
    }
    return $result;
}

function getTargetFiles(string $path): array {
    $targets = [];
    if (is_file($path)) {
        $targets[] = realpath($path);
    } elseif (is_dir($path)) {
        $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));
        foreach ($rii as $file) {
            if ($file->isFile()) {
                $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if (in_array($ext, ['php', 'inc'])) {
                    $targets[] = $file->getRealPath();
                }
            }
        }
    }
    return $targets;
}

$input = $argv[1] ?? '';
if (!$input || !file_exists($input)) {
    fwrite(STDERR, "Usage: php analyzer.php /path/to/file_or_directory\n");
    exit(1);
}

$files = getTargetFiles($input);

foreach ($files as $target) {
    echo "=== $target ===\n";
    $visited = [];
    $allCode = collectCodeWithIncludes($target, $visited);
    $defines = extractDefines($allCode);
    $funcSQLs = extractSQLReturningFunctions($allCode);
    $lines = explode("\n", $allCode);
    $sqlVars = resolveSQLVarsWithFunctions($lines, $defines, $funcSQLs);
    foreach ($sqlVars as $var => $sql) {
        $result = analyzeSQL($sql);
        foreach ($result as $table => $crud) {
            echo "Var: \$$var | Table: $table | Op: $crud\n";
        }
    }
    echo "\n";
}