<?php
#!/usr/bin/env php
/**
 * analyzer.php — CTE & サブクエリ完全対応版（regexフォールバック付き）
 *
 * - PHP-SQL-Parser で解析
 * - CTE（WITH句）の内部SQLも解析
 * - サブクエリ（FROM (... )）も解析
 * - フォールバックで正規表現も併用
 */

require 'vendor/autoload.php';
use PHPSQLParser\PHPSQLParser;

// コードからSQL文字列を抽出
function extractSQLStrings(string $code): array {
    preg_match_all('/\$\w+\s*=\s*"(.+?)";/s', $code, $matches);
    return $matches[1] ?? [];
}

// WITH句からCTE名とサブSQLを抽出
function extractCTEs(string $sql): array {
    $ctes = [];
    if (preg_match_all('/WITH\s+(\w+)\s+AS\s*\((.*?)\)\s*(?=SELECT)/is', $sql, $m)) {
        foreach ($m[1] as $i => $name) {
            $ctes[$name] = $m[2][$i];
        }
    }
    return $ctes;
}

// FROM句のサブクエリを抽出
function extractSubqueries(string $sql): array {
    $subs = [];
    if (preg_match_all('/FROM\s*\(\s*(SELECT.+?)\)\s*\w*/is', $sql, $m)) {
        $subs = $m[1];
    }
    return $subs;
}

// SQLを解析し、sub_treeも保持
function parseSQL(string $sql): array {
    $parser = new PHPSQLParser();
    return $parser->parse($sql, true);
}

// 解析結果からテーブル名とCRUDを収集
function collectTables(array $parsed): array {
    $res = [];
    foreach (['FROM','JOIN','UPDATE','INSERT','DELETE'] as $clause) {
        if (!isset($parsed[$clause])) continue;
        foreach ($parsed[$clause] as $entry) {
            if (($entry['expr_type'] ?? '') === 'table') {
                $table = $entry['table'];
                $op = $clause === 'INSERT' ? 'C' : ($clause === 'UPDATE' ? 'U' : ($clause === 'DELETE' ? 'D' : 'R'));
                $res[$table] = $op;
            } elseif (($entry['expr_type'] ?? '') === 'subquery' && isset($entry['sub_tree'])) {
                foreach (collectTables($entry['sub_tree']) as $t => $o) {
                    $res[$t] = $o;
                }
            }
        }
    }
    return $res;
}

// メイン処理
$input = $argv[1] ?? '';
if (!$input || !file_exists($input)) {
    fwrite(STDERR, "Usage: php analyzer.php /path/to/file.php\n");
    exit(1);
}

$code = file_get_contents($input);
$sqls = extractSQLStrings($code);

foreach ($sqls as $sql) {
    $result = [];
    // CTE解析
    $ctes = extractCTEs($sql);
    foreach ($ctes as $cteName => $subSQL) {
        $result[$cteName] = '@cte';
        $parsedSub = parseSQL($subSQL);
        foreach (collectTables($parsedSub) as $t => $o) {
            $result[$t] = $o;
        }
    }
    // サブクエリ解析
    foreach (extractSubqueries($sql) as $subSQL) {
        $parsedSub = parseSQL($subSQL);
        foreach (collectTables($parsedSub) as $t => $o) {
            $result[$t] = $o;
        }
    }
    // 本文解析
    $parsedMain = parseSQL($sql);
    foreach (collectTables($parsedMain) as $t => $o) {
        if (!isset($result[$t])) {
            $result[$t] = $o;
        }
    }
    // 出力
    foreach ($result as $t => $o) {
        echo "Table: $t | Op: $o\n";
    }
    echo "\n";
}
