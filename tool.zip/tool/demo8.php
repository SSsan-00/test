<?php
#!/usr/bin/env php
/**
 * analyzer.php — 完全版 PHP ソースコード解析ツール
 *
 * - PHP-SQL-Parser & 正規表現フォールバック
 * - CTE、サブクエリ、一時テーブル検出
 * - ビュー (view_list.txt) をテーブル同様に解析 (@view)
 * - ストアドプロシージャ (sp_list.txt) の呼び出し検出 (@proc)
 */

require 'vendor/autoload.php';
use PHPSQLParser\PHPSQLParser;

// SQL文字列を抽出
function extractSQLStrings(string $code): array {
    preg_match_all('/\$\w+\s*=\s*"(.+?)";/s', $code, $m);
    return $m[1] ?? [];
}

// WITH句を抽出
function extractCTEs(string $sql): array {
    preg_match_all('/WITH\s+(\w+)\s+AS\s*\((.*?)\)\s*(?=SELECT)/is', $sql, $m);
    $ctes = [];
    foreach ($m[1] as $i => $name) {
        $ctes[$name] = $m[2][$i];
    }
    return $ctes;
}

// サブクエリを抽出
function extractSubqueries(string $sql): array {
    preg_match_all('/FROM\s*\(\s*(SELECT.+?)\)\s*\w*/is', $sql, $m);
    return $m[1] ?? [];
}

// 一時テーブルを抽出
function extractTempTables(string $sql): array {
    $temps = [];
    // CREATE TEMP[TORARY] TABLE name
    if (preg_match_all('/CREATE\s+TEMP(?:ORARY)?\s+TABLE\s+(\w+)/i', $sql, $m)) {
        foreach ($m[1] as $name) {
            $temps[$name] = 'C';
        }
    }
    // SELECT ... INTO name
    if (preg_match_all('/SELECT\s+.+?\s+INTO\s+(\w+)/i', $sql, $m)) {
        foreach ($m[1] as $name) {
            $temps[$name] = 'C';
        }
    }
    return $temps;
}

// PHP-SQL-Parser で解析
function parseSQL(string $sql): array {
    $parser = new PHPSQLParser();
    return $parser->parse($sql, true);
}

// 解析結果からテーブル操作を収集
function collectTables(array $parsed, array &$result, array $views) {
    foreach (['FROM','JOIN','UPDATE','INSERT','DELETE'] as $clause) {
        if (empty($parsed[$clause])) continue;
        foreach ($parsed[$clause] as $entry) {
            $type = 'R';
            if ($clause === 'INSERT') $type = 'C';
            elseif ($clause === 'UPDATE') $type = 'U';
            elseif ($clause === 'DELETE') $type = 'D';

            $exprType = $entry['expr_type'] ?? '';
            if ($exprType === 'table') {
                $tbl = $entry['table'];
                // ビュー判定
                $note = in_array($tbl, $views, true) ? '@view' : '';
                $result[$tbl] = [$type, $note];
            }
            // サブクエリ内再帰
            if ($exprType === 'subquery' && !empty($entry['sub_tree'])) {
                collectTables($entry['sub_tree'], $result, $views);
            }
        }
    }
}

// ストアドプロシージャ呼び出しを検出
function extractProcCalls(string $sql, array $sps): array {
    $procs = [];
    if (preg_match_all('/CALL\s+(\w+)\s*\(/i', $sql, $m)) {
        foreach ($m[1] as $name) {
            if (in_array($name, $sps, true)) {
                $procs[$name] = '@proc';
            }
        }
    }
    return $procs;
}

// main
$input = $argv[1] ?? '';
if (!$input || !file_exists($input)) {
    fwrite(STDERR, "Usage: php analyzer.php /path/to/file.php\n");
    exit(1);
}
$dir = dirname($input);

// 外部リスト読み込み
$viewFile = "$dir/view_list.txt";
$spFile   = "$dir/sp_list.txt";
$views = file_exists($viewFile) ? array_map('trim', file($viewFile)) : [];
$sps   = file_exists($spFile)   ? array_map('trim', file($spFile))   : [];

$code = file_get_contents($input);
$sqls = extractSQLStrings($code);

foreach ($sqls as $sql) {
    $result = [];
    // CTE解析
    $ctes = extractCTEs($sql);
    foreach ($ctes as $cteName => $sub) {
        $result[$cteName] = ['R','@cte'];
        $parsed = parseSQL($sub);
        collectTables($parsed, $result, $views);
    }
    // サブクエリ解析
    foreach (extractSubqueries($sql) as $sub) {
        $parsed = parseSQL($sub);
        collectTables($parsed, $result, $views);
    }
    // 一時テーブル解析
    foreach (extractTempTables($sql) as $tbl => $op) {
        $result[$tbl] = [$op,'@temp'];
    }
    // 本文解析
    $parsedMain = parseSQL($sql);
    collectTables($parsedMain, $result, $views);
    // プロシージャ呼び出し検出
    $procs = extractProcCalls($sql, $sps);
    foreach ($procs as $name => $note) {
        $result[$name] = ['','@proc'];
    }
    // 出力
    foreach ($result as $tbl => [$op, $note]) {
        $out = "Table: $tbl |";
        $out .= $op ? " Op: $op |" : ' Proc:';
        $out .= $note ? " Note: $note" : '';
        echo $out . "\n";
    }
    echo "\n";
}
