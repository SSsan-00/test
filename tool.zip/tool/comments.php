#!/usr/bin/env php
<?php

require_once 'remove_comments.php';

function scanAndClean($dir) {
    $extensions = ['php', 'inc', 'html', 'js'];
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));

    foreach ($rii as $file) {
        if ($file->isDir()) continue;

        $ext = strtolower(pathinfo($file->getFilename(), PATHINFO_EXTENSION));
        if (!in_array($ext, $extensions)) continue;

        $content = file_get_contents($file->getPathname());
        $cleaned = removeComments($content, $ext);

        echo "--- {$file->getFilename()} ---\n";
        echo $cleaned . "\n\n";
    }
}

$targetDir = $argv[1] ?? '.';
scanAndClean($targetDir);
