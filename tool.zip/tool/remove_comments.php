<?php

function removeComments(string $content, string $ext): string {
    if ($content === null) {
        return '';
    }
    switch (strtolower($ext)) {
        case 'php':
        case 'inc':
            // コメント除去（//, #, /* */）※PHPタグ内のみ対象
            $content = preg_replace([
                '~//.*?$~m',        // // コメント
                '~^\s*#.*?$~m',     // # コメント
                '~/\*.*?\*/~s'      // /* */ コメント
            ], '', $content);
            break;

        case 'html':
            // HTMLコメント <!-- -->
            $content = preg_replace('/<!--.*?-->/s', '', $content);
            break;

        case 'js':
            // JSコメント（//, /* */）
            $content = preg_replace([
                '#//.*?$#m',        // // コメント
                '#/\*.*?\*/#s'      // /* */ コメント
            ], '', $content);
            break;

        default:
            // 未対応拡張子はそのまま
            break;
    }

    return $content;
}
