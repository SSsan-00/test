<?php

declare(strict_types=1);

namespace Tests;

use PHPUnit\Framework\TestCase;
use Analyzer\VariableResolver;
use PhpParser\ParserFactory;

class VariableResolverTest extends TestCase
{
    private VariableResolver $resolver;
    private \PhpParser\Parser $parser;

    protected function setUp(): void
    {
        $this->resolver = new VariableResolver();
        $this->parser = (new ParserFactory())->createForNewestSupportedVersion();
    }

    public function testBasicVariableAssignment(): void
    {
        $code = <<<'PHP'
<?php
$name = "John";
$age = 30;
$height = 175.5;
PHP;

        $ast = $this->parser->parse($code);
        $this->resolver->collectVariables($ast);

        $this->assertEquals("John", $this->resolver->resolveVariable('name'));
        $this->assertEquals(30, $this->resolver->resolveVariable('age'));
        $this->assertEquals(175.5, $this->resolver->resolveVariable('height'));
    }

    public function testArrayAssignment(): void
    {
        $code = <<<'PHP'
<?php
$fruits = ["apple", "banana"];
$fruits[2] = "orange";
PHP;

        $ast = $this->parser->parse($code);
        $this->resolver->collectVariables($ast);

        $expected = ["apple", "banana", "orange"];
        $this->assertEquals($expected, $this->resolver->resolveVariable('fruits'));
    }

    public function testConditionalAssignment(): void
    {
        $code = <<<'PHP'
<?php
if ($condition === true) {
    $value = "true";
} else {
    $value = "false";
}
PHP;

        $ast = $this->parser->parse($code);
        $this->resolver->collectVariables($ast);

        $values = $this->resolver->resolveVariable('value');
        $this->assertIsArray($values);
        $this->assertContains("true", $values);
        $this->assertContains("false", $values);
    }

    public function testObjectPropertyAssignment(): void
    {
        $code = <<<'PHP'
<?php
$user = new User();
$user->name = "John";
$user->age = 30;
PHP;

        $ast = $this->parser->parse($code);
        $this->resolver->collectVariables($ast);

        $user = $this->resolver->resolveVariable('user');
        $this->assertNotNull($user);
        $this->assertEquals("User", $user);
    }

    public function testStringResolution(): void
    {
        $code = <<<'PHP'
<?php
$name = "John";
$age = 30;
$info = "Name: $name, Age: $age";
PHP;

        $ast = $this->parser->parse($code);
        $this->resolver->collectVariables($ast);

        $result = $this->resolver->resolveString('Hello ${name}, you are ${age} years old');
        $this->assertEquals('Hello John, you are 30 years old', $result);
    }

    public function testArrayAccessInString(): void
    {
        $code = <<<'PHP'
<?php
$users = ["John", "Jane"];
$message = "First user: $users[0]";
PHP;

        $ast = $this->parser->parse($code);
        $this->resolver->collectVariables($ast);

        $result = $this->resolver->resolveString('User: ${users[0]}');
        $this->assertEquals('User: John', $result);
    }

    public function testFallbackParsing(): void
    {
        // 意図的にASTパースを失敗させるための不正なコード
        $code = <<<'PHP'
<?php
$name = "John";
$age = 30;
$invalid syntax here
PHP;

        $ast = $this->parser->parse('<?php $dummy = 1;'); // ダミーASTを使用
        $this->resolver->collectVariables($ast);

        // フォールバックパーサーが基本的な変数代入を検出できることを確認
        $result = $this->resolver->resolveString('Name: ${name}, Age: ${age}');
        $this->assertStringContainsString('Name:', $result);
        $this->assertStringContainsString('Age:', $result);
    }

    public function testComplexStringResolution(): void
    {
        $code = <<<'PHP'
<?php
$user = new stdClass();
$user->name = "John";
$user->details = ["age" => 30, "city" => "Tokyo"];
$message = "User {$user->name} is {$user->details['age']} years old";
PHP;

        $ast = $this->parser->parse($code);
        $this->resolver->collectVariables($ast);

        $result = $this->resolver->resolveString('${user->name} lives in ${user->details[city]}');
        $this->assertEquals('John lives in Tokyo', $result);
    }

    public function testMethodCallInString(): void
    {
        $code = <<<'PHP'
<?php
class User {
    public function getFullName() {
        return "John Doe";
    }
}
$user = new User();
$name = $user->getFullName();
PHP;

        $ast = $this->parser->parse($code);
        $this->resolver->collectVariables($ast);

        $result = $this->resolver->resolveString('Full name: ${name}');
        $this->assertEquals('Full name: John Doe', $result);
    }

    public function testConcatenationInAssignment(): void
    {
        $code = <<<'PHP'
<?php
$first = "Hello";
$second = "World";
$greeting = $first . " " . $second;
PHP;

        $ast = $this->parser->parse($code);
        $this->resolver->collectVariables($ast);

        $result = $this->resolver->resolveString('${greeting}!');
        $this->assertEquals('Hello World!', $result);
    }
} 