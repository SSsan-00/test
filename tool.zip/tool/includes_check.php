<?php

/**
 * ファイルからすべての include / require 対象を再帰的に読み込み、
 * コードを一つに統合して返す
 */
function collectCodeWithIncludes(string $filepath, array &$visited = [], string $baseDir = ''): string {
    $baseDir = $baseDir ?: dirname($filepath);
    $realpath = realpath($filepath);
    if (!$realpath || isset($visited[$realpath])) return '';

    $visited[$realpath] = true;

    $code = file_get_contents($realpath);
    $mergedCode = $code;

    // include, require, include_once, require_once の検出
    if (preg_match_all('/\b(include|require)(_once)?\s*\(?\s*[\'"](.+?)[\'"]\s*\)?\s*;/', $code, $matches)) {
        foreach ($matches[3] as $inc) {
            $includedPath = realpath($baseDir . DIRECTORY_SEPARATOR . $inc);
            if ($includedPath && file_exists($includedPath)) {
                $mergedCode .= "\n\n" . collectCodeWithIncludes($includedPath, $visited, dirname($includedPath));
            }
        }
    }

    return $mergedCode;
}
