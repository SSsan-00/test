#!/usr/bin/env php
<?php

function resolveConcatenatedSQLFromFile(string $filepath): array {
    $lines = file($filepath);
    $sql_vars = [];

    foreach ($lines as $line) {
        // $sql = "..." パターン
        if (preg_match('/\$(\w+)\s*=\s*(["\'])(.*?)\2\s*;/', $line, $m)) {
            $sql_vars[$m[1]] = $m[3];
        }
        // $sql .= "..." パターン
        elseif (preg_match('/\$(\w+)\s*\.\=\s*(["\'])(.*?)\2\s*;/', $line, $m)) {
            if (isset($sql_vars[$m[1]])) {
                $sql_vars[$m[1]] .= $m[3];
            } else {
                $sql_vars[$m[1]] = $m[3];
            }
        }
    }

    return $sql_vars;
}

// ==== 実行 ====
$target = $argv[1] ?? '';
if (!file_exists($target)) {
    echo "ファイルが見つかりません: $target\n";
    exit(1);
}

$result = resolveConcatenatedSQLFromFile($target);
echo "復元されたSQL文字列:\n";
foreach ($result as $var => $sql) {
    echo "\$$var = \"$sql\"\n";
}
