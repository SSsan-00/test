<?php
#!/usr/bin/env php
/**
 * analyzer.php — 条件分岐 define() 対応版（すべての定数値を展開し注釈付き出力）
 */

require 'vendor/autoload.php';
use PHPSQLParser\PHPSQLParser;
use PhpParser\ParserFactory;
use PhpParser\Node;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;
use PhpParser\Node\Expr;

function collectCodeWithIncludes(string $filepath, array &$visited = [], string $baseDir = ''): string {
    $baseDir = $baseDir ?: dirname($filepath);
    $realpath = realpath($filepath);
    if (!$realpath || isset($visited[$realpath])) return '';
    $visited[$realpath] = true;
    $code = file_get_contents($realpath);
    $merged = $code;
    if (preg_match_all('/\b(include|require)(_once)?\s*\(?\s*["\'](.+?)["\']\s*\)?\s*;/', $code, $m)) {
        foreach ($m[3] as $inc) {
            $path = realpath($baseDir . DIRECTORY_SEPARATOR . $inc);
            if ($path && file_exists($path)) {
                $merged .= "\n" . collectCodeWithIncludes($path, $visited, dirname($path));
            }
        }
    }
    return $merged;
}

function extractAllDefineValues(string $code): array {
    $values = [];
    if (preg_match_all('/define\s*\(\s*["\'](\w+)["\']\s*,\s*["\'](.+?)["\']\s*\)\s*;/', $code, $m, PREG_SET_ORDER)) {
        foreach ($m as $match) {
            $values[$match[1]][] = $match[2];
        }
    }
    return $values;
}

function resolveSQLsFromDefines(string $template, string $placeholder, array $values): array {
    $sqls = [];
    foreach ($values as $val) {
        $sqls[] = str_replace($placeholder, $val, $template);
    }
    return $sqls;
}

function analyzeSQL(string $sql): array {
    $parser = new PHPSQLParser();
    $parsed = $parser->parse($sql);
    $result = [];
    if (isset($parsed['INSERT'])) { $tables = $parsed['INSERT']; $type = 'C'; }
    elseif (isset($parsed['UPDATE'])) { $tables = $parsed['UPDATE']; $type = 'U'; }
    elseif (isset($parsed['DELETE'])) { $tables = $parsed['FROM']; $type = 'D'; }
    elseif (isset($parsed['FROM']))   { $tables = $parsed['FROM']; $type = 'R'; }
    else { return []; }
    foreach ($tables as $t) {
        if ($t['expr_type'] === 'table') $result[$t['table']] = $type;
    }
    return $result;
}

$input = $argv[1] ?? '';
if (!$input || !file_exists($input)) {
    fwrite(STDERR, "Usage: php analyzer.php /path/to/file_or_directory\n");
    exit(1);
}

$visited = [];
$code = collectCodeWithIncludes($input, $visited);
$defines = extractAllDefineValues($code);

$template = 'SELECT * FROM ' . (isset($defines['TABLE_NAME']) ? 'TABLE_NAME' : '');

if (isset($defines['TABLE_NAME'])) {
    $sqls = resolveSQLsFromDefines($template, 'TABLE_NAME', $defines['TABLE_NAME']);
    foreach ($sqls as $sql) {
        $result = analyzeSQL($sql);
        foreach ($result as $table => $crud) {
            echo "Table: $table | Op: $crud | 注釈: @define-multi\n";
        }
    }
} else {
    echo "TABLE_NAME not defined.\n";
}
