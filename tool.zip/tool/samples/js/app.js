// メインアプリケーションコード
class App {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadInitialData();
    }

    setupEventListeners() {
        document.addEventListener('DOMContentLoaded', () => {
            // イベントリスナーの設定
            this.setupFormHandlers();
            this.setupNavigation();
        });
    }

    async loadInitialData() {
        try {
            const response = await fetch('/api/users');
            const data = await response.json();
            this.renderUserList(data);
        } catch (error) {
            console.error('データの読み込みに失敗しました:', error);
        }
    }

    setupFormHandlers() {
        const forms = document.querySelectorAll('form[data-ajax="true"]');
        forms.forEach(form => {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                await this.handleFormSubmit(form);
            });
        });
    }

    setupNavigation() {
        // ナビゲーションの設定
        const navLinks = document.querySelectorAll('nav a');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.navigateTo(link.href);
            });
        });
    }

    async handleFormSubmit(form) {
        const formData = new FormData(form);
        try {
            const response = await fetch(form.action, {
                method: form.method,
                body: formData
            });
            const result = await response.json();
            this.handleFormResponse(result);
        } catch (error) {
            console.error('フォーム送信に失敗しました:', error);
        }
    }

    renderUserList(users) {
        const container = document.getElementById('user-list');
        if (!container) return;

        container.innerHTML = users.map(user => `
            <div class="user-card">
                <h3>${user.name}</h3>
                <p>${user.email}</p>
            </div>
        `).join('');
    }
}

// アプリケーションの初期化
const app = new App(); 