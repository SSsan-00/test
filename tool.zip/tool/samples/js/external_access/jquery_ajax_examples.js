// jQueryのAjaxを使用した外部アクセスのサンプル

// 1. 基本的なGETリクエスト
function basicGetRequest() {
    $.ajax({
        url: 'https://api.example.com/data',
        method: 'GET',
        success: function(data) {
            console.log(data);
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
        }
    });
}

// 2. POSTリクエスト（JSONデータ）
function postJsonData() {
    $.ajax({
        url: 'https://api.example.com/submit',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            name: 'John Doe',
            email: 'john@example.com'
        }),
        success: function() {
            console.log('送信成功');
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
        }
    });
}

// 3. フォームデータの送信
function submitFormData() {
    const formData = new FormData();
    formData.append('username', 'user123');
    formData.append('password', 'pass123');

    $.ajax({
        url: 'https://api.example.com/form',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function() {
            console.log('フォーム送信成功');
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
        }
    });
}

// 4. バイナリデータの送信
function sendBinaryData() {
    const file = document.querySelector('input[type="file"]').files[0];
    const formData = new FormData();
    formData.append('file', file);

    $.ajax({
        url: 'https://api.example.com/upload',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function() {
            console.log('バイナリデータ送信成功');
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
        }
    });
}

// 5. カスタムヘッダーの設定
function requestWithCustomHeaders() {
    $.ajax({
        url: 'https://api.example.com/protected',
        method: 'GET',
        headers: {
            'Authorization': 'Bearer token123',
            'X-Custom-Header': 'value'
        },
        success: function(data) {
            console.log(data);
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
        }
    });
}

// 6. タイムアウトの設定
function requestWithTimeout() {
    $.ajax({
        url: 'https://api.example.com/slow',
        method: 'GET',
        timeout: 5000, // 5秒
        success: function(data) {
            console.log(data);
        },
        error: function(xhr, status, error) {
            if (status === 'timeout') {
                console.log('リクエストがタイムアウトしました');
            } else {
                console.error('Error:', error);
            }
        }
    });
}

// 7. 進捗状況の監視
function monitorProgress() {
    $.ajax({
        url: 'https://api.example.com/large-file',
        method: 'GET',
        xhr: function() {
            const xhr = new window.XMLHttpRequest();
            xhr.addEventListener('progress', function(event) {
                if (event.lengthComputable) {
                    const percentComplete = (event.loaded / event.total) * 100;
                    console.log(`ダウンロード進捗: ${percentComplete}%`);
                }
            });
            return xhr;
        },
        success: function() {
            console.log('ダウンロード完了');
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
        }
    });
}

// 8. エラーハンドリング
function handleErrors() {
    $.ajax({
        url: 'https://api.example.com/error',
        method: 'GET',
        success: function(data) {
            console.log(data);
        },
        error: function(xhr, status, error) {
            console.error(`エラーが発生しました: ${xhr.status} ${error}`);
        }
    });
}

// 9. クロスオリジンリクエスト
function crossOriginRequest() {
    $.ajax({
        url: 'https://another-domain.com/data',
        method: 'GET',
        xhrFields: {
            withCredentials: true
        },
        success: function(data) {
            console.log(data);
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
        }
    });
}

// 10. 複数のリクエストの並列実行
function parallelRequests() {
    const urls = [
        'https://api.example.com/data1',
        'https://api.example.com/data2',
        'https://api.example.com/data3'
    ];

    const requests = urls.map(url => 
        $.ajax({
            url: url,
            method: 'GET'
        })
    );

    $.when.apply($, requests).then(function() {
        const results = Array.from(arguments);
        results.forEach((data, index) => {
            console.log(`${urls[index]}:`, data[0]);
        });
    }).fail(function(error) {
        console.error('Error:', error);
    });
}

// 11. キャッシュ制御
function requestWithCacheControl() {
    $.ajax({
        url: 'https://api.example.com/data',
        method: 'GET',
        cache: false, // キャッシュを使用しない
        success: function(data) {
            console.log(data);
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
        }
    });
}

// 12. グローバルAjaxイベントハンドラ
$(document).ajaxStart(function() {
    console.log('Ajaxリクエスト開始');
});

$(document).ajaxComplete(function() {
    console.log('Ajaxリクエスト完了');
});

$(document).ajaxError(function(event, xhr, settings, error) {
    console.error('Ajaxエラー:', error);
});

// 13. リクエスト前の前処理
$.ajaxPrefilter(function(options, originalOptions, jqXHR) {
    // リクエスト前の処理
    console.log('リクエスト前の処理:', options.url);
});

// 14. レスポンスの前処理
$.ajaxSetup({
    converters: {
        'text json': function(text) {
            try {
                return JSON.parse(text);
            } catch (e) {
                return text;
            }
        }
    }
}); 