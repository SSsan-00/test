// Axiosを使用した外部アクセスのサンプル

// 1. 基本的なGETリクエスト
async function basicGetRequest() {
    try {
        const response = await axios.get('https://api.example.com/data');
        console.log(response.data);
    } catch (error) {
        console.error('Error:', error);
    }
}

// 2. POSTリクエスト（JSONデータ）
async function postJsonData() {
    try {
        const response = await axios.post('https://api.example.com/submit', {
            name: 'John Doe',
            email: 'john@example.com'
        });
        console.log('送信成功');
    } catch (error) {
        console.error('Error:', error);
    }
}

// 3. フォームデータの送信
async function submitFormData() {
    try {
        const formData = new FormData();
        formData.append('username', 'user123');
        formData.append('password', 'pass123');

        const response = await axios.post('https://api.example.com/form', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('フォーム送信成功');
    } catch (error) {
        console.error('Error:', error);
    }
}

// 4. バイナリデータの送信
async function sendBinaryData() {
    try {
        const file = document.querySelector('input[type="file"]').files[0];
        const formData = new FormData();
        formData.append('file', file);

        const response = await axios.post('https://api.example.com/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('バイナリデータ送信成功');
    } catch (error) {
        console.error('Error:', error);
    }
}

// 5. カスタムヘッダーの設定
async function requestWithCustomHeaders() {
    try {
        const response = await axios.get('https://api.example.com/protected', {
            headers: {
                'Authorization': 'Bearer token123',
                'X-Custom-Header': 'value'
            }
        });
        console.log(response.data);
    } catch (error) {
        console.error('Error:', error);
    }
}

// 6. タイムアウトの設定
async function requestWithTimeout() {
    try {
        const response = await axios.get('https://api.example.com/slow', {
            timeout: 5000 // 5秒
        });
        console.log(response.data);
    } catch (error) {
        if (error.code === 'ECONNABORTED') {
            console.log('リクエストがタイムアウトしました');
        } else {
            console.error('Error:', error);
        }
    }
}

// 7. 進捗状況の監視
async function monitorProgress() {
    try {
        const response = await axios.get('https://api.example.com/large-file', {
            onDownloadProgress: function(progressEvent) {
                const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                console.log(`ダウンロード進捗: ${percentCompleted}%`);
            }
        });
        console.log('ダウンロード完了');
    } catch (error) {
        console.error('Error:', error);
    }
}

// 8. エラーハンドリング
async function handleErrors() {
    try {
        const response = await axios.get('https://api.example.com/error');
        console.log(response.data);
    } catch (error) {
        if (error.response) {
            // サーバーからのエラーレスポンス
            console.error('Error:', error.response.status, error.response.data);
        } else if (error.request) {
            // リクエストは送信されたがレスポンスがない
            console.error('Error:', error.request);
        } else {
            // リクエストの設定中にエラーが発生
            console.error('Error:', error.message);
        }
    }
}

// 9. クロスオリジンリクエスト
async function crossOriginRequest() {
    try {
        const response = await axios.get('https://another-domain.com/data', {
            withCredentials: true // クッキーを含める
        });
        console.log(response.data);
    } catch (error) {
        console.error('Error:', error);
    }
}

// 10. 複数のリクエストの並列実行
async function parallelRequests() {
    try {
        const urls = [
            'https://api.example.com/data1',
            'https://api.example.com/data2',
            'https://api.example.com/data3'
        ];

        const requests = urls.map(url => axios.get(url));
        const responses = await axios.all(requests);
        
        responses.forEach((response, index) => {
            console.log(`${urls[index]}:`, response.data);
        });
    } catch (error) {
        console.error('Error:', error);
    }
}

// 11. インターセプターの設定
// リクエストインターセプター
axios.interceptors.request.use(
    function(config) {
        // リクエスト前の処理
        console.log('リクエスト前の処理:', config.url);
        return config;
    },
    function(error) {
        return Promise.reject(error);
    }
);

// レスポンスインターセプター
axios.interceptors.response.use(
    function(response) {
        // レスポンス前の処理
        return response;
    },
    function(error) {
        return Promise.reject(error);
    }
);

// 12. キャッシュ制御
async function requestWithCacheControl() {
    try {
        const response = await axios.get('https://api.example.com/data', {
            headers: {
                'Cache-Control': 'no-cache'
            }
        });
        console.log(response.data);
    } catch (error) {
        console.error('Error:', error);
    }
}

// 13. リクエストのキャンセル
async function cancelableRequest() {
    const source = axios.CancelToken.source();

    try {
        const response = await axios.get('https://api.example.com/data', {
            cancelToken: source.token
        });
        console.log(response.data);
    } catch (error) {
        if (axios.isCancel(error)) {
            console.log('リクエストがキャンセルされました');
        } else {
            console.error('Error:', error);
        }
    }

    // リクエストのキャンセル
    source.cancel('操作がキャンセルされました');
}

// 14. グローバル設定
axios.defaults.baseURL = 'https://api.example.com';
axios.defaults.timeout = 5000;
axios.defaults.headers.common['Authorization'] = 'Bearer token123'; 