// XMLHttpRequestを使用した外部アクセスのサンプル

// 1. 基本的なGETリクエスト
function basicGetRequest() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://api.example.com/data', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(JSON.parse(xhr.responseText));
        }
    };
    xhr.send();
}

// 2. POSTリクエスト（JSONデータ）
function postJsonData() {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://api.example.com/submit', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log('送信成功');
        }
    };
    const data = {
        name: 'John Doe',
        email: 'john@example.com'
    };
    xhr.send(JSON.stringify(data));
}

// 3. フォームデータの送信
function submitFormData() {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://api.example.com/form', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log('フォーム送信成功');
        }
    };
    const formData = new FormData();
    formData.append('username', 'user123');
    formData.append('password', 'pass123');
    xhr.send(formData);
}

// 4. バイナリデータの送信
function sendBinaryData() {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://api.example.com/upload', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log('バイナリデータ送信成功');
        }
    };
    const file = document.querySelector('input[type="file"]').files[0];
    xhr.send(file);
}

// 5. カスタムヘッダーの設定
function requestWithCustomHeaders() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://api.example.com/protected', true);
    xhr.setRequestHeader('Authorization', 'Bearer token123');
    xhr.setRequestHeader('X-Custom-Header', 'value');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(JSON.parse(xhr.responseText));
        }
    };
    xhr.send();
}

// 6. タイムアウトの設定
function requestWithTimeout() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://api.example.com/slow', true);
    xhr.timeout = 5000; // 5秒
    xhr.ontimeout = function() {
        console.log('リクエストがタイムアウトしました');
    };
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(JSON.parse(xhr.responseText));
        }
    };
    xhr.send();
}

// 7. 進捗状況の監視
function monitorProgress() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://api.example.com/large-file', true);
    xhr.onprogress = function(event) {
        if (event.lengthComputable) {
            const percentComplete = (event.loaded / event.total) * 100;
            console.log(`ダウンロード進捗: ${percentComplete}%`);
        }
    };
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log('ダウンロード完了');
        }
    };
    xhr.send();
}

// 8. エラーハンドリング
function handleErrors() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://api.example.com/error', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log(JSON.parse(xhr.responseText));
            } else {
                console.error(`エラーが発生しました: ${xhr.status} ${xhr.statusText}`);
            }
        }
    };
    xhr.onerror = function() {
        console.error('ネットワークエラーが発生しました');
    };
    xhr.send();
}

// 9. クロスオリジンリクエスト
function crossOriginRequest() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://another-domain.com/data', true);
    xhr.withCredentials = true; // クッキーを含める
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(JSON.parse(xhr.responseText));
        }
    };
    xhr.send();
}

// 10. 複数のリクエストの並列実行
function parallelRequests() {
    const urls = [
        'https://api.example.com/data1',
        'https://api.example.com/data2',
        'https://api.example.com/data3'
    ];
    
    urls.forEach(url => {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log(`${url}: ${xhr.responseText}`);
            }
        };
        xhr.send();
    });
} 