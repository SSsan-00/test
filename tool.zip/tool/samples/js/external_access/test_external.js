// Fetch APIの使用例
async function fetchData() {
    const response = await fetch('https://api.example.com/data');
    return response.json();
}

// Axiosの使用例
import axios from 'axios';
function getData() {
    return axios.get('https://api.example.com/users');
}

// XMLHttpRequestの使用例
function xhrRequest() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://api.example.com/products');
    xhr.send();
}

// jQueryの使用例
function jqueryRequest() {
    $.ajax({
        url: 'https://api.example.com/items',
        method: 'GET'
    });
}

// WebSocketの使用例
function connectWebSocket() {
    const ws = new WebSocket('wss://api.example.com/ws');
    ws.onmessage = (event) => {
        console.log(event.data);
    };
}

// 複数の外部リソースを含む例
function multipleRequests() {
    // 同じドメインへの複数リクエスト
    fetch('https://api.example.com/data1');
    fetch('https://api.example.com/data2');
    
    // 異なるドメインへのリクエスト
    axios.get('https://another-api.example.com/users');
    
    // WebSocket接続
    new WebSocket('wss://ws-api.example.com/stream');
} 