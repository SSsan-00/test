// WebSocketを使用した外部アクセスのサンプル

// 1. 基本的なWebSocket接続
function basicWebSocketConnection() {
    const socket = new WebSocket('wss://example.com/ws');

    // 接続が開かれたとき
    socket.onopen = function(event) {
        console.log('WebSocket接続が確立されました');
        // メッセージの送信
        socket.send('Hello Server!');
    };

    // メッセージを受信したとき
    socket.onmessage = function(event) {
        console.log('受信したメッセージ:', event.data);
    };

    // エラーが発生したとき
    socket.onerror = function(error) {
        console.error('WebSocketエラー:', error);
    };

    // 接続が閉じられたとき
    socket.onclose = function(event) {
        console.log('WebSocket接続が閉じられました');
    };
}

// 2. バイナリデータの送受信
function binaryDataTransfer() {
    const socket = new WebSocket('wss://example.com/binary');

    socket.onopen = function() {
        // バイナリデータの送信
        const binaryData = new Uint8Array([1, 2, 3, 4, 5]);
        socket.send(binaryData);
    };

    socket.onmessage = function(event) {
        if (event.data instanceof ArrayBuffer) {
            const view = new Uint8Array(event.data);
            console.log('受信したバイナリデータ:', view);
        }
    };
}

// 3. ハートビートの実装
function heartbeatConnection() {
    const socket = new WebSocket('wss://example.com/heartbeat');
    let heartbeatInterval;

    socket.onopen = function() {
        // 30秒ごとにハートビートを送信
        heartbeatInterval = setInterval(() => {
            if (socket.readyState === WebSocket.OPEN) {
                socket.send('ping');
            }
        }, 30000);
    };

    socket.onmessage = function(event) {
        if (event.data === 'pong') {
            console.log('ハートビート応答を受信');
        }
    };

    socket.onclose = function() {
        clearInterval(heartbeatInterval);
    };
}

// 4. 再接続の実装
function reconnectableWebSocket() {
    let socket;
    let reconnectAttempts = 0;
    const maxReconnectAttempts = 5;
    const reconnectDelay = 1000;

    function connect() {
        socket = new WebSocket('wss://example.com/reconnect');

        socket.onopen = function() {
            console.log('WebSocket接続が確立されました');
            reconnectAttempts = 0;
        };

        socket.onclose = function(event) {
            if (reconnectAttempts < maxReconnectAttempts) {
                reconnectAttempts++;
                console.log(`再接続を試みます (${reconnectAttempts}/${maxReconnectAttempts})`);
                setTimeout(connect, reconnectDelay * reconnectAttempts);
            } else {
                console.log('最大再接続回数に達しました');
            }
        };
    }

    connect();
}

// 5. メッセージのキューイング
function queuedMessages() {
    const socket = new WebSocket('wss://example.com/queue');
    const messageQueue = [];
    let isProcessing = false;

    function sendMessage(message) {
        if (socket.readyState === WebSocket.OPEN) {
            socket.send(message);
        } else {
            messageQueue.push(message);
        }
    }

    socket.onopen = function() {
        isProcessing = true;
        while (messageQueue.length > 0) {
            const message = messageQueue.shift();
            socket.send(message);
        }
        isProcessing = false;
    };
}

// 6. エラーハンドリング
function errorHandlingWebSocket() {
    const socket = new WebSocket('wss://example.com/error');

    socket.onerror = function(error) {
        console.error('WebSocketエラー:', error);
        // エラーの種類に応じた処理
        if (error.code === 'ECONNREFUSED') {
            console.log('接続が拒否されました');
        } else if (error.code === 'ETIMEDOUT') {
            console.log('接続がタイムアウトしました');
        }
    };

    socket.onclose = function(event) {
        if (event.wasClean) {
            console.log('正常に接続が閉じられました');
        } else {
            console.log('接続が異常終了しました');
        }
    };
}

// 7. セキュリティ対策
function secureWebSocket() {
    const socket = new WebSocket('wss://example.com/secure', {
        // サブプロトコルの指定
        protocols: ['secure-protocol'],
        // オリジン制限
        origin: 'https://example.com'
    });

    // メッセージの検証
    socket.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            // データの検証
            if (validateMessage(data)) {
                processMessage(data);
            }
        } catch (error) {
            console.error('無効なメッセージ形式:', error);
        }
    };
}

// 8. ストリーミングデータの処理
function streamingData() {
    const socket = new WebSocket('wss://example.com/stream');
    let buffer = '';

    socket.onmessage = function(event) {
        buffer += event.data;
        
        // メッセージの区切り文字で分割
        const messages = buffer.split('\n');
        buffer = messages.pop(); // 最後の不完全なメッセージをバッファに戻す

        messages.forEach(message => {
            if (message.trim()) {
                processStreamMessage(message);
            }
        });
    };
}

// 9. 複数のチャンネル
function multiChannelWebSocket() {
    const channels = {
        chat: new WebSocket('wss://example.com/chat'),
        notifications: new WebSocket('wss://example.com/notifications'),
        updates: new WebSocket('wss://example.com/updates')
    };

    // 各チャンネルのイベントハンドラを設定
    Object.entries(channels).forEach(([name, socket]) => {
        socket.onmessage = function(event) {
            handleChannelMessage(name, event.data);
        };
    });
}

// 10. パフォーマンス最適化
function optimizedWebSocket() {
    const socket = new WebSocket('wss://example.com/optimized');
    let lastMessageTime = 0;
    const messageThrottle = 100; // ミリ秒

    function sendOptimizedMessage(message) {
        const now = Date.now();
        if (now - lastMessageTime >= messageThrottle) {
            socket.send(message);
            lastMessageTime = now;
        } else {
            // メッセージをキューに追加
            setTimeout(() => sendOptimizedMessage(message), messageThrottle);
        }
    }
} 