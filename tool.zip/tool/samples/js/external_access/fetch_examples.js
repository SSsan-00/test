// Fetch APIを使用した外部アクセスのサンプル

// 1. 基本的なGETリクエスト
async function basicGetRequest() {
    try {
        const response = await fetch('https://api.example.com/data');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error('Error:', error);
    }
}

// 2. POSTリクエスト（JSONデータ）
async function postJsonData() {
    try {
        const response = await fetch('https://api.example.com/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: 'John Doe',
                email: 'john@example.com'
            })
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        console.log('送信成功');
    } catch (error) {
        console.error('Error:', error);
    }
}

// 3. フォームデータの送信
async function submitFormData() {
    try {
        const formData = new FormData();
        formData.append('username', 'user123');
        formData.append('password', 'pass123');

        const response = await fetch('https://api.example.com/form', {
            method: 'POST',
            body: formData
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        console.log('フォーム送信成功');
    } catch (error) {
        console.error('Error:', error);
    }
}

// 4. バイナリデータの送信
async function sendBinaryData() {
    try {
        const file = document.querySelector('input[type="file"]').files[0];
        const response = await fetch('https://api.example.com/upload', {
            method: 'POST',
            body: file
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        console.log('バイナリデータ送信成功');
    } catch (error) {
        console.error('Error:', error);
    }
}

// 5. カスタムヘッダーの設定
async function requestWithCustomHeaders() {
    try {
        const response = await fetch('https://api.example.com/protected', {
            headers: {
                'Authorization': 'Bearer token123',
                'X-Custom-Header': 'value'
            }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error('Error:', error);
    }
}

// 6. タイムアウトの設定
async function requestWithTimeout() {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);

        const response = await fetch('https://api.example.com/slow', {
            signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log(data);
    } catch (error) {
        if (error.name === 'AbortError') {
            console.log('リクエストがタイムアウトしました');
        } else {
            console.error('Error:', error);
        }
    }
}

// 7. 進捗状況の監視
async function monitorProgress() {
    try {
        const response = await fetch('https://api.example.com/large-file');
        const reader = response.body.getReader();
        const contentLength = +response.headers.get('Content-Length');
        let receivedLength = 0;

        while (true) {
            const {done, value} = await reader.read();
            if (done) break;
            receivedLength += value.length;
            console.log(`ダウンロード進捗: ${(receivedLength / contentLength) * 100}%`);
        }
        console.log('ダウンロード完了');
    } catch (error) {
        console.error('Error:', error);
    }
}

// 8. エラーハンドリング
async function handleErrors() {
    try {
        const response = await fetch('https://api.example.com/error');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error('Error:', error);
    }
}

// 9. クロスオリジンリクエスト
async function crossOriginRequest() {
    try {
        const response = await fetch('https://another-domain.com/data', {
            credentials: 'include' // クッキーを含める
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error('Error:', error);
    }
}

// 10. 複数のリクエストの並列実行
async function parallelRequests() {
    const urls = [
        'https://api.example.com/data1',
        'https://api.example.com/data2',
        'https://api.example.com/data3'
    ];

    try {
        const responses = await Promise.all(
            urls.map(url => fetch(url).then(res => res.json()))
        );
        responses.forEach((data, index) => {
            console.log(`${urls[index]}:`, data);
        });
    } catch (error) {
        console.error('Error:', error);
    }
}

// 11. ストリーミングレスポンスの処理
async function handleStreamingResponse() {
    try {
        const response = await fetch('https://api.example.com/stream');
        const reader = response.body.getReader();
        
        while (true) {
            const {done, value} = await reader.read();
            if (done) break;
            console.log('受信データ:', new TextDecoder().decode(value));
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// 12. キャッシュ制御
async function requestWithCacheControl() {
    try {
        const response = await fetch('https://api.example.com/data', {
            cache: 'no-store' // キャッシュを使用しない
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error('Error:', error);
    }
} 