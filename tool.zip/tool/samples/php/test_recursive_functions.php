<?php
declare(strict_types=1);

// 相互再帰的な関数
function process_users($depth = 0) {
    if ($depth >= 3) {
        return "SELECT * FROM users";
    }
    return process_roles($depth + 1);
}

function process_roles($depth = 0) {
    if ($depth >= 3) {
        return "SELECT * FROM roles";
    }
    return process_users($depth + 1);
}

// 自己再帰的な関数
function get_parent_category($id) {
    return "WITH RECURSIVE category_tree AS (
        SELECT * FROM categories WHERE id = {$id}
        UNION ALL
        SELECT c.* FROM categories c
        INNER JOIN category_tree ct ON ct.parent_id = c.id
    )
    SELECT * FROM category_tree";
}

// 循環参照を含むクラス
class UserService {
    private $roleService;
    
    public function __construct(RoleService $roleService) {
        $this->roleService = $roleService;
    }
    
    public function getUserWithRoles($userId) {
        return "SELECT u.*, r.name as role_name 
                FROM users u 
                LEFT JOIN user_roles ur ON u.id = ur.user_id
                LEFT JOIN roles r ON ur.role_id = r.id
                WHERE u.id = {$userId}";
    }
    
    public function getUsersByRole($roleName) {
        return $this->roleService->getUsersWithRole($roleName);
    }
}

class RoleService {
    private $userService;
    
    public function __construct(UserService $userService) {
        $this->userService = $userService;
    }
    
    public function getUsersWithRole($roleName) {
        return "SELECT u.* 
                FROM users u 
                INNER JOIN user_roles ur ON u.id = ur.user_id
                INNER JOIN roles r ON ur.role_id = r.id
                WHERE r.name = '{$roleName}'";
    }
    
    public function getRoleWithUsers($roleId) {
        return $this->userService->getUserWithRoles($roleId);
    }
}

// テストケースの実行
echo "テスト1: 相互再帰的な関数\n";
echo "process_users(): " . process_users() . "\n\n";

echo "テスト2: 自己再帰的なCTE\n";
echo "get_parent_category(1): " . get_parent_category(1) . "\n\n";

echo "テスト3: 循環参照を含むクラス\n";
$roleService = new RoleService(new UserService($roleService));
$userService = new UserService($roleService);

echo "userService->getUserWithRoles(1): " . $userService->getUserWithRoles(1) . "\n";
echo "userService->getUsersByRole('admin'): " . $userService->getUsersByRole('admin') . "\n";
echo "roleService->getRoleWithUsers(1): " . $roleService->getRoleWithUsers(1) . "\n"; 