<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/utils.php';

class AdvancedQueryBuilder {
    private $db;
    private $conditions = [];
    private $params = [];
    private $table;

    public function __construct($db, $table) {
        $this->db = $db;
        $this->table = $table;
    }

    public function addCondition($field, $operator, $value) {
        $this->conditions[] = "$field $operator ?";
        $this->params[] = $value;
        return $this;
    }

    public function buildQuery() {
        $sql = "SELECT * FROM {$this->table}";
        if (!empty($this->conditions)) {
            $sql .= " WHERE " . implode(" AND ", $this->conditions);
        }
        return [$sql, $this->params];
    }
}

// 1. 文字列結合による動的クエリ生成
function generateDynamicQuery($userId, $status) {
    $baseQuery = "SELECT * FROM users";
    $conditions = [];
    $params = [];

    if ($userId) {
        $conditions[] = "id = ?";
        $params[] = $userId;
    }
    if ($status) {
        $conditions[] = "status = ?";
        $params[] = $status;
    }

    if (!empty($conditions)) {
        $baseQuery .= " WHERE " . implode(" AND ", $conditions);
    }

    return [$baseQuery, $params];
}

// 2. 条件分岐による複数候補の出現
function getQueryByType($type, $id) {
    switch ($type) {
        case 'user':
            return "SELECT * FROM users WHERE id = ?";
        case 'post':
            return "SELECT * FROM posts WHERE id = ?";
        case 'comment':
            return "SELECT * FROM comments WHERE id = ?";
        default:
            return "SELECT * FROM {$type}s WHERE id = ?";
    }
}

// 3. 同じ変数名だが別のクエリ
function processUserData($userId) {
    // 最初のクエリ
    $query = "SELECT name, email FROM users WHERE id = ?";
    $userData = $db->query($query, [$userId]);

    // 同じ変数名で別のクエリ
    $query = "SELECT COUNT(*) as post_count FROM posts WHERE user_id = ?";
    $postCount = $db->query($query, [$userId]);

    return [$userData, $postCount];
}

// 4. 複雑な文字列結合と変数展開
function buildSearchQuery($searchTerm, $filters) {
    $sql = "SELECT u.*, p.title, p.content 
            FROM users u 
            LEFT JOIN posts p ON u.id = p.user_id 
            WHERE 1=1";

    if ($searchTerm) {
        $sql .= " AND (u.name LIKE ? OR p.content LIKE ?)";
        $params = ["%$searchTerm%", "%$searchTerm%"];
    }

    foreach ($filters as $field => $value) {
        if (is_array($value)) {
            $placeholders = str_repeat('?,', count($value) - 1) . '?';
            $sql .= " AND $field IN ($placeholders)";
            $params = array_merge($params, $value);
        } else {
            $sql .= " AND $field = ?";
            $params[] = $value;
        }
    }

    return [$sql, $params];
}

// 5. ヒアドキュメント内での変数展開
function generateReportQuery($startDate, $endDate) {
    $sql = <<<SQL
        SELECT 
            u.id,
            u.name,
            COUNT(p.id) as post_count,
            (
                SELECT COUNT(*)
                FROM comments c
                WHERE c.user_id = u.id
                AND c.created_at BETWEEN ? AND ?
            ) as comment_count
        FROM users u
        LEFT JOIN posts p ON u.id = p.user_id
        WHERE p.created_at BETWEEN ? AND ?
        GROUP BY u.id, u.name
        HAVING post_count > 0
    SQL;

    return [$sql, [$startDate, $endDate, $startDate, $endDate]];
}

// 6. 動的なテーブル名とカラム名
function dynamicTableQuery($tableName, $columns, $conditions) {
    $columnList = implode(', ', $columns);
    $whereClause = implode(' AND ', array_map(
        fn($col) => "$col = ?",
        array_keys($conditions)
    ));

    $sql = "SELECT $columnList FROM $tableName WHERE $whereClause";
    return [$sql, array_values($conditions)];
}

// 7. サブクエリと結合の組み合わせ
function getComplexStats($userId) {
    $sql = <<<SQL
        SELECT 
            u.*,
            (SELECT COUNT(*) FROM posts WHERE user_id = u.id) as post_count,
            (SELECT COUNT(*) FROM comments WHERE user_id = u.id) as comment_count,
            p.recent_title,
            p.recent_date
        FROM users u
        LEFT JOIN (
            SELECT 
                user_id,
                title as recent_title,
                created_at as recent_date
            FROM posts
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT 1
        ) p ON u.id = p.user_id
        WHERE u.id = ?
    SQL;

    return [$sql, [$userId, $userId]];
}

// 8. 条件付きのORDER BY句
function getSortedUsers($sortField, $sortOrder = 'ASC') {
    $validFields = ['name', 'email', 'created_at'];
    $field = in_array($sortField, $validFields) ? $sortField : 'created_at';
    $order = strtoupper($sortOrder) === 'DESC' ? 'DESC' : 'ASC';

    $sql = "SELECT * FROM users ORDER BY $field $order";
    return [$sql, []];
}

// 9. WITH句と一時テーブルを使用した複雑なクエリ
function getComplexPostgresQuery($userId) {
    $sql = <<<SQL
        WITH user_stats AS (
            SELECT 
                u.id,
                u.name,
                COUNT(p.id) post_count,
                COUNT(c.id) comment_count
            FROM users u
            LEFT JOIN posts p ON u.id = p.user_id
            LEFT JOIN comments c ON u.id = c.user_id
            WHERE u.id = ?
            GROUP BY u.id, u.name
        ),
        recent_activity AS (
            SELECT 
                user_id,
                MAX(created_at) last_activity,
                COUNT(*) activity_count
            FROM (
                SELECT user_id, created_at FROM posts
                UNION ALL
                SELECT user_id, created_at FROM comments
            ) combined_activity
            WHERE user_id = ?
            GROUP BY user_id
        )
        SELECT 
            us.*,
            ra.last_activity,
            ra.activity_count,
            p.title recent_post_title,
            c.content recent_comment
        FROM user_stats us
        LEFT JOIN recent_activity ra ON us.id = ra.user_id
        LEFT JOIN LATERAL (
            SELECT title FROM posts 
            WHERE user_id = us.id 
            ORDER BY created_at DESC 
            LIMIT 1
        ) p ON true
        LEFT JOIN LATERAL (
            SELECT content FROM comments 
            WHERE user_id = us.id 
            ORDER BY created_at DESC 
            LIMIT 1
        ) c ON true;
    SQL;

    return [$sql, [$userId, $userId]];
}

// 10. SELECT INTOと一時テーブル作成
function createTempTableAndAnalyze($startDate, $endDate) {
    $sql = <<<SQL
        -- 一時テーブルの作成
        CREATE TEMP TABLE temp_user_stats AS
        SELECT 
            u.id user_id,
            u.name,
            COUNT(p.id) post_count,
            COUNT(c.id) comment_count
        FROM users u
        LEFT JOIN posts p ON u.id = p.user_id AND p.created_at BETWEEN ? AND ?
        LEFT JOIN comments c ON u.id = c.user_id AND c.created_at BETWEEN ? AND ?
        GROUP BY u.id, u.name;

        -- 一時テーブルの分析
        ANALYZE temp_user_stats;

        -- 結果の取得
        SELECT * FROM temp_user_stats
        WHERE post_count > 0 OR comment_count > 0
        ORDER BY post_count DESC, comment_count DESC;
    SQL;

    return [$sql, [$startDate, $endDate, $startDate, $endDate]];
}

// 11. AS句を省略したエイリアスと複雑な結合
function getAliasedQuery($userId) {
    $sql = <<<SQL
        SELECT 
            u.id uid,
            u.name uname,
            p.id pid,
            p.title ptitle,
            c.id cid,
            c.content ccontent
        FROM users u
        JOIN posts p u.id = p.user_id
        LEFT JOIN comments c p.id = c.post_id
        WHERE u.id = ?
        ORDER BY p.created_at DESC, c.created_at DESC;
    SQL;

    return [$sql, [$userId]];
}

// 12. ウィンドウ関数と複雑な集計
function getWindowFunctionQuery($userId) {
    $sql = <<<SQL
        WITH user_activity AS (
            SELECT 
                user_id,
                created_at,
                'post' activity_type,
                title content
            FROM posts
            WHERE user_id = ?
            UNION ALL
            SELECT 
                user_id,
                created_at,
                'comment' activity_type,
                content
            FROM comments
            WHERE user_id = ?
        )
        SELECT 
            user_id,
            activity_type,
            content,
            created_at,
            ROW_NUMBER() OVER (PARTITION BY activity_type ORDER BY created_at DESC) rn,
            COUNT(*) OVER (PARTITION BY activity_type) total_count,
            AVG(LENGTH(content)) OVER (PARTITION BY activity_type) avg_length
        FROM user_activity
        ORDER BY created_at DESC;
    SQL;

    return [$sql, [$userId, $userId]];
}

// 13. 複雑なサブクエリとWITH RECURSIVE
function getRecursiveQuery($categoryId) {
    $sql = <<<SQL
        WITH RECURSIVE category_tree AS (
            -- 基本ケース
            SELECT 
                id,
                name,
                parent_id,
                1 level,
                ARRAY[id] path
            FROM categories
            WHERE id = ?
            
            UNION ALL
            
            -- 再帰ケース
            SELECT 
                c.id,
                c.name,
                c.parent_id,
                ct.level + 1,
                ct.path || c.id
            FROM categories c
            JOIN category_tree ct ON c.parent_id = ct.id
            WHERE NOT c.id = ANY(ct.path)  -- 循環参照を防止
        )
        SELECT 
            ct.*,
            COUNT(p.id) post_count,
            STRING_AGG(p.title, ', ') post_titles
        FROM category_tree ct
        LEFT JOIN posts p ON p.category_id = ct.id
        GROUP BY ct.id, ct.name, ct.parent_id, ct.level, ct.path
        ORDER BY ct.level, ct.name;
    SQL;

    return [$sql, [$categoryId]];
} 