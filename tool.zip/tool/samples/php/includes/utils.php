<?php
function sanitizeInput($input) {
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}

function formatDate($date, $format = 'Y-m-d H:i:s') {
    return date($format, strtotime($date));
}

function generateRandomString($length = 10) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)))), 1, $length);
}

function logError($message, $context = []) {
    $log = date('Y-m-d H:i:s') . " - $message\n";
    if (!empty($context)) {
        $log .= "Context: " . json_encode($context) . "\n";
    }
    file_put_contents(__DIR__ . '/../logs/error.log', $log, FILE_APPEND);
} 