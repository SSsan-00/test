<?php
// 基本的なSELECT文
$sql1 = "SELECT * FROM users WHERE id = 1";

// 複雑なJOINを含むSELECT
$sql2 = "SELECT u.name, p.title 
         FROM users u 
         JOIN posts p ON u.id = p.user_id 
         WHERE u.status = 'active'";

// INSERT文
$sql3 = "INSERT INTO users (name, email) VALUES ('John', 'john@example.com')";

// UPDATE文
$sql4 = "UPDATE users SET status = 'inactive' WHERE last_login < NOW() - INTERVAL '30 days'";

// DELETE文
$sql5 = "DELETE FROM users WHERE status = 'banned'"; 