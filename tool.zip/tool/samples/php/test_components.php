<?php
namespace Analyzer\Test;

use PhpParser\ParserFactory;
use PhpParser\Node\Expr\FuncCall;
use PhpParser\Node\Name;
use PhpParser\Node\Arg;
use PhpParser\Node\Scalar\LNumber;
use Analyzer\ConstantResolver;
use Analyzer\VariableResolver;
use Analyzer\FunctionResolver;
use Analyzer\IncludeResolver;
use Analyzer\ExternalResourceAnalyzer;
use Analyzer\CrudResolver;
use PHPSQLParser\PHPSQLParser;

require_once __DIR__ . '/../../analyzer/analyzer.php';

class ComponentTest {
    public function testConstantResolver() {
        echo "=== ConstantResolver Test ===\n";
        $constantResolver = new ConstantResolver();
        $code = "<?php
        define('DB_HOST', 'localhost');
        define('DB_PORT', 3306);
        define('DB_NAME', 'test_db');
        ";
        $parser = (new ParserFactory())->createForNewestSupportedVersion();
        $ast = $parser->parse($code);
        $constantResolver->collectConstants($ast);
        echo "DB_HOST: " . $constantResolver->resolveConstant('DB_HOST') . "\n";
        echo "DB_PORT: " . $constantResolver->resolveConstant('DB_PORT') . "\n";
        echo "DB_NAME: " . $constantResolver->resolveConstant('DB_NAME') . "\n";
    }

    public function testVariableResolver() {
        echo "\n=== VariableResolver Test ===\n";
        $variableResolver = new VariableResolver();
        $code = "<?php
        \$host = 'localhost';
        \$port = 3306;
        \$db = 'test_db';
        ";
        $parser = (new ParserFactory())->createForNewestSupportedVersion();
        $ast = $parser->parse($code);
        $variableResolver->collectVariables($ast);
        echo "host: " . $variableResolver->resolveVariable('host') . "\n";
        echo "port: " . $variableResolver->resolveVariable('port') . "\n";
        echo "db: " . $variableResolver->resolveVariable('db') . "\n";
    }

    public function testFunctionResolver() {
        echo "\n=== FunctionResolver Test ===\n";
        $functionResolver = new FunctionResolver();
        $code = "<?php
        function get_user(\$id) {
            return \"SELECT * FROM users WHERE id = {\$id}\";
        }
        ";
        $parser = (new ParserFactory())->createForNewestSupportedVersion();
        $ast = $parser->parse($code);
        $functionResolver->collectFunctions($ast);
        $result = $functionResolver->resolveFunctionCall(new FuncCall(
            new Name('get_user'),
            [new Arg(new LNumber(1))]
        ));
        print_r($result);
    }

    public function testIncludeResolver() {
        echo "\n=== IncludeResolver Test ===\n";
        $includeResolver = new IncludeResolver();
        $code = "<?php
        include 'config.php';
        require_once 'functions.php';
        ";
        $log = [];
        $resolvedCode = $includeResolver->resolveIncludes('test.php', $code, [], $log);
        print_r($log);
    }

    public function testExternalResourceAnalyzer() {
        echo "\n=== ExternalResourceAnalyzer Test ===\n";
        $externalAnalyzer = new ExternalResourceAnalyzer();
        $code = "<?php
        \$response = fetch('https://api.example.com/data');
        \$ws = new WebSocket('wss://ws.example.com');
        ";
        $resources = $externalAnalyzer->analyze($code);
        print_r($resources);
    }

    public function testCrudResolver() {
        echo "\n=== CrudResolver Test ===\n";
        $views = ['user_view', 'order_view'];
        $procedures = ['sp_get_user', 'sp_update_order'];
        $crudResolver = new CrudResolver($views, $procedures);
        $sql = "SELECT * FROM users JOIN orders ON users.id = orders.user_id";
        $parser = new PHPSQLParser(false, true);
        $parser->parse($sql);
        $result = $crudResolver->resolve($parser->parsed);
        print_r($result);
    }
}

// テストの実行
$test = new ComponentTest();
$test->testConstantResolver();
$test->testVariableResolver();
$test->testFunctionResolver();
$test->testIncludeResolver();
$test->testExternalResourceAnalyzer();
$test->testCrudResolver(); 