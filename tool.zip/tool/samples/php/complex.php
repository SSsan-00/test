<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/utils.php';

class UserManager {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getUserWithPosts($userId) {
        // ヒアドキュメントを使用した複雑なSQL
        $sql = <<<SQL
            SELECT u.*, 
                   p.title, 
                   p.content,
                   COUNT(c.id) as comment_count
            FROM users u
            LEFT JOIN posts p ON u.id = p.user_id
            LEFT JOIN comments c ON p.id = c.post_id
            WHERE u.id = ?
            GROUP BY u.id, p.id
        SQL;

        return $this->db->query($sql, [$userId]);
    }

    public function updateUserStatus($userId, $status) {
        // プリペアドステートメントを使用したUPDATE
        $sql = "UPDATE users SET status = ? WHERE id = ?";
        return $this->db->execute($sql, [$status, $userId]);
    }
}

// ビューを使用したクエリ
$viewQuery = "SELECT * FROM user_posts_view WHERE user_id = 1";

// ストアドプロシージャの呼び出し
$procCall = "CALL update_user_stats(1)";

// サブクエリを含む複雑なクエリ
$complexQuery = "SELECT * FROM (
    SELECT u.id, u.name, COUNT(p.id) as post_count
    FROM users u
    LEFT JOIN posts p ON u.id = p.user_id
    GROUP BY u.id, u.name
) AS user_stats
WHERE post_count > 5"; 