<?php
declare(strict_types=1);

// 配列アクセスのテスト
$config = [
    'db' => [
        'host' => 'localhost',
        'port' => 5432
    ]
];

$query1 = "SELECT * FROM users WHERE host = '{$config['db']['host']}' AND port = {$config['db']['port']}";

// オブジェクトプロパティのテスト
class DatabaseConfig {
    public string $host = '127.0.0.1';
    public int $port = 15432;
    private array $credentials = ['user' => 'admin', 'pass' => 'secret'];
    
    public function getCredentials(): array {
        return $this->credentials;
    }
}

$dbConfig = new DatabaseConfig();
$query2 = "SELECT * FROM users WHERE host = '{$dbConfig->host}' AND port = {$dbConfig->port}";

// メソッド呼び出しのテスト
$query3 = "SELECT * FROM users WHERE user = '{$dbConfig->getCredentials()['user']}'";

// 可変変数のテスト
$tableName = 'users';
$column = 'id';
$query4 = "SELECT ${$column} FROM ${$tableName}";

// 条件分岐を含む複雑なケース
$env = 'development';
if ($env === 'development') {
    $config['db']['host'] = 'dev.localhost';
    $dbConfig->host = 'dev.127.0.0.1';
} else {
    $config['db']['host'] = 'prod.localhost';
    $dbConfig->host = 'prod.127.0.0.1';
}

$query5 = "SELECT * FROM users WHERE host IN ('{$config['db']['host']}', '{$dbConfig->host}')";

// 文字列結合を含むケース
$tablePrefix = 'app_';
$query6 = "SELECT * FROM {$tablePrefix}users";

// 配列とオブジェクトの組み合わせ
$queries = [
    'simple' => $query1,
    'object' => $query2,
    'method' => $query3,
    'variable' => $query4,
    'conditional' => $query5,
    'concat' => $query6
];

// 結果の出力
foreach ($queries as $name => $query) {
    echo "=== {$name} ===\n";
    echo $query . "\n\n";
} 