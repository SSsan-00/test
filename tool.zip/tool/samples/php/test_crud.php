<?php
// テスト用のSQL文を含むコード

// 1. 基本的なSELECT文
$selectQuery = "SELECT * FROM users WHERE status = 'active'";

// 2. INSERT文
$insertQuery = "INSERT INTO orders (user_id, product_id, quantity) VALUES (1, 100, 2)";

// 3. UPDATE文
$updateQuery = "UPDATE products SET stock = stock - 1 WHERE id = 100";

// 4. DELETE文
$deleteQuery = "DELETE FROM cart_items WHERE user_id = 1 AND product_id = 100";

// 5. 文字列結合を使用したSQL
$table = "users";
$where = "status = 'active'";
$combinedQuery = "SELECT * FROM " . $table . " WHERE " . $where;

// 6. 関数内のSQL
function get_user_data($user_id) {
    return "SELECT * FROM users WHERE id = " . $user_id;
}

// 7. クラス内のSQL
class UserRepository {
    public function find($id) {
        return "SELECT * FROM users WHERE id = " . $id;
    }
    
    public function update($id, $data) {
        $set = [];
        foreach ($data as $key => $value) {
            $set[] = "$key = '$value'";
        }
        return "UPDATE users SET " . implode(', ', $set) . " WHERE id = " . $id;
    }
}

// 8. WITH句を使用したSQL
$withQuery = "WITH recent_orders AS (
    SELECT * FROM orders WHERE created_at > '2024-01-01'
)
SELECT * FROM recent_orders";

// 9. 複数テーブルを参照するSQL
$multiTableQuery = "SELECT u.name, o.order_date 
    FROM users u 
    JOIN orders o ON u.id = o.user_id 
    WHERE u.status = 'active'";

// 10. 条件付きSQL
$isAdmin = true;
$query = $isAdmin 
    ? "SELECT * FROM users" 
    : "SELECT * FROM users WHERE status = 'active'"; 