<?php
declare(strict_types=1);

// 環境による定数値の変更
if (PHP_OS === 'Darwin') {
    define('DB_HOST', 'localhost');
    define('DB_PORT', 5432);
} else {
    define('DB_HOST', '127.0.0.1');
    define('DB_PORT', 15432);
}

// 設定による定数値の変更
$env = 'production';
if ($env === 'development') {
    define('TABLE_PREFIX', 'dev_');
    define('MAX_CONNECTIONS', 10);
} else {
    define('TABLE_PREFIX', 'prod_');
    define('MAX_CONNECTIONS', 100);
}

// 定数を使用したSQLクエリ
$queries = [
    // 基本的なSELECT文
    "SELECT * FROM " . TABLE_PREFIX . "users WHERE host = '" . DB_HOST . "'",
    
    // 条件分岐を含むクエリ
    "SELECT * FROM " . TABLE_PREFIX . "connections 
     WHERE host = '" . DB_HOST . "' 
     AND port = " . DB_PORT . "
     LIMIT " . MAX_CONNECTIONS
];

// 型による定数値の変更
if (PHP_INT_SIZE === 8) {
    define('MAX_ID', 9223372036854775807); // 64bit
} else {
    define('MAX_ID', 2147483647); // 32bit
}

// 言語設定による定数値の変更
$lang = 'ja';
if ($lang === 'ja') {
    define('ERROR_MESSAGE', 'エラーが発生しました');
    define('SUCCESS_MESSAGE', '成功しました');
} else {
    define('ERROR_MESSAGE', 'An error occurred');
    define('SUCCESS_MESSAGE', 'Success');
}

// 複数の条件による定数値の変更
$mode = 'batch';
$debug = true;

if ($mode === 'batch' && $debug) {
    define('LOG_LEVEL', 'DEBUG');
    define('LOG_FILE', '/tmp/debug.log');
} elseif ($mode === 'batch') {
    define('LOG_LEVEL', 'INFO');
    define('LOG_FILE', '/var/log/batch.log');
} else {
    define('LOG_LEVEL', 'ERROR');
    define('LOG_FILE', '/var/log/error.log');
}

// 定数を使用したクエリ
$query = "INSERT INTO " . TABLE_PREFIX . "logs (level, message, file) 
          VALUES ('" . LOG_LEVEL . "', '" . ERROR_MESSAGE . "', '" . LOG_FILE . "')"; 