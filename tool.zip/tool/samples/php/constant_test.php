<?php
// 定数定義のテストケース
const DB_HOST = 'localhost';
const DB_PORT = 5432;
const DB_NAME = 'test_db';
const DB_USER = 'test_user';
const DB_PASS = 'test_pass';

// 文字列定数
const TABLE_USERS = 'users';
const TABLE_ORDERS = 'orders';
const COLUMN_ID = 'id';
const COLUMN_NAME = 'name';

// 数値定数
const DEFAULT_LIMIT = 10;
const MAX_RETRY = 3;

// 定数を使用したSQLクエリ
$queries = [
    // 基本的なSELECT文
    "SELECT * FROM " . TABLE_USERS . " WHERE " . COLUMN_ID . " = 1",
    
    // 文字列結合を含むクエリ
    "SELECT " . COLUMN_ID . ", " . COLUMN_NAME . " FROM " . TABLE_USERS . " LIMIT " . DEFAULT_LIMIT,
    
    // 複数の定数を使用したクエリ
    "INSERT INTO " . TABLE_ORDERS . " (" . COLUMN_ID . ", " . COLUMN_NAME . ") VALUES (1, 'test')",
    
    // 定数を含む文字列リテラル
    "SELECT * FROM users WHERE id = 1 LIMIT " . DEFAULT_LIMIT,
    
    // 定数を含む複雑なクエリ
    "WITH recent_users AS (
        SELECT * FROM " . TABLE_USERS . " 
        WHERE created_at > NOW() - INTERVAL '1 day'
        LIMIT " . DEFAULT_LIMIT . "
    )
    SELECT * FROM recent_users"
];

// 定数を使用した接続文字列
$connectionString = sprintf(
    "host=%s port=%d dbname=%s user=%s password=%s",
    DB_HOST,
    DB_PORT,
    DB_NAME,
    DB_USER,
    DB_PASS
);

// 定数を使用した関数
function getUsers($limit = DEFAULT_LIMIT) {
    return "SELECT * FROM " . TABLE_USERS . " LIMIT " . $limit;
}

// 定数を使用したクラス
class UserRepository {
    const TABLE = TABLE_USERS;
    const DEFAULT_LIMIT = DEFAULT_LIMIT;
    
    public function getUsers() {
        return "SELECT * FROM " . self::TABLE . " LIMIT " . self::DEFAULT_LIMIT;
    }
}

// 定数を使用した条件分岐
$retryCount = 0;
while ($retryCount < MAX_RETRY) {
    $retryCount++;
    // リトライ処理
}

// 定数を使用した配列
$config = [
    'host' => DB_HOST,
    'port' => DB_PORT,
    'database' => DB_NAME,
    'user' => DB_USER,
    'password' => DB_PASS
]; 