<?php
declare(strict_types=1);

// 定数の定義
define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('TABLE_PREFIX', 'app_');

// 環境に応じた設定
$env = 'development';
if ($env === 'development') {
    define('DB_NAME', 'dev_db');
} else {
    define('DB_NAME', 'prod_db');
}

// 配列を使用したクエリ
$config = [
    'table' => 'users',
    'columns' => ['id', 'name', 'email']
];

// オブジェクトを使用したクエリ
class Database {
    public string $host = DB_HOST;
    public int $port = DB_PORT;
    
    public function getConnectionString(): string {
        return "mysql:host={$this->host};port={$this->port};dbname=" . DB_NAME;
    }
}

$db = new Database();

// 様々なSQLクエリの例
$queries = [
    // 基本的なSELECT
    "SELECT * FROM {$config['table']} WHERE id = 1",
    
    // 定数を使用したクエリ
    "SELECT * FROM users WHERE host = '" . DB_HOST . "' AND port = " . DB_PORT,
    
    // 配列アクセスを使用したクエリ
    "SELECT " . implode(', ', $config['columns']) . " FROM {$config['table']}",
    
    // オブジェクトプロパティを使用したクエリ
    "SELECT * FROM users WHERE host = '{$db->host}' AND port = {$db->port}",
    
    // メソッド呼び出しを使用したクエリ
    "SELECT * FROM users WHERE connection = '{$db->getConnectionString()}'",
    
    // 条件分岐を含むクエリ
    "SELECT * FROM users WHERE db_name = '" . DB_NAME . "'",
    
    // 文字列結合を使用したクエリ
    "SELECT * FROM " . TABLE_PREFIX . $config['table'] . "_backup",
    
    // 複雑な条件を含むクエリ
    "SELECT * FROM {$config['table']} WHERE " . 
    "host = '{$db->host}' AND " .
    "port = {$db->port} AND " .
    "db_name = '" . DB_NAME . "'"
];

// クエリの出力
foreach ($queries as $index => $query) {
    echo "Query {$index}:\n";
    echo $query . "\n\n";
} 