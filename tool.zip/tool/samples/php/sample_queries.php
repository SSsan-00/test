<?php
declare(strict_types=1);

class SampleQueries {
    private $db;

    public function __construct(PDO $db) {
        $this->db = $db;
    }

    public function getUserStats(int $userId): array {
        $sql = "SELECT * FROM user_stats WHERE user_id = :user_id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getOrderSummary(string $startDate, string $endDate): array {
        $sql = "SELECT * FROM order_summary 
                WHERE order_date BETWEEN :start_date AND :end_date";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'start_date' => $startDate,
            'end_date' => $endDate
        ]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateInventory(int $productId, int $quantity): bool {
        $sql = "CALL sp_sync_inventory(:product_id, :quantity)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'product_id' => $productId,
            'quantity' => $quantity
        ]);
    }

    public function generateMonthlyReport(int $year, int $month): array {
        $sql = "CALL sp_generate_monthly_report(:year, :month)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'year' => $year,
            'month' => $month
        ]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getProductInventory(): array {
        $sql = "SELECT * FROM product_inventory 
                WHERE stock_quantity > 0";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function archiveOldOrders(string $cutoffDate): bool {
        $sql = "CALL sp_archive_old_orders(:cutoff_date)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(['cutoff_date' => $cutoffDate]);
    }

    public function getCustomerActivity(int $customerId): array {
        $sql = "SELECT * FROM customer_activity 
                WHERE customer_id = :customer_id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['customer_id' => $customerId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function calculateOrderTotal(int $orderId): float {
        $sql = "CALL sp_calculate_order_total(:order_id)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['order_id' => $orderId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return (float)($result['total'] ?? 0);
    }

    public function updateUserStatus(int $userId, string $status): bool {
        $sql = "CALL sp_update_user_status(:user_id, :status)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'user_id' => $userId,
            'status' => $status
        ]);
    }
} 