<?php
declare(strict_types=1);

// インクルード解決関数
function resolveIncludes(string $file, string $code, array $stack, array &$log): string
{
    // 循環参照チェック
    if (in_array($file, $stack)) {
        $log[] = [
            'file' => $file,
            'line' => 0,
            'msg' => "循環参照を検出: " . implode(' -> ', $stack) . " -> {$file}"
        ];
        return $code;
    }

    // スタックに現在のファイルを追加
    $stack[] = $file;
    
    // インクルードパターン
    $patterns = [
        'include' => '/include\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?;?/',
        'include_once' => '/include_once\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?;?/',
        'require' => '/require\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?;?/',
        'require_once' => '/require_once\s+(?:\(|[\'"])?([^\'"\)]+)(?:[\'"\)])?;?/'
    ];

    $resolvedCode = $code;
    
    foreach ($patterns as $type => $pattern) {
        if (preg_match_all($pattern, $code, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE)) {
            // 後ろから処理して置換位置がずれるのを防ぐ
            $matches = array_reverse($matches);
            foreach ($matches as $match) {
                $includePath = trim($match[1][0]);
                $startPos = $match[0][1];
                $length = strlen($match[0][0]);
                
                // パスの解決
                $absPath = resolveIncludePath($file, $includePath);
                
                if ($absPath === null) {
                    $log[] = [
                        'file' => $file,
                        'line' => 0,
                        'msg' => "インクルードファイルが見つかりません: {$includePath}"
                    ];
                    continue;
                }

                // インクルードファイルの内容を読み込む
                $includedCode = file_get_contents($absPath);
                if ($includedCode === false) {
                    $log[] = [
                        'file' => $file,
                        'line' => 0,
                        'msg' => "インクルードファイルの読み込みに失敗: {$absPath}"
                    ];
                    continue;
                }

                // PHPタグを除去
                $includedCode = preg_replace('/^<\?php\s*/', '', $includedCode);
                $includedCode = preg_replace('/\?>\s*$/', '', $includedCode);
                // 末尾のセミコロンを除去
                $includedCode = rtrim($includedCode, "; \n\r\t");

                // 再帰的にインクルードを解決
                $resolvedIncludedCode = resolveIncludes($absPath, $includedCode, $stack, $log);
                
                // インクルード文を解決済みコードで置換（セミコロンを追加）
                $resolvedCode = substr_replace($resolvedCode, $resolvedIncludedCode . ";", $startPos, $length);
            }
        }
    }

    return $resolvedCode;
}

/**
 * インクルードパスを解決
 */
function resolveIncludePath(string $currentFile, string $includePath): ?string
{
    // 文字列連結の解決
    if (preg_match('/^(.+?)\s*\.\s*[\'"]([^\'"]+)[\'"]$/', $includePath, $matches)) {
        $first = trim($matches[1], '\'"');
        // __DIR__ の解決
        if ($first === '__DIR__') {
            $includePath = dirname($currentFile) . $matches[2];
        } else {
            $includePath = $first . $matches[2];
        }
    } elseif (strpos($includePath, '__DIR__') !== false) {
        $includePath = str_replace('__DIR__', dirname($currentFile), $includePath);
    }

    // 絶対パスの場合
    if (strpos($includePath, '/') === 0) {
        return file_exists($includePath) ? $includePath : null;
    }

    // 相対パスの場合
    $currentDir = dirname($currentFile);
    $absPath = realpath($currentDir . '/' . $includePath);
    
    if ($absPath === false) {
        // PHPのインクルードパスをチェック
        $includePaths = explode(PATH_SEPARATOR, get_include_path());
        foreach ($includePaths as $path) {
            $absPath = realpath($path . '/' . $includePath);
            if ($absPath !== false) {
                return $absPath;
            }
        }
        return null;
    }

    return $absPath;
}

// テスト用のインクルードファイルを作成
$testDir = __DIR__ . '/include_test';
if (!is_dir($testDir)) {
    mkdir($testDir, 0777, true);
}

// テスト用のファイルを作成
file_put_contents($testDir . '/config.php', <<<'EOD'
<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'test_db');
EOD
);

file_put_contents($testDir . '/functions.php', <<<'EOD'
<?php
function getConnection() {
    return "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME;
}
EOD
);

file_put_contents($testDir . '/circular_a.php', <<<'EOD'
<?php
include 'circular_b.php';
EOD
);

file_put_contents($testDir . '/circular_b.php', <<<'EOD'
<?php
include 'circular_a.php';
EOD
);

file_put_contents($testDir . '/main.php', <<<'EOD'
<?php
// 相対パスでのインクルード
include 'config.php';
include 'functions.php';

// 絶対パスでのインクルード
include __DIR__ . '/config.php';

// 循環参照のテスト
include 'circular_a.php';

// 存在しないファイルのインクルード
include 'not_exists.php';

// インクルードされたファイルの内容を使用
$dsn = getConnection();
echo "DSN: {$dsn}\n";
EOD
);

// テスト実行
echo "=== インクルード解決テスト ===\n\n";

$code = file_get_contents($testDir . '/main.php');
$log = [];
$resolvedCode = resolveIncludes($testDir . '/main.php', $code, [], $log);

echo "解決後のコード:\n";
echo "-------------------\n";
echo $resolvedCode;
echo "-------------------\n\n";

echo "ログ:\n";
echo "-------------------\n";
foreach ($log as $entry) {
    echo "ファイル: {$entry['file']}\n";
    echo "行: {$entry['line']}\n";
    echo "メッセージ: {$entry['msg']}\n";
    echo "-------------------\n";
}

// テスト用のファイルを削除
array_map('unlink', glob($testDir . '/*.php'));
rmdir($testDir); 