<?php
declare(strict_types=1);

// 基本的な関数定義
function get_user_by_id($id) {
    return "SELECT * FROM users WHERE id = {$id}";
}

function update_user_status($id, $status) {
    return "UPDATE users SET status = '{$status}' WHERE id = {$id}";
}

// 配列を使用した関数
function get_table_data($table, $conditions = []) {
    $where = '';
    if (!empty($conditions)) {
        $where = ' WHERE ' . implode(' AND ', array_map(function($k, $v) {
            return "{$k} = '{$v}'";
        }, array_keys($conditions), $conditions));
    }
    return "SELECT * FROM {$table}{$where}";
}

// オブジェクトを使用した関数
function insert_record($table, $data) {
    $columns = implode(', ', array_keys($data));
    $values = implode(', ', array_map(function($v) {
        return "'{$v}'";
    }, $data));
    return "INSERT INTO {$table} ({$columns}) VALUES ({$values})";
}

// クラス定義
class UserRepository {
    private $table = 'users';
    
    public function find($id) {
        return "SELECT * FROM {$this->table} WHERE id = {$id}";
    }
    
    public function update($id, $data) {
        $set = implode(', ', array_map(function($k, $v) {
            return "{$k} = '{$v}'";
        }, array_keys($data), $data));
        return "UPDATE {$this->table} SET {$set} WHERE id = {$id}";
    }
}

// テストケースの実行
echo "テスト1: 基本的な関数呼び出し\n";
echo "get_user_by_id(1): " . get_user_by_id(1) . "\n\n";

echo "テスト2: 配列を使用した関数呼び出し\n";
echo "get_table_data('users', ['status' => 'active']): " . 
    get_table_data('users', ['status' => 'active']) . "\n\n";

echo "テスト3: オブジェクトを使用した関数呼び出し\n";
echo "insert_record('users', ['name' => 'John', 'email' => 'john@example.com']): " . 
    insert_record('users', ['name' => 'John', 'email' => 'john@example.com']) . "\n\n";

echo "テスト4: クラスメソッドの呼び出し\n";
$repo = new UserRepository();
echo "repo->find(1): " . $repo->find(1) . "\n";
echo "repo->update(1, ['name' => 'Jane']): " . 
    $repo->update(1, ['name' => 'Jane']) . "\n"; 