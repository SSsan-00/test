#!/usr/bin/env php
<?php

require 'vendor/autoload.php';

use PHPSQLParser\PHPSQLParser;

function resolveSQLVars(array $lines): array {
    $sql_vars = [];

    foreach ($lines as $line) {
        if (preg_match('/\$(\w+)\s*=\s*(["\'])(.*?)\2\s*;/', $line, $m)) {
            $sql_vars[$m[1]] = $m[3];
        } elseif (preg_match('/\$(\w+)\s*\.\=\s*(["\'])(.*?)\2\s*;/', $line, $m)) {
            if (isset($sql_vars[$m[1]])) {
                $sql_vars[$m[1]] .= $m[3];
            } else {
                $sql_vars[$m[1]] = $m[3];
            }
        }
    }

    return $sql_vars;
}

function analyzeSQL(string $sql): array {
    $parser = new PHPSQLParser();
    $parsed = $parser->parse($sql);
    $result = [];

    // CRUD 判定
    if (isset($parsed['INSERT'])) {
        $tables = $parsed['INSERT'];
        $type = 'C';
    } elseif (isset($parsed['UPDATE'])) {
        $tables = $parsed['UPDATE'];
        $type = 'U';
    } elseif (isset($parsed['DELETE'])) {
        $tables = $parsed['FROM'];
        $type = 'D';
    } elseif (isset($parsed['FROM'])) {
        $tables = $parsed['FROM'];
        $type = 'R';
    } else {
        return [];
    }

    foreach ($tables as $entry) {
        if ($entry['expr_type'] === 'table') {
            $result[$entry['table']] = $type;
        }
    }

    // JOIN考慮（すべてR）
    if (isset($parsed['JOIN'])) {
        foreach ($parsed['JOIN'] as $join) {
            if ($join['expr_type'] === 'table') {
                $result[$join['table']] = 'R';
            }
        }
    }

    return $result;
}

// ==== 実行 ====
$filepath = $argv[1] ?? '';
if (!file_exists($filepath)) {
    echo "ファイルが見つかりません: $filepath\n";
    exit(1);
}

$lines = file($filepath);
$vars = resolveSQLVars($lines);

echo "解析結果:\n";

foreach ($vars as $var => $sql) {
    $tables = analyzeSQL($sql);
    foreach ($tables as $table => $crud) {
        echo "\$$var: $table → $crud\n";
    }
}
