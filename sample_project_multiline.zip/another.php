<?php
define("PRODUCT_TABLE", "products");

$query = "INSERT INTO " . PRODUCT_TABLE . " VALUES (...)";
$query2 = "DELETE FROM logs WHERE id = 1";
?>
