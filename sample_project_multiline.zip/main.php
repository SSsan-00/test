<?php
require_once 'functions/user.php';
require_once 'functions/helper.php';

if ($isAdmin) {
    define("LOG_TABLE", "logs");
    deleteLogs();
}

$sql1 = "SELECT * " . "FROM " . "sales_view";
$sql2 = "CREATE TEMP TABLE temp_orders AS " . getOrderSQL();
?>
