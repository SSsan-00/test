<?php
function loadUser() {
    $table = "users";
    $query = "SELECT * FROM " . $table;
}

function updateProduct() {
    $table = "products";
    $set = "price = 100";
    $sql = "UPDATE " . $table . " SET " . $set . " WHERE id = 1";
}
?>
