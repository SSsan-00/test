<?php
function getOrderSQL() {
    $sql = "SELECT id, name ";
    $sql .= "FROM orders ";
    $sql .= "WHERE status = 'pending'";
    return $sql;
}
?>
